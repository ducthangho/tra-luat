# Kế hoạch tiếp tục #1319

1. Preflight Cloud: repo/AGENTS/protocol/provider; GitHub state/source/dispatcher/leases/budgets; nhận vai duy nhất đúng phạm vi.
2. Evidence acquisition: tìm private handoff cuối13/11 qua references/host/session được cấp; kiểm manifest/hash, đừng công khai dữ liệu riêng.
3. Acceptance matrix: mỗi hàng §11/U1–U12 có exactcode+host+command+rc+marker+source/hash+direct/inherited/fixture/not_run+giới hạn. Bốn lựa chọn/core độc lập, target/WhatIf/noinference, pins/cache, provenance, busy/locks, promotionfence, restore và faults.
4. Gap decision: phân loại thiếu bằng chứng, requirement chưa đạt, hoặc phạm vi mở rộng. U8 test-profile/restore; manualreleasecheck vs scheduler; NSIS/crossversion/login/runtimepromotion tách rõ. Chuẩn bị design/spec trước khi tác động host.
5. Execution: chỉ phần thiếu cần thiết, target rảnh/đúngauth/đủdisk+ACL; frozenartifact/spec/write-set/budget/lease. Giữ rawFAIL; không fallback/retry tự động, không forcekill tác vụ khác. Không dùng kết quả cũ cho code mới.
6. Independent review: freeze exactbundle, reviewer riêng readonly/model+effort theo yêu cầu và evidence thật; scope+limits minh bạch.
7. Closeout: nghiệm thu từng hàng, cleanup/process/lock/retention/rollbackrunbook; post/readback exactbytes; #1319 chỉ complete khi mọi requiredoutcome đạt. Không phát minh chữ ký human hoặc productionauthority.

Chưa có spec/lease cho thi công bổ sung; PLAN này là trình tự đề xuất, không tự cấp quyền. Giữ chỉ thị ủy quyền đã có; chỉ hỏi khi thiếu quyết định thật mà không thể tra cứu.
