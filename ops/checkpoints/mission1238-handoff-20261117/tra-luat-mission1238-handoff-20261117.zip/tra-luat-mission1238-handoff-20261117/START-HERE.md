# Bàn giao Cloud — Mission1238 / Packet1319

1. Đính kèm nguyên ZIP vào phiên Cloud mới; dán nội dung PROMPT-CLOUD.md.
2. Kiểm MANIFEST.json bằng verify_handoff.py, sau đó đọc HANDOFF.md và PLAN.md.
3. Đọc GitHub hiện tại trước khi thực thi. ZIP là snapshot/hồ sơ, không phải lease hay bộ cài.

Không cần đường dẫn /workspace của phiên cũ. Mọi tệp cần để hiểu kế hoạch nằm trong ZIP. Bằng chứng raw cuối13/11 KHÔNG có trong ZIP; mục còn thiếu được khai trong HANDOFF.md. Gói09/11 là lịch sử và đã bị các quyết định P2 landed thay thế.
