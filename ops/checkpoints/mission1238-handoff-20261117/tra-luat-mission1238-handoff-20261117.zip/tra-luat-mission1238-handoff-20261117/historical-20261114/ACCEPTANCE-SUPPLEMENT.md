Theo chỉ thị mới của chủ kho: “Nghiệm thu đủ đi”. Đây là Packet bổ sung cho nghiệm thu đầy đủ, không sửa hồi tố kết quả canary đã đóng của Mission #1238, không tự mở quyền production/LIVE.

## Baseline và phần đã đạt
- Source P2 PR #1306 merge b0b5480807dd70a367a306c158cc1df08b70fc25; M8 https://github.com/ducthangho/tra-luat/issues/1287#issuecomment-6815845097.
- Closeout P3/P4/P5/P6 và giới hạn: https://github.com/ducthangho/tra-luat/issues/1238#issuecomment-6843361361.
- Canonical master quan sát 14/11: 072d45a0595f3d2ff9f0880143a237c9e0ea70c3, gate43579856328 success. Không gán gate này thành lần chạy mới của operator ngoài Git.
- Baseline acceptance gốc: ops/plans/PROXIMA-PLAYWRIGHT-v1.md và bảng U1–U12 trong docs/research/2026-11-05-proxima-playwright-p0.md; giữ các quyết định owner đổi Desktop→ASUS và exact-artifact đã có.

## A. Đối chiếu nghiệm thu bắt buộc (chưa tự tuyên bố audit PASS)
- [ ] Thu bàn giao riêng từ dispatcher kế nhiệm: ma trận từng ca/U1–U12, bản mã operator cuối/manifest, raw normal+induced receipts, review exact artifact, runbook/retention/rollback và quyết định nguồn/target. Dẫn nơi lưu + hash; không công khai profile/credential.
- [ ] Kiểm từng tiêu chí §11 kế hoạch: 4 lựa chọn/core độc lập; target/no fallback/no retry; WhatIf; secrets/profile isolation; pins/cache; provenance/corrupt rejection; busy/dual lock; promotion fence; binary+matching-data restore; filelock/diskfull/restore failure; no-inference health; exact-source review.
- [ ] Tách bằng chứng đọc lại trực tiếp, bằng chứng kế thừa tương đương byte, fixture, và not_run. Đặc biệt không biến G1 controlledfixture thành legal verification, status thành upstream auth/quota, hay raw induced FAIL thành controller PASS.
- [ ] Kiểm U8 theo profile thử: nêu rõ dữ liệu/phiên nào được tái lập thực sự và điều gì không bảo đảm; chưa có bằng chứng thì giữ mở phần đó, không tự ghi PASS.
- [ ] Kiểm cơ chế kiểm release hằng ngày: phân biệt chạy thủ công ngày13/11 với scheduler đã cài. Nếu không có scheduler, ghi đúng trạng thái và chuẩn bị thiết kế bổ sung trước mọi cài tác vụ nền.
- [ ] Reviewer độc lập đọc exact frozen evidence bundle; không coi việc dispatcher đối chiếu comment là product review/human audit mới. Ghi raw verdict, limits và readback.

## B. Phần nghiệm thu mở rộng cần thiết kế cụ thể
NSIS thực, migration khác phiên bản, giữ phiên đăng nhập và runtime promotion chưa được Mission trước chứng minh. Đây là phạm vi bổ sung, không phải tự kết luận mọi thử nghiệm cũ thất bại. Trước chạy: chọn đúng phiên bản cũ/mới, official artifact+provenance, installer scope, account/target/path/profile thử, phương án gỡ/rollback, disk/ACL, giới hạn tác động và tiêu chí PASS/FAIL. Không dùng/copy profile đăng nhập thật, tự đăng nhập/2FA, đổi gateway/service/account/endpoint, hoặc triển khai LIVE từ câu lệnh nghiệm thu chung.

## Preflight thực đo và điều kiện chặn
- ASUS 7404cfba-9034-4787-b46b-7c358126a411 offline (lastseen14h trong snapshot).
- Desktop a5f7076e-a491-4f84-829b-8d1fbcc1c767 và VM f7281f27-f79f-40a2-a2f5-b454b58a166a online, nhưng KHOA.txt đều có holder wp1315-r4-g4-validation, expiry lần lượt20:32Z và20:31Z ngày14/11/2026, heartbeat mới18:32Z/18:31Z. Không gỡ khóa, không chạy native canary chồng, không suy hết hạn là đã cleanup.
- Đọc được VM verified-result.json của wp1298-operator-unit-20261112: helper-only native locking checks PASS; chính receipt nói không thay ASUS activation/rollout.
- Workspace hiện tại chỉ có bàn giao09/11; chưa có gói raw cuối ngày13/11. Public closeout nói gói riêng tồn tại, không được suy thiếu ở workspace này là bằng chứng bị mất.

## Trạng thái/phạm vi hiện tại
proposed / evidence acquisition and acceptance-gap reconciliation. Chưa cấp executor lease; chưa thay product source/host runtime; chưa gọi model review; không reset budget/counters các Packet cũ. Ghi hồ sơ và đọc dữ liệu được thực hiện theo chỉ thị nghiệm thu; mọi thi công mới cần spec/write-set/budget/generation tương ứng và fresh ownership. Không mở lại Packet đã landed để mượn lease.

Đầu ra: ma trận nghiệm thu có nguồn/hash cho từng hàng, danh sách thiếu còn thực sự bắt buộc, rồi bounded native runs sau khi nhận đủ artifact và target rảnh; final độc lập + bookkeeping. Không đóng Packet từ checklist/tổng hợp thiếu raw evidence.
