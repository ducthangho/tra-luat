import pathlib,json,hashlib,sys
r=pathlib.Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST.json').read_text(encoding='utf-8'))
for f in m['files']:
 p=r/f['path']; b=p.read_bytes()
 assert len(b)==f['size'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
print('PASS',len(m['files']),'files; manifest does not hash itself')
