# Packet #1287 / P2: playwright-browser handoff (author, revision 1 / generation 1)

The three new files are written: about 299 lines added against B, and nothing else touched. None of it has been run. This session had no shell, Git or network, so `npm ci`, the browser install and every bash/PowerShell example are untested; the operator has to run them on Linux and Windows. No commit, push, review or merge.

**What the files contain:**
- **`package.json`**: private package `tra-luat-playwright-browser@0.1.0` with no scripts. Its only dependency is `@playwright/cli` 0.1.23. A `traLuatRuntime` block lists the required pins: Linux Node 24.19.0/npm 11.9.0, Windows Node 26.13.0/npm 11.20.0, the alpha `playwright`/`playwright-core` build, and Chromium 1252 / 157.0.8103.15 (headless, isolated).
- **`package-lock.json`**: lockfileVersion 3; root name and version match `package.json`. The download URLs and integrity hashes of the three packages are copied unchanged from the surveyed lock. I put small objects on one line to stay under 300 lines; the data is the same, and `npm ci` never rewrites a lockfile.
- **`SKILL.md`** (Vietnamese, version 0.1.0): sections Scope, pin table, Setup, Kiểm pin (pin check), Capture, Evidence, Cleanup and Limits. Setup, pin check, both capture steps and cleanup each have a bash and a PowerShell 5.1/7 block. Every flag, the config format and the output shapes come from the local CLI source, its help text and the survey files, not from memory.

**Things found in the CLI source that the SKILL now handles:**
- **Session option:** `--session=<nonce>` is read along with the other global options; `--config` is accepted only by `open`.
- **Config merging:** `~/.playwright/cli.config.json` and any `PLAYWRIGHT_MCP_*` variables are merged into the config. The pin check stops if any are present.
- **Update check:** `open` starts an `npm view` check through the shell unless `NO_UPDATE_NOTIFIER` is set, so the SKILL sets it.
- **Saved page source isn't raw bytes:** for text responses, `response-body --filename` saves decoded text re-written as UTF-8 (after the CLI's secret redaction, which is assumed to do nothing when no secrets are configured). It matches the server's bytes only when the server sent UTF-8. The Evidence section says so.
- **Opening an existing session name:** `open` silently stops an existing session with the same name first. That's why every capture uses a fresh random session name.

## Handoff

```json
{
  "packet": 1287, "revision": 1, "generation": 1,
  "provider": "anthropic", "model": "claude-opus-5-5", "surface": "claude_code_cloud", "transport": "machine",
  "session": "unknown",
  "base": "bf9914cb1a8e6f5047468f4d130b587015f8d73f",
  "candidate_head": "not_assigned (root mechanical commit determines H/tree)",
  "status": "author_handoff_ready",
  "changed_paths": [
    ".agents/skills/playwright-browser/package.json",
    ".agents/skills/playwright-browser/package-lock.json",
    ".agents/skills/playwright-browser/SKILL.md"
  ],
  "size": {"additions_by_line_count": 299, "deletions": 0, "per_file": {"package.json": 20, "package-lock.json": 35, "SKILL.md": 244}},
  "summary": "Optional data/docs skill: exact pins for official Playwright CLI 0.1.23 + alpha playwright/core + Chromium 1252/157.0.8103.15; lock resolved/SRI copied verbatim from the survey lock; Vietnamese SKILL with bash + PowerShell setup/pin-check/capture/cleanup, allow-listed CLI commands only, absolute paths outside Git, owned session name and evidence rules. Version 0.1.0.",
  "tests": {"status": "NOT_RUN", "reason": "Author limited to Read/Glob/Grep/Edit/Write; no shell/Git/network. Nothing installed or executed, not even the doc examples. Pins are the required set, not proven on any candidate."},
  "remaining_work": [
    "Mechanical commit -> H/tree; numstat confirms exactly 3 paths and <=300 lines",
    "Linux + Desktop a5f7076e-... native: clean npm ci --ignore-scripts with lock unchanged, audit signatures rc0, exact 3 installed versions/SRI, official installer gives exact Chromium 1252, redirect fixture capture, own close/delete-data, missing/corrupt install fails only the optional step",
    "Actually run every bash and PowerShell example in the SKILL on its platform (PS 5.1 and 7)",
    "Four core trees full selftest N/N; Linux gates incl. doctrine-scan, adr-song, doc-claims, Ruff F delta 0, diffcheck",
    "Independent Codex formal review and later steps per spec"
  ],
  "requested_next_role": "root_operator_mechanical_commit_then_actual_platform_gates",
  "uncertainties": [
    "Size cap pressure: lock/package.json use compact one-line small objects; a few code lines in SKILL are ~150-170 chars; few blank lines around fences. Reviewer should judge readability",
    "Windows Start-Process redirect + Handle/WaitForExit with the CLI's background daemon is untested (e.g. whether the daemon inherits the redirected file handles)",
    "Assumed, not observed: chrome.exe ProductVersion equals '157.0.8103.15'; Linux browser path chrome-linux64/chrome (from source); tab-list exits non-zero after close/delete-data; npm ls --all output contains 'name@version' text",
    "npm --userconfig is set to an owned empty file; --globalconfig is not overridden, so a pre-existing <node prefix>/etc/npmrc could still apply (registry is passed explicitly)",
    "CLI session registry stays in the per-user default cache (~/.cache/ms-playwright/daemon, %LOCALAPPDATA%\\ms-playwright\\daemon); documented, not overridden",
    "requests --static index used for response-body follows the survey (bytes matched there); numbering semantics on other sites not proven",
    "doctrine-scan 10-word overlap with the protocol not measured",
    "Author wall time not measured"
  ]
}
```