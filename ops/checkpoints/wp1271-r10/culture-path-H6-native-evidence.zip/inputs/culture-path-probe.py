import pathlib,subprocess,os,hashlib,json,datetime,csv,sys
W=pathlib.Path(r'C:\tl-win\wp1271-r9-culture-path-probe');I=pathlib.Path(r'C:\tl-win\wp1271-g8-measure-inputs')
R=pathlib.Path(r'C:\tl-win\wp1271-r8-g8\final-d04745248666\candidate')
LOCK=pathlib.Path(r'C:\tl-win\KHOA.txt');SID='wp1271-r9-H6-culture-advisory';taken=False;rows=[]
PS51=r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe';PS7=r'C:\Program Files\PowerShell\7\pwsh.exe';GIT=r'C:\tl-win\wp1271-tools\mingit-2.56.0.4\cmd\git.exe'
MODULE=R/'.agents/skills/proxima-control/scripts/ProximaConfig.psm1'
def now():return datetime.datetime.now(datetime.timezone.utc)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(n,v):(W/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env['PSModulePath']=r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules';env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
for k in list(env):
 if k.startswith('TL_') or k in ['GH_TOKEN','GITHUB_TOKEN','CLAUDE_CODE_OAUTH_TOKEN','ANTHROPIC_API_KEY','OPENAI_API_KEY','CODEX_AUTH_JSON']:env.pop(k,None)
def run(args,label,allowed=(0,),pe=None):
 p=subprocess.run(args,env=pe or env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
 (W/(label+'.log')).write_bytes(p.stdout);rows.append(dict(label=label,command=args,rc=p.returncode,output_sha256=hashlib.sha256(p.stdout).hexdigest()))
 if p.returncode not in allowed:raise RuntimeError(label+' rc='+str(p.returncode))
 return p.returncode,p.stdout.decode('utf-8-sig',errors='replace').strip()
def beat():
 if LOCK.read_text(encoding='utf-8-sig').split('\t')[0]!=SID:raise RuntimeError('Lost own lock; no overwrite')
 n=now();assert n<start+datetime.timedelta(hours=2)
 LOCK.write_text('\t'.join([SID,start.isoformat(),(start+datetime.timedelta(hours=2)).isoformat(),'H6 schema-key advisory PS51+7',n.isoformat()])+'\n',encoding='utf-8');save('heartbeat.json',dict(at=n.isoformat(),readback=LOCK.read_text(encoding='utf-8-sig')))

try:
 before=LOCK.read_text(encoding='utf-8-sig') if LOCK.exists() else ''
 if before.strip():raise RuntimeError('Host lock occupied')
 if W.exists():raise RuntimeError('Already measured; do not rerun')
 W.mkdir();start=now();LOCK.write_text(SID+'\t'+start.isoformat()+'\t'+(start+datetime.timedelta(hours=2)).isoformat()+'\tH6 culture-path advisory\t'+start.isoformat()+'\n',encoding='utf-8');taken=True;beat()
 assert sha(MODULE)=='2457a18e3c4e337b142cffc630d382693de7601b83f4ebf3b3a6b6a709552b97'
 policy="if((Get-ExecutionPolicy -Scope MachinePolicy) -ne 'Undefined' -or (Get-ExecutionPolicy -Scope UserPolicy) -ne 'Undefined'){throw 'Managed policy'};Get-ExecutionPolicy -List|ConvertTo-Json -Compress"
 run([PS51,'-NoProfile','-Command',policy],'policy')
 out={}
 for name,exe in [('ps51',PS51),('ps7',PS7)]:
  for culture in ['en-US','tr-TR']:
   pe=env.copy();pe['PSModulePath']=(r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules' if name=='ps51' else r'C:\Program Files\PowerShell\7\Modules')+r';C:\Program Files\WindowsPowerShell\Modules'
   script="$ErrorActionPreference='Stop';[Threading.Thread]::CurrentThread.CurrentCulture=[Globalization.CultureInfo]::GetCultureInfo('"+culture+"');$m=Import-Module '"+str(MODULE)+"' -Force -PassThru; $r=& $m { [ordered]@{ culture=[Globalization.CultureInfo]::CurrentCulture.Name; valid=(Test-PxPathSyntax 'C:\\px'); conin=(Test-PxPathSyntax 'C:\\conin$'); conout=(Test-PxPathSyntax 'C:\\conout$'); nul=(Test-PxPathSyntax 'C:\\nul'); com1=(Test-PxPathSyntax 'C:\\com1') } };$r|ConvertTo-Json -Compress"
   rc,data=run([exe,'-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-Command',script],name+'-'+culture,pe=pe);out[name+'-'+culture]=json.loads(data)
 save('receipt.json',dict(kind='advisory_private_helper_only',head='d047452486663c5e9c3bf234f3a62a3254213065',module_sha256=sha(MODULE),observations=out,commands=rows));print(json.dumps(out),flush=True);rc=0
except Exception as e:
 print(type(e).__name__+': '+str(e),flush=True);rc=2
finally:
 if taken and LOCK.read_text(encoding='utf-8-sig').split('\t')[0]==SID:
  final=LOCK.read_text(encoding='utf-8-sig');LOCK.write_text('',encoding='utf-8');save('lock-release.json',dict(before=final,released=True))
sys.exit(rc)
