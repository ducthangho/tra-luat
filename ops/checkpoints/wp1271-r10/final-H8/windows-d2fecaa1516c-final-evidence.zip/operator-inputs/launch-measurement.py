import pathlib,json,hashlib,base64,runpy
I=pathlib.Path(r'C:\tl-win\wp1271-g10-measure-inputs')
M=json.loads((I/'candidate-final-manifest.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((I/'windows-compare-r10.py').read_bytes())==M['operator_sha256']=='ccc229e7982d00c26525d37f94c0e4f6d420a135f478c302e74e77dece750de9'
assert len((I/'candidate-final.bundle.b64').read_text())==55184
assert sha(base64.b64decode((I/'candidate-final.bundle.b64').read_text(),validate=True))==M['bundle_sha256']
assert M['candidate']=='d2fecaa1516cbc8c20b70331a45c8c728e59ddce'
print('preflight exact operator/input/bundle hashes verified',flush=True)
runpy.run_path(str(I/'windows-compare-r10.py'),run_name='__main__')
