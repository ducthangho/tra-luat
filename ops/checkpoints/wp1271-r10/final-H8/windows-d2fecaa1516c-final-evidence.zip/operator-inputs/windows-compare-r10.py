import base64,csv,ctypes,datetime,hashlib,json,os,pathlib,shutil,subprocess,sys,threading,time,traceback
I=pathlib.Path(r'C:\tl-win\wp1271-g10-measure-inputs')
M=json.loads((I/'candidate-final-manifest.json').read_text())
W=pathlib.Path(r'C:\tl-win\wp1271-r10-g10')/('final-'+M['candidate'][:12])
LOCK=pathlib.Path(r'C:\tl-win\KHOA.txt')
SID='wp1271-r10-g10-final-'+M['candidate'][:12]
GIT=r'C:\tl-win\wp1271-tools\mingit-2.56.0.4\cmd\git.exe'
PS51=r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'
PS7=r'C:\Program Files\PowerShell\7\pwsh.exe'
REL='.agents/skills/proxima-control/scripts/ProximaConfig.psm1'
TEST='.agents/skills/proxima-control/tests/ProximaConfig.Tests.ps1'
SAMPLE='.agents/skills/proxima-control/config.example.json'
stop=threading.Event();taken=False;start=None;results=[];heartbeat_thread=None;unrelated_drive=None;unrelated_target=None;unrelated_marker=None
def now():return datetime.datetime.now(datetime.timezone.utc)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def say(v):print(json.dumps(v,ensure_ascii=True),flush=True)
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
def own():return LOCK.exists() and LOCK.read_text(encoding='utf-8-sig').split('\t')[0]==SID
def beat():
    if not own():raise RuntimeError('Lock ownership changed; no overwrite')
    n=now();
    if n>start+datetime.timedelta(hours=2):raise RuntimeError('Absolute machine-lock deadline exceeded')
    LOCK.write_text('\t'.join([SID,start.isoformat(),(start+datetime.timedelta(hours=2)).isoformat(),'wp1271 focused base/candidate PS51+7',n.isoformat()])+'\n',encoding='utf-8')
    with (W/'heartbeat-readbacks.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps({'at':n.isoformat(),'readback':LOCK.read_text(encoding='utf-8-sig')})+'\n')
def heart():
    while not stop.wait(60):
        try:beat()
        except Exception as e:say({'heartbeat_error':str(e)});stop.set();return
def run(args,label,env=None,timeout=1200,cwd=None,check=True):
    if stop.is_set():raise RuntimeError('Heartbeat/ownership lost')
    if start and now()>start+datetime.timedelta(hours=2):raise RuntimeError('Machine-lock deadline exceeded')
    say({'start':label,'command':args})
    t=time.monotonic();p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,cwd=cwd)
    try:out,_=p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        try:out,_=p.communicate(timeout=10)
        except subprocess.TimeoutExpired:out=b''
        (W/'logs'/f'{label}.log').write_bytes(out)
        raise RuntimeError('Owned test process timed out: '+label)
    (W/'logs'/f'{label}.log').write_bytes(out)
    row={'label':label,'command':args,'rc':p.returncode,'seconds':round(time.monotonic()-t,3),'log_sha256':sha(W/'logs'/f'{label}.log')}
    results.append(row)
    with (W/'command-receipts.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
    say({'finished':label,'rc':p.returncode,'seconds':row['seconds']})
    if check and p.returncode:raise RuntimeError(label+' failed rc='+str(p.returncode))
    return p.returncode,out.decode('utf-8',errors='replace').strip()
def git(repo,*args,label):return run([GIT,'-C',str(repo),*args],label)[1]
def ledger(label,rep,rc,seconds):
    p=pathlib.Path(r'C:\tl-win\do-luong.csv');exists=p.exists() and p.stat().st_size>0
    cols=['thoi_diem','session','packet','sha','bo_test','dat','tong','ca_do','thoi_luong_s','phat_hien_boi','loi_that','da_va','ghi_chu']
    row=[now().isoformat(),SID,'wp1271',M['baseline'] if label.startswith('baseline') else M['candidate'],label,rep.get('passed',0),rep.get('total',0),'|'.join(rep.get('failed_ids',[])),seconds,'focused-local','not_classified','no',f'may=DESKTOP-T9R33P2;device=a5f7076e-a491-4f84-829b-8d1fbcc1c767;ngat=khong;rc={rc}']
    with p.open('a',encoding='utf-8',newline='') as f:
        w=csv.writer(f)
        if not exists:w.writerow(cols)
        w.writerow(row)
def drive_target(d):
    k=ctypes.WinDLL('kernel32',use_last_error=True);fn=k.QueryDosDeviceW;fn.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_uint32];fn.restype=ctypes.c_uint32
    b=ctypes.create_unicode_buffer(32768);n=fn(d,b,len(b))
    return b.value if n else None
def validate_counterexamples(rep,evidence,exe):
    records=rep.get('counterexample_evidence',[])
    wanted=set(M['counterexample_only_ids'])
    if len(records)!=len(wanted) or {x.get('id') for x in records}!=wanted:raise RuntimeError('Counterexample records incomplete')
    kinds={k:0 for k in ['m','c','i']}
    for x in records:
        kind=x.get('kind');kinds[kind]=kinds.get(kind,0)+1
        for field in ['report','output','mutant']:
            v=x.get(field+'_path')
            if v:
                p=pathlib.Path(v)
                if not p.resolve().is_relative_to(evidence.resolve()):raise RuntimeError('Evidence path outside owned evidence root')
                if not p.is_file() or sha(p)!=x.get(field+'_sha256'):raise RuntimeError('Child '+field+' hash mismatch')
        cp=pathlib.Path(x['report_path']);child=json.loads(cp.read_text(encoding='utf-8-sig'))
        rp=pathlib.Path(str(cp).removesuffix('.report.json')+'.record.json')
        if not rp.is_file() or json.loads(rp.read_text(encoding='utf-8-sig'))!=x:raise RuntimeError('Retained child record differs')
        cmd=x.get('command',[])
        if not cmd or cmd[0].lower()!=exe.lower() or '-ReportPath' not in cmd or cmd[cmd.index('-ReportPath')+1]!=str(cp):raise RuntimeError('Child command/report binding missing')
        if child.get('test_culture')!='tr-TR' or '-TestCulture' not in cmd or cmd[cmd.index('-TestCulture')+1]!='tr-TR':raise RuntimeError('Actual child locale or forwarded culture invalid')
        if child.get('harness_sha256')!=M['file_sha256'][TEST] or child.get('setup_error'):raise RuntimeError('Child harness/setup invalid')
        if kind=='i':
            if x['rc']!=2 or x.get('credited') or not str(x.get('verdict')).startswith('CLEANUP_FAILURE_REPORTED') or child.get('failed') or child.get('passed')!=child.get('total') or not child.get('total') or child.get('cleanup',{}).get('status')!='failed' or child.get('cleanup',{}).get('keep_sentinel_intact') is not True:raise RuntimeError('Cleanup fault was not honestly retained')
            continue
        if x['rc']!=1 or child.get('cleanup',{}).get('status')!='ok':raise RuntimeError('Mutant/control setup or cleanup failure')
        for w in x.get('required',[]):
            cid,token=w.split(':',1)
            if not any(c['id']==cid and c['outcome']=='failed' and token in str(c.get('reason','')) for c in child['cases']):raise RuntimeError('Named child behavioural failure absent: '+w)
            if kind=='m' and token.startswith('WRONG_CODE'):raise RuntimeError('Diagnostic mismatch got mutant credit')
        if kind=='m' and (x.get('credited') is not True or not str(x.get('verdict')).startswith('KILLED')):raise RuntimeError('Mutant not credited/killed')
        if kind=='c' and (x.get('credited') or not str(x.get('verdict')).startswith('CONTROL_NO_CREDIT') or any('ACCEPTED_INVALID' in str(c.get('reason','')) for c in child['cases'])):raise RuntimeError('Diagnostic-only control incorrectly credited')
    if kinds!={'m':24,'c':1,'i':1}:raise RuntimeError('Unexpected focused mutant/control kinds')
    return {'verified_records':len(records),'kinds':kinds}
def main():
    global taken,start,heartbeat_thread,unrelated_drive,unrelated_target,unrelated_marker
    if os.name!='nt':raise RuntimeError('Windows only')
    lock_before=LOCK.read_text(encoding='utf-8-sig') if LOCK.exists() else ''
    if lock_before.strip():raise RuntimeError('Owner-machine lock not empty; do not take it')
    if W.exists():raise RuntimeError('Measurement directory already exists; do not overwrite')
    W.mkdir(parents=True);(W/'logs').mkdir();(W/'reports').mkdir();(W/'scratch').mkdir();(W/'harness').mkdir();(W/'evidence').mkdir()
    start=now();LOCK.write_text(SID+'\t'+start.isoformat()+'\t'+(start+datetime.timedelta(hours=2)).isoformat()+'\twp1271 focused tests\t'+start.isoformat()+'\n',encoding='utf-8');taken=True
    if not own():raise RuntimeError('Lock readback mismatch')
    save(W/'lock-acquisition.json',{'session':SID,'at':now().isoformat(),'before':lock_before,'readback':LOCK.read_text(encoding='utf-8-sig'),'path':str(LOCK),'deadline':(start+datetime.timedelta(hours=2)).isoformat()})
    if sha(I/'device-online.json')!=M['device_online_sha256']:raise RuntimeError('Device Online readback hash mismatch')
    online=json.loads((I/'device-online.json').read_text(encoding='utf-8-sig'));
    if online.get('device_id')!='a5f7076e-a491-4f84-829b-8d1fbcc1c767' or online.get('online') is not True:raise RuntimeError('Missing selected-device Online evidence')
    save(W/'device-online.json',online)
    beat()
    heartbeat_thread=threading.Thread(target=heart,daemon=True);heartbeat_thread.start()
    env=os.environ.copy();env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
    for k in list(env):
        if k.startswith('TL_') or k in ['GH_TOKEN','GITHUB_TOKEN','ANTHROPIC_API_KEY','CLAUDE_CODE_OAUTH_TOKEN','CODEX_AUTH_JSON','OPENAI_API_KEY']:env.pop(k,None)
    load="$ErrorActionPreference='Stop'; $env:PSModulePath=(Join-Path $PSHOME 'Modules')+';C:\\Program Files\\WindowsPowerShell\\Modules'; Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | Select-Object ProcessId,ParentProcessId,CreationDate | ConvertTo-Json -Compress"
    _,load_data=run([PS51,'-NoProfile','-NonInteractive','-Command',load],'load-before',env=env)
    policy="$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';C:\\Program Files\\WindowsPowerShell\\Modules'; if((Get-ExecutionPolicy -Scope MachinePolicy) -ne 'Undefined' -or (Get-ExecutionPolicy -Scope UserPolicy) -ne 'Undefined'){throw 'Managed policy forbids process-only exception'}; Get-ExecutionPolicy -List | ConvertTo-Json -Compress"
    run([PS51,'-NoProfile','-NonInteractive','-Command',policy],'policy-before',env=env)
    load_rows=json.loads(load_data);load_rows=load_rows if isinstance(load_rows,list) else [load_rows]
    if not any(x['ProcessId']==os.getpid() for x in load_rows):raise RuntimeError('Load probe did not positively identify own process')
    save(W/'load-before.json',load_rows)
    ud=W/'unrelated-mapping-target';ud.mkdir();unrelated_marker=ud/'marker.txt';unrelated_marker.write_text(SID,encoding='utf-8')
    for l in 'PQRSTUVWXYZONMLKJIHG':
        if not (ctypes.windll.kernel32.GetLogicalDrives() & (1<<(ord(l)-65))) and drive_target(l+':') is None:unrelated_drive=l+':';break
    if not unrelated_drive:raise RuntimeError('No free unrelated fixture drive')
    run([r'C:\Windows\System32\subst.exe',unrelated_drive,str(ud)],'create-unrelated-mapping',env=env)
    unrelated_target=drive_target(unrelated_drive)
    if not unrelated_target or pathlib.Path(unrelated_drive+'\\marker.txt').read_text(encoding='utf-8')!=SID:raise RuntimeError('Unrelated mapping identity failed')
    save(W/'unrelated-mapping-before.json',{'drive':unrelated_drive,'target':unrelated_target,'marker_sha256':sha(unrelated_marker)})
    b=base64.b64decode((I/'candidate-final.bundle.b64').read_text());bundle=W/'candidate.bundle';bundle.write_bytes(b)
    if sha(bundle)!=M['bundle_sha256']:raise RuntimeError('Bundle hash mismatch')
    base=W/'baseline';candidate=W/'candidate'
    run([GIT,'-c','core.autocrlf=false','clone','--no-checkout','--single-branch','--branch','master','https://github.com/ducthangho/tra-luat.git',str(base)],'clone-baseline')
    git(base,'fetch','origin',M['baseline'],label='fetch-base-exact')
    run([GIT,'clone','--no-hardlinks','--no-checkout',str(base),str(candidate)],'clone-candidate')
    for name,repo in [('baseline',base),('candidate',candidate)]:
        git(repo,'config','core.autocrlf','false',label=name+'-lf')
        git(repo,'config','core.eol','lf',label=name+'-eol')
        git(repo,'config','core.abbrev','7',label=name+'-abbrev')
        git(repo,'sparse-checkout','set','--no-cone','/.gitattributes','/.agents/skills/proxima-control/',label=name+'-sparse')
    git(base,'checkout','--detach',M['baseline'],label='checkout-base')
    git(candidate,'bundle','verify',str(bundle),label='bundle-verify')
    git(candidate,'fetch',str(bundle),'HEAD:refs/heads/measured-candidate',label='import-candidate')
    git(candidate,'checkout','--detach',M['candidate'],label='checkout-candidate')
    identities={}
    for name,repo in [('baseline',base),('candidate',candidate)]:
        h=git(repo,'rev-parse','HEAD',label=name+'-sha');tree=git(repo,'rev-parse','HEAD^{tree}',label=name+'-tree')
        identities[name]={'sha':h,'tree':tree,'parents':git(repo,'show','-s','--format=%P','HEAD',label=name+'-identity-parents').split()}
        if name=='baseline' and (tree!=M['baseline_tree'] or identities[name]['parents']!=M['baseline_parents']):raise RuntimeError('Baseline tree/parents mismatch')
        if h!=M[name]:raise RuntimeError('Wrong '+name+' SHA')
    parents=git(candidate,'show','-s','--format=%P','HEAD',label='candidate-parents').split()
    if identities['candidate']['tree']!=M['tree'] or parents!=M['parents']:raise RuntimeError('Candidate tree/parent mismatch')
    for f,h in M['file_sha256'].items():
        if sha(candidate/f)!=h:raise RuntimeError('Checkout bytes mismatch: '+f)
    save(W/'identity.json',{'source':M,'actual':identities,'parents':parents,'lock_session':SID,'host':os.environ.get('COMPUTERNAME'),'account':os.environ.get('USERNAME')})
    harness=W/'harness'/'ProximaConfig.Tests.ps1';shutil.copyfile(candidate/TEST,harness)
    if sha(harness)!=M['file_sha256'][TEST]:raise RuntimeError('Common harness hash mismatch')
    before_bytes={name:{str(f.relative_to(repo)).replace(chr(92),'/'):sha(f) for f in repo.rglob('*') if f.is_file() and '.git' not in f.relative_to(repo).parts} for name,repo in [('baseline',base),('candidate',candidate)]}
    save(W/'before-file-hashes.json',before_bytes)
    phases={};normal_ok=True
    def measure(name,repo,exe,psid,cx=False):
        label=name+'-'+psid+('-counterexamples' if cx else '')
        scratch=W/'scratch'/label;scratch.mkdir();evidence=W/'evidence'/label;evidence.mkdir();report=W/'reports'/(label+'.json')
        pe=env.copy();pe['PSModulePath']=(r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules' if psid=='ps51' else r'C:\Program Files\PowerShell\7\Modules')+r';C:\Program Files\WindowsPowerShell\Modules'
        pe['TEMP']=str(scratch);pe['TMP']=str(scratch)
        args=[exe,'-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(harness),'-ModulePath',str(repo/REL),'-RepositoryRoot',str(repo),'-SamplePath',str(repo/SAMPLE),'-ScratchRoot',str(scratch),'-ReportPath',str(report),'-EvidenceRoot',str(evidence),'-VhdFixture']
        args.extend(['-TestCulture','tr-TR' if cx else 'en-US'])
        if cx:args.append('-Counterexamples')
        t=time.monotonic();rc,_=run(args,label,env=pe,check=False)
        rep=json.loads(report.read_text(encoding='utf-8-sig')) if report.exists() else {'setup_error':'report absent','total':0,'passed':0,'cases':[]}
        ledger(label,rep,rc,round(time.monotonic()-t,3));phases[label]={'rc':rc,'report':rep,'report_sha256':sha(report) if report.exists() else None}
        save(W/'phase-progress.json',{'candidate':M['candidate'],'phases':phases,'commands':results,'at':now().isoformat()})
        ids=[x['id'] for x in rep['cases']]
        expected=set(M['counterexample_ids'] if cx else M['mandatory_ids']) | set(M['optional_ids'])
        counted=[x for x in rep['cases'] if x['outcome']!='unavailable']
        valid=not rep.get('setup_error') and not rep.get('setup_error_ids') and len(ids)==len(set(ids)) and set(ids)==expected and rep.get('total')==len(counted) and len(counted)>0 and rep.get('harness_sha256')==sha(harness) and rep.get('alias_r')=='Invoke-History'
        valid=valid and rep.get('test_culture')==('tr-TR' if cx else 'en-US')
        clean=rep.get('cleanup',{})
        valid=valid and clean.get('status')=='ok' and clean.get('keep_sentinel_intact') is True and clean.get('mappings_before')==clean.get('mappings_after') and rep.get('vhd_fixture') is True and clean.get('vhd',{}).get('removed') is True
        exclusions=rep.get('snapshot_exclusions',[])
        valid=valid and len(exclusions)==1 and exclusions[0].get('path')==clean.get('vhd',{}).get('file') and exclusions[0].get('logical_files_hashed')==str(clean.get('vhd',{}).get('letter'))+'\\px'
        if name=='baseline':valid=valid and rc==1 and rep.get('total')==len(expected) and rep.get('failed')==len(expected) and rep.get('api_state')=='module_absent' and all(x['outcome']=='failed' and 'API_ABSENT' in str(x.get('reason','')) for x in rep['cases'])
        else:
            valid=valid and rc==0 and rep.get('passed')==rep.get('total') and rep.get('failed')==0 and rep.get('module_sha256')==M['file_sha256'][REL] and rep.get('sample_sha256')==M['file_sha256'][SAMPLE]
            valid=valid and all(x['outcome']=='passed' if x['id'] not in M['optional_ids'] else x['outcome'] in ['passed','unavailable'] for x in rep['cases'])
        if cx and valid:
            phases[label]['independently_verified_counterexamples']=validate_counterexamples(rep,evidence,exe)
            save(W/'phase-progress.json',{'candidate':M['candidate'],'phases':phases,'commands':results,'at':now().isoformat()})
        return valid,set(ids)
    for psid,exe in [('ps51',PS51),('ps7',PS7)]:
        bok,bids=measure('baseline',base,exe,psid);cok,cids=measure('candidate',candidate,exe,psid)
        normal_ok=normal_ok and bok and cok and bids==cids
    counter_ok=False
    if normal_ok:
        counter_ok=True
        for psid,exe in [('ps51',PS51),('ps7',PS7)]:
            ok,_=measure('candidate',candidate,exe,psid,True);counter_ok=counter_ok and ok
    _,load_after=run([PS51,'-NoProfile','-NonInteractive','-Command',load],'load-after',env=env)
    save(W/'load-after.json',json.loads(load_after))
    with pathlib.Path(r'C:\tl-win\do-luong.csv').open(encoding='utf-8-sig',newline='') as f:rows=[x for x in csv.DictReader(f) if x.get('session')==SID]
    if len(rows)!=len(phases):raise RuntimeError('Own ledger rows missing/misaligned')
    save(W/'ledger-own-rows.json',rows)
    if drive_target(unrelated_drive)!=unrelated_target or pathlib.Path(unrelated_drive+'\\marker.txt').read_text(encoding='utf-8')!=SID:raise RuntimeError('Unrelated fixture mapping changed')
    save(W/'unrelated-mapping-after-tests.json',{'drive':unrelated_drive,'target':drive_target(unrelated_drive),'marker_sha256':sha(unrelated_marker),'unchanged':True})
    dirty={}
    for name,repo in [('baseline',base),('candidate',candidate)]:
        dirty[name]=git(repo,'status','--porcelain','--untracked-files=all',label=name+'-status-after')
    after_bytes={name:{str(f.relative_to(repo)).replace(chr(92),'/'):sha(f) for f in repo.rglob('*') if f.is_file() and '.git' not in f.relative_to(repo).parts} for name,repo in [('baseline',base),('candidate',candidate)]}
    save(W/'after-file-hashes.json',after_bytes)
    if before_bytes!=after_bytes:raise RuntimeError('Measured checkout filesystem changed')
    final={'normal_comparison_passed':normal_ok,'counterexamples_passed':counter_ok,'counterexamples_not_run_reason':None if normal_ok else 'normal comparison failed; blocked','phases':phases,'identities':identities,'dirty':dirty,'commands':results,'finished_at':now().isoformat()}
    save(W/'measurement.json',final);say({'measurement':str(W/'measurement.json'),'normal_comparison_passed':normal_ok,'counterexamples_passed':counter_ok})
    return 0 if normal_ok and counter_ok and not any(dirty.values()) else 1
try:rc=main()
except Exception as e:
    say({'operator_error':type(e).__name__+': '+str(e)})
    if W.exists():save(W/'operator-error.json',{'error':str(e),'commands':results,'traceback':traceback.format_exc()})
    rc=2
finally:
    if unrelated_drive and unrelated_target:
        if drive_target(unrelated_drive)==unrelated_target:
            q=subprocess.run([r'C:\Windows\System32\subst.exe',unrelated_drive,'/D'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            removed=q.returncode==0 and drive_target(unrelated_drive) is None
            save(W/'unrelated-mapping-cleanup.json',{'drive':unrelated_drive,'rc':q.returncode,'removed':removed,'output_sha256':hashlib.sha256(q.stdout).hexdigest()})
            if not removed:rc=2
        else:
            save(W/'unrelated-mapping-cleanup.json',{'drive':unrelated_drive,'removed':False,'reason':'ownership changed; did not alter foreign mapping'});rc=2
    stop.set()
    if heartbeat_thread:heartbeat_thread.join(timeout=3)
    if taken:
        if own():
            before_release=LOCK.read_text(encoding='utf-8-sig');LOCK.write_text('',encoding='utf-8');released=LOCK.read_text(encoding='utf-8-sig')
            save(W/'lock-release.json',{'at':now().isoformat(),'session':SID,'before':before_release,'after':released,'released':released==''})
            if released!='':rc=2
        else:
            save(W/'lock-release.json',{'at':now().isoformat(),'session':SID,'released':False,'error':'ownership lost; did not modify foreign lock'});rc=2
sys.exit(rc)
