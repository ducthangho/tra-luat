@{
    RootModule='ProximaControl.psm1'
    ModuleVersion='1.0.1'
    GUID='f71abb2d-e8a4-459e-819e-08356792fb83'
    PowerShellVersion='5.1'
    FunctionsToExport=@('px','Invoke-ProximaOperation')
    CmdletsToExport=@()
    VariablesToExport=@()
    AliasesToExport=@()
    Description='Proxima service operations and exact model selection for local and authenticated remote PowerShell sessions.'
}
