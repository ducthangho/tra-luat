Set-StrictMode -Version 2
$script:Session = $null
$script:ConfigPath = Join-Path ([Environment]::GetFolderPath('UserProfile')) '.proxima-control/settings.json'

function Get-PxConfig {
    $c = [pscustomobject]@{ mode='Local'; basePath=(Join-Path ([Environment]::GetFolderPath('UserProfile')) 'ProximaGateway'); connectionUri=''; configurationName='Microsoft.PowerShell'; defaults=[pscustomobject]@{} }
    if (Test-Path $script:ConfigPath) { $c = Get-Content $script:ConfigPath -Raw | ConvertFrom-Json }
    return $c
}
function Save-PxConfig($Config) {
    [IO.Directory]::CreateDirectory((Split-Path $script:ConfigPath)) | Out-Null
    [IO.File]::WriteAllText($script:ConfigPath, ($Config | ConvertTo-Json -Depth 8), (New-Object Text.UTF8Encoding($false)))
}
function Resolve-PxProvider([string]$Name) {
    switch ($Name.ToLowerInvariant()) {
        'gpt' { 'chatgpt' }; 'chatgpt' { 'chatgpt' }; 'claude' { 'claude' }
        'gemini' { 'gemini' }; 'perplexity' { 'perplexity' }
        default { throw 'Provider must be gpt, claude, gemini or perplexity.' }
    }
}
function Get-PxGateway([string]$BasePath) {
    $meta = Get-Content (Join-Path $BasePath 'profile/rest-port.json') -Raw -ErrorAction Stop | ConvertFrom-Json
    $p = Get-Process -Id $meta.pid -ErrorAction Stop
    if ($p.ProcessName -ne 'Proxima' -or $p.SessionId -ne 0) { throw 'Published port does not identify a background Proxima process.' }
    if ($p.Path -and $p.Path -ne (Join-Path $BasePath 'runtime/Proxima.exe')) { throw 'Unexpected runtime path.' }
    return ('http://127.0.0.1:' + [int]$meta.port)
}
function Invoke-PxHttp([string]$Uri, [string]$Method='Get', [string]$Body) {
    Add-Type -AssemblyName System.Net.Http
    $client=New-Object Net.Http.HttpClient
    $client.Timeout=[TimeSpan]::FromSeconds(300)
    $content=$null;$response=$null
    try {
        if($env:PROXIMA_API_KEY){$client.DefaultRequestHeaders.Authorization=New-Object Net.Http.Headers.AuthenticationHeaderValue('Bearer',$env:PROXIMA_API_KEY)}
        # Exactly one attempt. A timeout is not proof the provider did not execute.
        if($Method -eq 'Post'){
            $content=New-Object Net.Http.StringContent($Body,[Text.Encoding]::UTF8,'application/json')
            $response=$client.PostAsync($Uri,$content).GetAwaiter().GetResult()
        }else{$response=$client.GetAsync($Uri).GetAwaiter().GetResult()}
        $raw=$response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        if(!$response.IsSuccessStatusCode){
            $detail='Gateway request failed'
            try {
                $failure=$raw|ConvertFrom-Json
                if($failure.PSObject.Properties['error'] -and $failure.error.PSObject.Properties['message']){$detail=[string]$failure.error.message}
            }catch{}
            $detail=$detail -replace 'https?://\S+','[url]' -replace '(?i)(bearer\s+|sk-)[A-Za-z0-9._-]+','[redacted]'
            throw ('HTTP '+[int]$response.StatusCode+': '+$detail)
        }
        return ($raw|ConvertFrom-Json)
    }finally{if($response){$response.Dispose()};if($content){$content.Dispose()};$client.Dispose()}
}

function Invoke-ProximaOperation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateSet('start','stop','restart','status','models','ask')][string]$Action,
        [Parameter(Mandatory)][string]$BasePath,
        [string]$Provider, [string]$Model, [string]$Prompt, [switch]$Force
    )
    $ErrorActionPreference='Stop'
    # Gateway status is independent of Windows Service Control Manager access.
    # A denied service query must not block an already authorized inference route.
    if($Action -eq 'status'){
        $uri=Get-PxGateway $BasePath
        $r=Invoke-RestMethod ($uri+'/api/status') -TimeoutSec 10 -ErrorAction Stop
        if(!$r.success){throw 'Gateway returned unsuccessful status.'}
        return [pscustomobject]@{service='not_queried';serviceControl='not_checked';gateway=$true;version=$r.version;providers=$r.enabledProviders;authentication='not_verified_by_status'}
    }
    $activeDir=Join-Path $BasePath 'results/px-active'
    if ($Action -in @('stop','restart')) {
        $pending=@(Get-ChildItem $activeDir -Filter '*.json' -ErrorAction SilentlyContinue | Where-Object {
            (Get-Content $_.FullName -Raw | ConvertFrom-Json).state -in @('pending','unknown')
        })
        if ($pending.Count -and !$Force) { throw 'A px request is pending or has unknown outcome. Inspect it, or explicitly use -Force to interrupt.' }
    }
    if ($Action -in @('start','restart')) {
        $ui=@(Get-Process -Name Proxima -ErrorAction SilentlyContinue | Where-Object {$_.SessionId -ne 0})
        if ($ui.Count) { throw 'Exit the Proxima login UI completely before starting or restarting the service.' }
    }
    switch ($Action) {
        'start' { Start-Service -Name ProximaGateway; (Get-Service ProximaGateway).WaitForStatus('Running',[TimeSpan]::FromSeconds(30)) }
        'stop' { Stop-Service -Name ProximaGateway; (Get-Service ProximaGateway).WaitForStatus('Stopped',[TimeSpan]::FromSeconds(40)); return [pscustomobject]@{service='Stopped';gateway=$false} }
        'restart' { Restart-Service -Name ProximaGateway; (Get-Service ProximaGateway).WaitForStatus('Running',[TimeSpan]::FromSeconds(40)) }
    }
    if ($Action -in @('start','restart')) {
        $service=Get-Service ProximaGateway
        if ($service.Status -ne 'Running') { return [pscustomobject]@{service=[string]$service.Status;gateway=$false} }
        $limit=30
        for($i=0;$i -lt $limit;$i++) {
            try {
                $uri=Get-PxGateway $BasePath
                $r=Invoke-RestMethod ($uri+'/api/status') -TimeoutSec 2 -ErrorAction Stop
                if(!$r.success){throw 'Gateway returned unsuccessful status.'}
                return [pscustomobject]@{service='Running';gateway=$true;version=$r.version;providers=$r.enabledProviders;authentication='not_verified_by_status'}
            } catch { if($i -eq ($limit-1)){throw}; Start-Sleep -Seconds 2 }
        }
    }
    $uri=Get-PxGateway $BasePath
    $models=Invoke-PxHttp ($uri+'/v1/models')
    if ($Action -eq 'models') {
        foreach($m in $models.data) {
            if(!$Provider -or $m.id -eq $Provider -or $m.id.StartsWith($Provider+':')) {
                [pscustomobject]@{id=$m.id;owner=$m.owned_by;availability='advertised_not_execution_tested'}
            }
        }
        return
    }
    if ($Action -eq 'ask') {
        if (@($models.data.id) -notcontains $Model) { throw 'Exact model ID is not advertised. Run px models first.' }
        if($Model -ne $Provider -and !$Model.StartsWith($Provider+':')) { throw 'Model does not belong to the selected provider.' }
        [IO.Directory]::CreateDirectory($activeDir)|Out-Null
        $requestId=[guid]::NewGuid().ToString('N')
        $path=Join-Path $activeDir ($requestId+'.json')
        $record=@{id=$requestId;provider=$Provider;model=$Model;state='pending';startedUtc=[DateTime]::UtcNow.ToString('o')}
        $encoding=New-Object Text.UTF8Encoding($false)
        [IO.File]::WriteAllText($path,($record|ConvertTo-Json),$encoding)
        try {
            # Do not append thinking/reasoning suffixes; use the discovered ID verbatim.
            $body=@{model=$Model;message=$Prompt;stream=$false}|ConvertTo-Json -Compress
            $r=Invoke-PxHttp ($uri+'/v1/chat/completions') 'Post' $body
            $record.state='returned'
            [pscustomobject]@{requestId=$requestId;requestedModel=$Model;reportedModel=$r.model;answer=$r.choices[0].message.content}
        } catch { $record.state='unknown'; throw }
        finally { $record.finishedUtc=[DateTime]::UtcNow.ToString('o'); [IO.File]::WriteAllText($path,($record|ConvertTo-Json),$encoding) }
    }
}

function Invoke-PxTarget($Config, [hashtable]$Arguments) {
    $Arguments.BasePath=$Config.basePath
    if($Config.mode -eq 'Local'){ return Invoke-ProximaOperation @Arguments }
    if(!$script:Session -or $script:Session.State -ne 'Opened'){throw 'Remote session is not connected. Run px connect with a trusted HTTPS connection URI.'}
    Invoke-Command -Session $script:Session -ScriptBlock {
        param($Operation)
        # Windows PowerShell WinRM endpoints do not search the PowerShell 7 module directory.
        Import-Module (Join-Path $Operation.BasePath 'control/ProximaControl.psd1') -ErrorAction Stop
        Invoke-ProximaOperation @Operation
    } -ArgumentList $Arguments -ErrorAction Stop
}

function px {
    [CmdletBinding(SupportsShouldProcess=$true)]
    param(
        [Parameter(Position=0)][ValidateSet('help','start','stop','restart','status','models','use','ask','connect','disconnect','config')][string]$Action='help',
        [Parameter(Position=1)][string]$Provider,
        [Parameter(Position=2)][string]$Value,
        [string]$Model, [uri]$ConnectionUri, [PSCredential]$Credential,
        [string]$ConfigurationName, [switch]$Force
    )
    $ErrorActionPreference='Stop'
    $c=Get-PxConfig
    switch($Action) {
        'help' { return @'
px start | stop | restart | status
px models [gpt|claude|gemini|perplexity]
px use gpt "exact-id-from-px-models"
px ask gpt "Your request" [-Model exact-id]
px connect -ConnectionUri https://trusted-name:port/wsman [-Credential (Get-Credential)]
px disconnect | config
Service control tracks only px requests, not arbitrary direct gateway clients.
Do not run service and login UI against the same browser profile concurrently.
'@ }
        'config' { return $c }
        'connect' {
            if(!$ConnectionUri -and $c.connectionUri){$ConnectionUri=[uri]$c.connectionUri}
            if(!$ConnectionUri -or $ConnectionUri.Scheme -ne 'https'){throw 'A trusted HTTPS WinRM URI is required. Certificate checks are not bypassed.'}
            if(!$Credential){$Credential=Get-Credential -Message 'Ordinary Windows operator account on the VM'}
            if(!$ConfigurationName){$ConfigurationName=$c.configurationName}
            $new=New-PSSession -ConnectionUri $ConnectionUri -Credential $Credential -ConfigurationName $ConfigurationName -Authentication Negotiate -ErrorAction Stop
            if($script:Session){Remove-PSSession $script:Session}
            $script:Session=$new
            $c.mode='Remote';$c.connectionUri=$ConnectionUri.AbsoluteUri;$c.configurationName=$ConfigurationName
            Save-PxConfig $c
            return [pscustomobject]@{connected=$true;computer=$new.ComputerName}
        }
        'disconnect' { if($script:Session){Remove-PSSession $script:Session;$script:Session=$null}; return }
        'use' {
            if(!$Provider -or !$Value){throw 'Usage: px use gpt|claude|gemini|perplexity exact-model-id'}
            $p=Resolve-PxProvider $Provider
            $available=@(Invoke-PxTarget $c @{Action='models';Provider=$p})
            if(@($available.id) -notcontains $Value){throw 'Model ID not advertised for this provider. No default changed.'}
            $c.defaults | Add-Member -MemberType NoteProperty -Name $p -Value $Value -Force
            Save-PxConfig $c
            return [pscustomobject]@{provider=$p;model=$Value;scope='this Windows user; no gateway configuration changed'}
        }
        'ask' {
            if(!$Provider -or !$Value){throw 'Usage: px ask provider "request" [-Model exact-id]'}
            $p=Resolve-PxProvider $Provider
            if(!$Model){$property=$c.defaults.PSObject.Properties[$p];if($property){$Model=[string]$property.Value}}
            if(!$Model){throw 'Choose a model first with px models and px use; no fallback was selected.'}
            if($PSCmdlet.ShouldProcess($p,'Send one provider request')){return Invoke-PxTarget $c @{Action='ask';Provider=$p;Model=$Model;Prompt=$Value}}
            return
        }
        'models' { $p=if($Provider){Resolve-PxProvider $Provider}else{''}; return Invoke-PxTarget $c @{Action='models';Provider=$p} }
        default {
            if($Action -eq 'status' -or $PSCmdlet.ShouldProcess('ProximaGateway',$Action)){return Invoke-PxTarget $c @{Action=$Action;Force=[bool]$Force}}
        }
    }
}
Export-ModuleMember -Function px,Invoke-ProximaOperation
