#requires -Version 7.2
[CmdletBinding(SupportsShouldProcess=$true)]
param(
    [ValidateSet('help','start','stop','restart','status','models','use','ask','config')]
    [string]$Action='status',
    [string]$Provider,
    [string]$Value,
    [string]$Model,
    [uri]$ConnectionUri,
    [PSCredential]$Credential,
    [string]$ConfigurationName,
    [switch]$Force
)
$ErrorActionPreference='Stop'
Import-Module (Join-Path $PSScriptRoot 'ProximaControl.psd1') -ErrorAction Stop
if($ConnectionUri){
    $connection=@{ConnectionUri=$ConnectionUri}
    if($Credential){$connection.Credential=$Credential}
    if($ConfigurationName){$connection.ConfigurationName=$ConfigurationName}
    px connect @connection | Out-Null
}
$operation=@{Action=$Action}
foreach($name in @('Provider','Value','Model')){
    if($PSBoundParameters.ContainsKey($name)){$operation[$name]=$PSBoundParameters[$name]}
}
if($Force){$operation.Force=$true}
if($WhatIfPreference){$operation.WhatIf=$true}
px @operation
