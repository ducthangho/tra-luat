import pathlib,subprocess,importlib.util,json,datetime,hashlib,fnmatch
S=pathlib.Path('/workspace/scratch/proxima-p1-s2-20261108');R=S/'holder-cache.git';source=pathlib.Path('/workspace/scratch/proxima-p1-s2-canonical/ops/lease_publish.py')
sp=importlib.util.spec_from_file_location('lp_s2',source);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
remote=subprocess.check_output(['git','-C',str(R),'ls-remote','--heads','origin'],text=True);(S/'holder-remote-heads.raw').write_text(remote)
local=dict((ref,oid) for oid,ref in (line.split() for line in subprocess.check_output(['git','-C',str(R),'show-ref','--heads'],text=True).splitlines()))
for line in remote.splitlines():
 oid,ref=line.split();assert local.get(ref)==oid,(ref,'stale')
leases=m._quet_lease_toan_kho(R);paths=['.agents/skills/proxima-control/scripts/ProximaControl.psm1','.agents/skills/proxima-control/scripts/Run-Px.ps1','.agents/skills/proxima-control/tests/ProximaControl.Tests.ps1'];matches={p:[] for p in paths};now=datetime.datetime.now(datetime.timezone.utc)
for row in leases:
 d=row['lease'];entries=d.get('write_set',[]);entries=entries if isinstance(entries,list) else []
 for p in paths:
  overlap=False
  for entry in entries:
   if isinstance(entry,str):
    q=entry.removeprefix('planned:').strip().replace('\\','/');overlap |= q==p or (q.endswith('/') and p.startswith(q)) or ('*' in q and fnmatch.fnmatchcase(p,q))
   elif isinstance(entry,dict) and isinstance(entry.get('path'),str):
    q=entry['path'].rstrip('/');overlap |= p==q or (entry.get('type')=='prefix' and p.startswith(q+'/'))
  if not overlap:continue
  state=m._phan_loai_lease(d,now);retired=m._bia_mo_doi_xung(d,leases) if state=='CÒN_HẠN' else None;assert retired is not False,(d.get('lease_id'),'unilateral tombstone');active=state=='CÒN_HẠN' and retired is not True
  matches[p].append({'lease_id':d.get('lease_id'),'ref':row['ref'],'path':row['path'],'blob':row['blob'],'state':state,'reciprocal_retired':retired,'active':active})
out={'measured_at_utc':now.isoformat(),'remote_heads':len(remote.splitlines()),'remote_heads_sha256':hashlib.sha256(remote.encode()).hexdigest(),'source_consumer_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'lease_blob_path_pairs':len(leases),'write_set':paths,'class':m._tinh_lop_tu_write_set(paths),'paths':matches,'active_holders':sum(sum(x['active'] for x in a) for a in matches.values())};(S/'holders-before-lease.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');assert out['active_holders']==0,out;print({k:v for k,v in out.items() if k!='paths'})
