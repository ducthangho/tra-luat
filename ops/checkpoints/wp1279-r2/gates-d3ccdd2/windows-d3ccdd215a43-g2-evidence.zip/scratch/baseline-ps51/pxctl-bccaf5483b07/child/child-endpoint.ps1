param([string]$In, [string]$Out, [string]$Culture)
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'
$tc = [Globalization.CultureInfo]::GetCultureInfo($Culture); [Threading.Thread]::CurrentThread.CurrentCulture = $tc; [Threading.Thread]::CurrentThread.CurrentUICulture = $tc
$WhatIfPreference = $false
$x = [Management.Automation.PSSerializer]::Deserialize([IO.File]::ReadAllText($In))
$sb = [scriptblock]::Create([string]$x.Body)
$rows = [Collections.Generic.List[object]]::new()
foreach ($it in $x.Items) {
    $e = $it.Envelope
    $row = [ordered]@{ name = [string]$it.Name; ambient_whatif = [bool]$WhatIfPreference; received_whatif = $null; received_whatif_type = $null; fqid = $null; message = $null
        result = $null; imported_before = @(Get-Module -Name ProximaControl).Count; imported_after = $null }
    foreach ($k in @($e.Keys)) { if ([string]$k -ceq 'WhatIf') { $row.received_whatif = "$($e[$k])"; if ($null -ne $e[$k]) { $row.received_whatif_type = $e[$k].GetType().FullName } } }
    try { $o = @(& $sb $e); $row.result = $(if ($o.Count -eq 1) { $o[0] } else { "count=$($o.Count)" }) } catch { $row.fqid = [string]$_.FullyQualifiedErrorId; $row.message = [string]$_.Exception.Message }
    $row.imported_after = @(Get-Module -Name ProximaControl).Count
    $rows.Add([pscustomobject]$row)
}
$rep = [ordered]@{ ps_version = "$($PSVersionTable.PSVersion)"; ps_edition = "$($PSVersionTable.PSEdition)"; culture = [Globalization.CultureInfo]::CurrentCulture.Name
    ui_culture = [Globalization.CultureInfo]::CurrentUICulture.Name; rows = $rows }
[IO.File]::WriteAllText($Out, ($rep | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))