param([string]$Wrapper, [string]$ArgsFile, [string]$Out, [string]$Culture, [string]$PreImport = '')
Set-StrictMode -Version 3.0
$ErrorActionPreference = 'Stop'
$tc = [Globalization.CultureInfo]::GetCultureInfo($Culture); [Threading.Thread]::CurrentThread.CurrentCulture = $tc; [Threading.Thread]::CurrentThread.CurrentUICulture = $tc
$WhatIfPreference = $false
$a = [Management.Automation.PSSerializer]::Deserialize([IO.File]::ReadAllText($ArgsFile)); $h = @{}; foreach ($k in $a.Keys) { $h[[string]$k] = $a[$k] }
if ($PreImport) { $null = Import-Module -Name $PreImport -DisableNameChecking -Global }
$row = [ordered]@{ ps_version = "$($PSVersionTable.PSVersion)"; ps_edition = "$($PSVersionTable.PSEdition)"; culture = [Globalization.CultureInfo]::CurrentCulture.Name
    ui_culture = [Globalization.CultureInfo]::CurrentUICulture.Name; fqid = $null; result = $null }
try { $row.result = @(& $Wrapper @h) } catch { $row.fqid = [string]$_.FullyQualifiedErrorId }
[IO.File]::WriteAllText($Out, ($row | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
if ($row.fqid) { exit 1 }
exit 0