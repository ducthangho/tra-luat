[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'imported.txt'), 'imported')
function Invoke-ProximaOperation { 'benign' }
