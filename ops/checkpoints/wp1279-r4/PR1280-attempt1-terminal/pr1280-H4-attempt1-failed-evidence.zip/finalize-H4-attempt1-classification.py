from pathlib import Path
import json,hashlib,subprocess,datetime
S=Path('/workspace/scratch/proxima-p1-s2-20261108');R=S/'holder-cache.git';C='3cc0bc7b1dd26955b6fd4cc96612d9fbacc8a8d4';B='c15603dcf537fa4beb753b263398d6e6b8c92019';H='bc16ccff3601fabeeb783f41b52360ef5851838a';ws=set(json.loads((S/'g4-lease-prepared.json').read_text())['write_set'])
def g(*a):return subprocess.check_output(['git','-C',str(R),*a],text=True).strip()
f=json.loads((S/'H4-CI-retry-dispatch-fence.json').read_text());rows=[]
for x in f['deltas']:
 start=x['old'] or g('merge-base',C,x['new']);paths=g('diff','--name-only',start,x['new']).splitlines();assert not ws.intersection(paths);row={**x,'comparison_start':start,'changed_paths':paths,'overlap':[],'classification':'ownauthorizedAUXwallplanmetadata' if x['ref']=='refs/heads/ops/wp1279-spec' else 'independent lease/land-metadata progress, disjointS2'}
 if x['ref'].endswith('/merge'):
  row.update(actual_parents=g('show','-s','--format=%P',x['new']).split(),actual_tree=g('rev-parse',x['new']+'^{tree}'));assert row['actual_parents']==[C,'b45f6bde07bec62127323131985bf5852829ab5d'];row['classification']='new PR1283landmetadata synthetic; parents/currentC and ownhead verified; not PR1280CIproof'
 rows.append(row)
assert g('ls-remote','origin','refs/heads/master').split()[0]==C;assert json.loads((S/'holders-H4-CI-retry-dispatch.json').read_text())['active_lease_ids']==['wp1279-r4-g4-claude'];f.update(classifications=rows,current_canonical=C,master_drift_since_last_classification='none',prior201metadata_drift_source='H4-master-drift-classification.json',holders_source='holders-H4-CI-retry-dispatch.json',recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat());(S/'H4-CI-retry-dispatch-fence-classification.json').write_text(json.dumps(f,indent=2)+'\n')
p=S/'pr1280-H4-ci-attempt1-failed/classification.json';assert hashlib.sha256(p.read_bytes()).hexdigest()=='e490f106aa2d726c2a9ada282fc25a44babad17eb3fbc71e9c6137621dc652c3';a=json.loads(p.read_text());assert a['jobs_total']==23 and a['jobs_success']==18 and a['jobs_failed']==5 and a['jobs_skipped']==a['jobs_cancelled']==0
for row in a['logs']:
 p=S/'pr1280-H4-ci-plugin-logs'/(str(row['job_id'])+'.json');j=json.loads(p.read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==row['source_record_sha256'];assert hashlib.sha256(j['content'].encode()).hexdigest()==row['received_UTF8_sha256'];assert len(j['content'].encode())==row['bytes']
for row in a['failures']:
 text=json.loads((S/'pr1280-H4-ci-plugin-logs'/(str(row['job_id'])+'.json')).read_text())['content']
 if row['class']=='dependency_download_transport_failure':assert text.count('The requested URL returned error: 504')==9 and 'Process completed with exit code 4.' in text
 elif row['class']=='undetermined_timing_dependency_process_cleanup_failure':assert 'source_cung_chay_main' in text and 'TimeoutExpired' in text and '12/13' in text and 'ChildProcessError' in text
 elif row['class']=='required_shards_missing_consequence':
  import re,ast
  line=next(l for l in text.splitlines() if '[G-tap]' in l and 'tập mảnh' in l);m=re.search(r'tập mảnh (\[[0-9, ]+\]) ≠ 0\.\.7',line);assert m and ast.literal_eval(m.group(1))==[0,1,3,4,5,7];row['retained_exact_raw_diagnostic_line']=line;row['prior_v3_diagnostic_label']='Compact semantic rendering, not byte-exactquote; original rawlog unchanged'
 else:raise AssertionError('unknownclass')
assert {x['actual_checkout'] for x in a['logs']}=={'2b40120d576c1de13e1cb3f4330608695ec7b884'};assert g('show','-s','--format=%P','2b40120d576c1de13e1cb3f4330608695ec7b884').split()==[B,H];assert g('rev-parse','2b40120d576c1de13e1cb3f4330608695ec7b884^{tree}')==g('rev-parse',H+'^{tree}')
a.update(all_failed_jobs_accounted=True,operator_verification='All23wrapper/contenthashes and5namedfailuremanifestations verified againstretainedofficialsource; actualsyntheticB/H4parents/tree verified, notcurrentCintegrationproof',source_aux_receipt='pr1280-H4-ci-attempt1-failed/classification.json',source_aux_sha256='e490f106aa2d726c2a9ada282fc25a44babad17eb3fbc71e9c6137621dc652c3',operator_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),retry_source='b439b14c5231adac220639520577d1da17bd74c6:ops/checkpoints/wp1279-r4/H4-metadata-drift-and-CI-retry-v3/retry-plan-v3.json');(S/'H4-attempt1-final-classification.json').write_text(json.dumps(a,indent=2)+'\n')
p=S/'retry-H4-CI-once.py';s=p.read_text().replace('H4-CI-retry-final-fence-classification.json','H4-CI-retry-dispatch-fence-classification.json').replace('holders-H4-CI-retry-final.json','holders-H4-CI-retry-dispatch.json');p.write_text(s);print('Rootverifiedall23logs/5knownfailed; fresh5refdeltasclassified; onlyg4; retryNOTyetexecuted')
