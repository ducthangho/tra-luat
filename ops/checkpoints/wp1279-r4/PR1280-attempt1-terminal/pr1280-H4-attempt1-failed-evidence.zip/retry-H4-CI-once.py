from pathlib import Path
import json,subprocess,datetime,os
S=Path('/workspace/scratch/proxima-p1-s2-20261108');G='/workspace/scratch/proxima-p0-tools/gh';H='bc16ccff3601fabeeb783f41b52360ef5851838a';RUN=42469501853

def api(ep):return json.loads(subprocess.check_output([G,'api',ep],text=True))
def git(*a):return subprocess.check_output(['git','-C','/workspace/scratch/wp1279-g4-claude',*a],text=True).strip()
plan=json.loads((S/'H4-drift-retry-v3-binding.json').read_text());assert plan['retry_used']==0 and plan['retry_limit']==1 and plan['exact_body'] and plan['remote_blobs_exact']
fence=json.loads((S/'H4-CI-retry-dispatch-fence-classification.json').read_text());assert fence['current_canonical']==plan['current_canonical'] and len(fence['classifications'])==len(fence['deltas'])
assert (datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(fence['recorded_at'])).total_seconds()<600
holder=json.loads((S/'holders-H4-CI-retry-dispatch.json').read_text());assert holder['active_lease_ids']==['wp1279-r4-g4-claude']
classification=json.loads((S/'H4-attempt1-final-classification.json').read_text());assert classification['all_failed_jobs_accounted'] and classification['run_id']==RUN and classification['attempt']==1 and classification['head']==H
r=api(f'repos/ducthangho/tra-luat/actions/runs/{RUN}');assert r['run_attempt']==1 and r['head_sha']==H and r['status']=='completed' and r['conclusion']=='failure'
j=json.loads(subprocess.check_output([G,'api','--paginate','--slurp',f'repos/ducthangho/tra-luat/actions/runs/{RUN}/attempts/1/jobs?per_page=100'],text=True));jobs=[x for p in j for x in p['jobs']];assert len(jobs)==j[0]['total_count']==23 and all(x['status']=='completed' and x['conclusion'] in ['success','failure'] for x in jobs)
assert {x['id'] for x in jobs if x['conclusion']=='failure'}=={128696795044,128696795169,128696795235,128697201468,128701958518}
pr=api('repos/ducthangho/tra-luat/pulls/1280');assert pr['head']['sha']==H and pr['draft'] and pr['state']=='open' and pr['merged'] is False
assert git('ls-remote','origin','refs/heads/master').split()[0]==plan['current_canonical'];assert git('rev-parse','HEAD')==H and not git('status','--porcelain')
(S/'H4-attempt1-final-run-before-retry.json').write_text(json.dumps(r,indent=2)+'\n');(S/'H4-attempt1-final-jobs-before-retry.json').write_text(json.dumps(j,indent=2)+'\n')
p=S/'pr1280-H4-CI-retry-executed.json';cmd=[G,'run','rerun',str(RUN),'--repo','ducthangho/tra-luat'];record={'run_id':RUN,'head':H,'old_attempt':1,'next_attempt_requested':2,'plan':plan,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'state':'dispatching_non_idempotent_do_not_repeat','allowance_used':1,'allowance_limit':1};fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:f.write(json.dumps(record,indent=2)+'\n')
q=subprocess.run(cmd,capture_output=True);(S/'pr1280-H4-CI-retry-request.stdout').write_bytes(q.stdout);(S/'pr1280-H4-CI-retry-request.stderr').write_bytes(q.stderr);record.update(request_exit=q.returncode,state='request_accepted' if q.returncode==0 else 'request_result_needs_readback_before_any_decision',finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());p.write_text(json.dumps(record,indent=2)+'\n');assert q.returncode==0,(q.returncode,q.stderr)
r2=api(f'repos/ducthangho/tra-luat/actions/runs/{RUN}');(S/'pr1280-H4-CI-retry-initial-readback.json').write_text(json.dumps(r2,indent=2)+'\n');assert r2['head_sha']==H and r2['run_attempt'] in [1,2];record.update(observed_run_attempt=r2['run_attempt'],observed_status=r2['status']);p.write_text(json.dumps(record,indent=2)+'\n')
bp=S/'packet-live-budget.json';b=json.loads(bp.read_text());b['ci_H4_PR_attempt1']={'run_id':RUN,'attempt':1,'status':'completed','conclusion':'failure','classified_source':'H4-attempt1-final-classification.json','not_passed':True};b['ci_H4_PR_retry']={'run_id':RUN,'requested_attempt':2,'category':'authorized_measurement','used':1,'limit':1,'plan_source':plan,'state':record['state'],'head':H};b['as_of']=datetime.datetime.now(datetime.timezone.utc).isoformat();bp.write_text(json.dumps(b,indent=2)+'\n');print({'run_id':RUN,'head':H,'request_exit':q.returncode,'observed_attempt':r2['run_attempt'],'status':r2['status'],'allowance_used_limit':'1/1'})
