# runtime (PM03+PM06): Test-ModuleManifest, manifest import, px help, then the UNCHANGED Run-Px.ps1 help in this same process with a test-owned
# in-memory sentinel in the module. tamper (PM04): import a private copy whose ProximaConfig.psm1 has a harmless sentinel line; S2 must reject it.
param([string]$Mode, [string]$ManifestPath, [string]$SentinelPath, [string]$OutPath)
Set-StrictMode -Version 3.0; $ErrorActionPreference = 'Stop'
$r = [ordered]@{ mode = $Mode; ps_version = "$($PSVersionTable.PSVersion)"; ps_edition = "$($PSVersionTable.PSEdition)"; culture = [Globalization.CultureInfo]::CurrentCulture.Name
    preloaded = @(Get-Module -Name ProximaControl, ProximaConfig | ForEach-Object { $_.Path }); test_manifest = $null; module = $null; help = $null; wrapper = $null
    imported = $false; error = $null; messages = @(); sentinel_exists = $false; loaded_after = @() }
$scripts = [IO.Path]::GetDirectoryName($ManifestPath)
try {
    if ($Mode -ceq 'tamper') { $null = Import-Module -Name $ManifestPath -DisableNameChecking -ErrorAction Stop; $r.imported = $true; return }
    $tm = Test-ModuleManifest -Path $ManifestPath -ErrorAction Stop; $r.test_manifest = [ordered]@{ version = "$($tm.Version)"; guid = "$($tm.Guid)"; root_module = "$($tm.RootModule)" }
    $m = Import-Module -Name $ManifestPath -PassThru -Global -DisableNameChecking -ErrorAction Stop; $r.imported = $true
    $r.module = [ordered]@{ path = $m.Path; version = "$($m.Version)"; guid = "$($m.Guid)"; commands = @($m.ExportedCommands.Keys); functions = @($m.ExportedFunctions.Keys).Count
        others = @($m.ExportedCmdlets.Keys).Count + @($m.ExportedAliases.Keys).Count + @($m.ExportedVariables.Keys).Count; loaded = @(Get-Module -Name ProximaControl).Count
        path_is_root_module = [string]::Equals([IO.Path]::GetFullPath($m.Path), [IO.Path]::Combine($scripts, 'ProximaControl.psm1'), [StringComparison]::OrdinalIgnoreCase) }
    $h = & $m.ExportedCommands['px'] help; $r.help = [ordered]@{ schema = "$($h.schema)"; action = "$($h.action)"; outcome = "$($h.outcome)"; first = "$(@($h.data)[0])" }
    $tok = [guid]::NewGuid().ToString('N'); & $m { param($t) $script:PmSentinel = $t } $tok
    $w = [ordered]@{ action = $null; outcome = $null; error = $null; conflict = $false; loaded_after = 0; same_instance = $false; sentinel_intact = $false }
    try { $wo = @(& ([IO.Path]::Combine($scripts, 'Run-Px.ps1')) help); if ($wo.Count) { $w.action = "$($wo[0].action)"; $w.outcome = "$($wo[0].outcome)" } }
    catch { $w.error = "$($_.FullyQualifiedErrorId) | $($_.Exception.Message)"; $w.conflict = "$($_.FullyQualifiedErrorId)".StartsWith('ProximaControl.ModuleConflict', [StringComparison]::Ordinal) }
    $after = @(Get-Module -Name ProximaControl); $w.loaded_after = $after.Count
    $w.same_instance = $after.Count -eq 1 -and [object]::ReferenceEquals($after[0].PSObject.BaseObject, $m.PSObject.BaseObject)
    $w.sentinel_intact = $after.Count -eq 1 -and ((& $after[0] { Get-Variable -Name PmSentinel -Scope Script -ValueOnly -ErrorAction SilentlyContinue }) -ceq $tok)
    $r.wrapper = $w
} catch {
    $r.error = "$($_.FullyQualifiedErrorId) | $($_.Exception.Message)"; $x = $_.Exception
    while ($null -ne $x) { $r.messages += $x.Message; if ($x -is [Management.Automation.IContainsErrorRecord]) { $r.messages += "$($x.ErrorRecord.FullyQualifiedErrorId)" }; $x = $x.InnerException }
} finally {
    $r.sentinel_exists = [bool]$SentinelPath -and [IO.File]::Exists($SentinelPath); $r.loaded_after = @(Get-Module -Name ProximaControl, ProximaConfig | ForEach-Object { $_.Path })
    [IO.File]::WriteAllText($OutPath, ($r | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
}