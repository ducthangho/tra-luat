chay_ghi() { local ten=$1 rc; shift
  printf '%s\t%s\t' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$ten" >> "$TL_PW_RUN/commands.tsv" || return 70
  printf '%q ' "$TL_PW_NODE" "$TL_PW_CLI" "--session=$TL_PW_SESSION" "$@" --json >> "$TL_PW_RUN/commands.tsv" || return 70
  (cd "$TL_PW_ROOT/work" && "$TL_PW_NODE" "$TL_PW_CLI" "--session=$TL_PW_SESSION" "$@" --json \
    > "$TL_PW_RUN/$ten.json" 2> "$TL_PW_RUN/$ten.err") && rc=0 || rc=$?
  printf '\trc=%s\t%s\n' "$rc" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$TL_PW_RUN/commands.tsv" || return 70
  return "$rc"; }

( set -u
  [[ "$TL_PW_SESSION" =~ ^tl-pw-[0-9a-f]{12}$ ]] || { echo 'STOP: nonce không hợp lệ' >&2; exit 1; }
  for ten in 08-close 09-delete-data 10-verify; do
    for ext in json err; do
      [ ! -e "$TL_PW_RUN/$ten.$ext" ] && [ ! -L "$TL_PW_RUN/$ten.$ext" ] ||
        { echo "STOP: output cũ $ten.$ext, không ghi đè" >&2; exit 1; }
    done
  done
  chay_ghi 08-close close || { rc=$?; echo "STOP: close rc=$rc" >&2; exit "$rc"; }
  [ -f "$TL_PW_RUN/08-close.err" ] && [ ! -s "$TL_PW_RUN/08-close.err" ] &&
    cmp -s -- "$TL_PW_RUN/08-close.json" <(printf '{\n  "session": "%s",\n  "status": "closed"\n}\n' "$TL_PW_SESSION") ||
    { echo 'STOP: close thiếu/sai phản hồi' >&2; exit 1; }
  chay_ghi 09-delete-data delete-data || { rc=$?; echo "STOP: delete-data rc=$rc" >&2; exit "$rc"; }
  [ -f "$TL_PW_RUN/09-delete-data.err" ] && [ ! -s "$TL_PW_RUN/09-delete-data.err" ] ||
    { echo 'STOP: delete-data thiếu/có stderr' >&2; exit 1; }
  if cmp -s -- "$TL_PW_RUN/09-delete-data.json" <(printf '{\n  "session": "%s",\n  "deleted": false\n}\n' "$TL_PW_SESSION"); then
    :
  elif cmp -s -- "$TL_PW_RUN/09-delete-data.json" <(printf '{\n  "session": "%s",\n  "deleted": true\n}\n' "$TL_PW_SESSION"); then
    :
  else echo 'STOP: delete-data thiếu/sai phản hồi' >&2; exit 1; fi
  if chay_ghi 10-verify tab-list; then rc=0; else rc=$?; fi
  [ "$rc" -eq 1 ] || { echo "STOP: tab-list rc=$rc, chưa chứng minh đóng phiên" >&2; exit 1; }
  [ -f "$TL_PW_RUN/10-verify.err" ] && [ ! -s "$TL_PW_RUN/10-verify.err" ] &&
    cmp -s -- "$TL_PW_RUN/10-verify.json" <(printf '{\n  "isError": true,\n  "error": "The browser '\''%s'\'' is not open, please run open first"\n}\n' "$TL_PW_SESSION") ||
    { echo 'STOP: thiếu/sai bằng chứng đóng đúng phiên' >&2; exit 1; }
  find "$TL_PW_RUN" -type f ! -name SHA256SUMS -exec sha256sum {} + > "$TL_PW_RUN/SHA256SUMS" ||
    { echo 'STOP: chưa lưu đủ hash Cleanup' >&2; exit 1; }
  echo 'CLEANUP OK' )
