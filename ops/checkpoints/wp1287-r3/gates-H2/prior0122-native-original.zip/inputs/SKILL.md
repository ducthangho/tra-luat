Operator diagnostic fixture ONLY: official previous CLI0.1.22. NOT a product candidate/SKILL or verified compatibility set. Product pins/source untouched.
