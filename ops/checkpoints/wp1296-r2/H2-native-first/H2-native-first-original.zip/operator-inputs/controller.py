import base64,csv,ctypes,datetime,hashlib,json,os,pathlib,shutil,subprocess,sys,threading,time,traceback,zipfile,msvcrt
I=pathlib.Path(r'C:\tl-win\wp1296-H2-inputs');M=json.loads((I/'manifest.json').read_text());W=pathlib.Path(r'C:\tl-win\wp1296-H2-native');LOCK=pathlib.Path(r'C:\tl-win\KHOA.txt');SID='wp1296-H2-native-'+M['candidate'][:12]
GIT=r'C:\tl-win\wp1271-tools\mingit-2.56.0.4\cmd\git.exe';PS51=r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe';PS7=r'C:\Program Files\PowerShell\7\pwsh.exe'
REL='.agents/skills/proxima-control/scripts/ProximaControl.psm1';TEST='.agents/skills/proxima-control/tests/ProximaControl.Tests.ps1';MT='.agents/skills/proxima-control/tests/ProximaManifest.Tests.ps1'
stop=threading.Event();taken=False;start=None;thread=None;results=[];phases={};lockfile=None;mu=threading.Lock()
def now():return datetime.datetime.now(datetime.timezone.utc)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n',encoding='utf-8')
def say(v):print(json.dumps(v,ensure_ascii=True),flush=True)
def own():return LOCK.exists() and LOCK.read_text(encoding='utf-8-sig').split('\t')[0]==SID
# Share READ only: competing writers cannot overwrite a live lock. Writes/heartbeat use this held handle.
def lockwrite(text):
 with mu:
  lockfile.seek(0)
  if text:lockfile.write(text)
  lockfile.truncate();lockfile.flush();os.fsync(lockfile.fileno())
def beat():
 if not own():raise RuntimeError('machine-lock ownership lost')
 n=now()
 if n>start+datetime.timedelta(hours=1):raise RuntimeError('machine-lock deadline exceeded')
 lockwrite('\t'.join([SID,start.isoformat(),(start+datetime.timedelta(hours=1)).isoformat(),'wp1296 focused native PS51/7',n.isoformat()])+'\n')
 with (W/'heartbeat-readbacks.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps({'at':n.isoformat(),'readback':LOCK.read_text(encoding='utf-8-sig')})+'\n')
def heart():
 while not stop.wait(30):
  try:beat()
  except Exception as e:say({'heartbeat_error':str(e)});stop.set();return

def run(args,label,env=None,cwd=None,timeout=1200,check=True):
 if stop.is_set() or (start and now()>start+datetime.timedelta(hours=2)):raise RuntimeError('ownership/deadline lost')
 say({'start':label});t=time.monotonic();p=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,cwd=cwd)
 try:out,_=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  subprocess.run(['taskkill','/PID',str(p.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);out,_=p.communicate();(W/'logs'/f'{label}.log').write_bytes(out);raise RuntimeError('owned test timeout '+label)
 log=W/'logs'/f'{label}.log';log.write_bytes(out);row={'label':label,'command':args,'rc':p.returncode,'seconds':round(time.monotonic()-t,3),'log_sha256':sha(log)};results.append(row)
 with (W/'command-receipts.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
 say({'finished':label,'rc':p.returncode,'seconds':row['seconds']})
 if check and p.returncode:raise RuntimeError(label+' failed rc='+str(p.returncode))
 return p.returncode,out.decode('utf-8',errors='replace').strip()
def git(repo,*args,label):return run([GIT,'-C',str(repo),*args],label)[1]
def ledger(label,rep,rc,seconds):
 p=pathlib.Path(r'C:\tl-win\do-luong.csv');exists=p.exists() and p.stat().st_size>0
 with p.open('a',encoding='utf-8',newline='') as f:
  w=csv.writer(f)
  if not exists:w.writerow(['thoi_diem','session','packet','sha','bo_test','dat','tong','ca_do','thoi_luong_s','phat_hien_boi','loi_that','da_va','ghi_chu'])
  w.writerow([now().isoformat(),SID,'wp1296',M['baseline'] if label.startswith('baseline') else (M['old_h3'] if label.startswith('old-h3') else M['candidate']),label,rep.get('passed',0),rep.get('total',0),'|'.join(rep.get('failed_ids',[])),seconds,'focused-local','not_classified','no',f'may=DESKTOP-T9R33P2;device=a5f7076e-a491-4f84-829b-8d1fbcc1c767;ngat=khong;rc={rc}'])
def files(repo):return {str(p.relative_to(repo)).replace(chr(92),'/'):sha(p) for p in repo.rglob('*') if p.is_file() and '.git' not in p.relative_to(repo).parts}

def acquire():
 global lockfile,taken
 k=ctypes.WinDLL('kernel32',use_last_error=True);k.CreateFileW.restype=ctypes.c_void_p;k.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p]
 h=k.CreateFileW(str(LOCK),0x80000000|0x40000000,1,None,4,0x80,None)
 if h==ctypes.c_void_p(-1).value:raise OSError(ctypes.get_last_error(),'native lock busy/unavailable')
 fd=msvcrt.open_osfhandle(h,os.O_RDWR|os.O_BINARY);lockfile=os.fdopen(fd,'r+',encoding='utf-8-sig',newline='');before=lockfile.read();assert not before.strip(),'foreign machine-lock owner';taken=True;lockwrite(SID+'\tBOOTSTRAP\n');return before


def main():
 global start,thread
 assert os.name=='nt' and not W.exists(),'wrongOS or existingevidence; do not repeat'
 W.mkdir(parents=True)
 for n in ['logs','reports','scratch','harness','operator-inputs','evidence']:(W/n).mkdir()
 env=os.environ.copy()
 for k in list(env):
  if k.startswith('TL_') or k in ['GH_TOKEN','GITHUB_TOKEN','GITHUB_PAT','CODEX_AUTH_JSON','CLAUDE_CODE_OAUTH_TOKEN','OPENAI_API_KEY','ANTHROPIC_API_KEY','PROXIMA_API_KEY']:env.pop(k,None)
 env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',POWERSHELL_TELEMETRY_OPTOUT='1')
 pre="$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';$env:PSModulePath=(Join-Path $PSHOME 'Modules')+';C:\\Program Files\\WindowsPowerShell\\Modules';"
 probe=pre+"[pscustomobject]@{host=$env:COMPUTERNAME;service=@(Get-CimInstance Win32_Service -Filter \"Name='ProximaGateway'\").Count;process=@(Get-CimInstance Win32_Process -Filter \"Name='Proxima.exe'\").Count;python=@(Get-CimInstance Win32_Process -Filter \"Name='python.exe'\"|Select-Object ProcessId,ParentProcessId,CreationDate,ExecutablePath);policy=@(Get-ExecutionPolicy -List)}|ConvertTo-Json -Depth 5 -Compress"
 _,out=run([PS51,'-NoProfile','-NonInteractive','-Command',probe],'host-before',env=env);host=json.loads(out);save(W/'host-before.json',host);assert host['host']=='DESKTOP-T9R33P2' and host['service']==host['process']==0
 assert all(str(p['ExecutionPolicy']) in ['5','Undefined'] for p in host['policy'] if str(p['Scope']) in ['4','3','MachinePolicy','UserPolicy'])
 start=now();before=acquire();save(W/'lock-acquisition.json',{'session':SID,'before':before,'at':start.isoformat()});beat();thread=threading.Thread(target=heart,daemon=True);thread.start()
 base=I/'base';cand=I/'candidate'
 for root,key in [(base,'base_files'),(cand,'candidate_files')]:
  assert files(root)==M[key],('sourceexportmismatch',key)
 shutil.copyfile(__file__,W/'operator-inputs/controller.py');shutil.copyfile(I/'manifest.json',W/'operator-inputs/manifest.json')
 shutil.copytree(base,W/'operator-inputs/base');shutil.copytree(cand,W/'operator-inputs/candidate')
 common=W/'harness/ProximaManifest.Tests.ps1';shutil.copyfile(cand/MT,common);legacy=W/'harness/ProximaControl.Tests.ps1';shutil.copyfile(cand/TEST,legacy)
 rollback=W/'harness/rollback-requirements-only.ps1';text=common.read_text(encoding='utf-8-sig');anchor='    Assert-NoScriptRequirements $ast';assert text.count(anchor)==1;rollback.write_text(text.replace(anchor,'    # operator private rollback: requirements call intentionally removed'),encoding='utf-8')
 save(W/'rollback-only.json',{'source':sha(common),'mutant':sha(rollback),'anchor':anchor,'replacement':'only guard call removed; other AST guards retained'})
 def pq(v):return "'"+str(v).replace("'","''")+"'"
 def phase(label,exe,psid,source,harness=None,prefix='',culture='en-US',shape=None,cx=False,old=False):
  d=W/'scratch'/label;d.mkdir();addon=d/'addon';shutil.copytree(source/'.agents/skills/proxima-control',addon);mf=addon/'scripts/ProximaControl.psd1';orig=mf.read_text(encoding='utf-8-sig')
  changed=prefix+orig
  if shape:changed=orig.rstrip()+' &\n' if shape=='background' else 'end {\n'+orig+'\n}\n'+("clean { 'WP1296_CLEAN_CONTROL' }\n" if shape=='end-clean' else '')
  if prefix or shape:mf.write_text(changed,encoding='utf-8')
  rp=W/'reports'/(label+'.json');ap=W/'reports'/(label+'-parser.json');pe=env.copy();pe['PSModulePath']=str(pathlib.Path(exe).parent/'Modules')+r';C:\Program Files\WindowsPowerShell\Modules';pe['TEMP']=pe['TMP']=str(d);pe['PSModuleAnalysisCachePath']=str(d/'ModuleAnalysisCache')
  if old:
   ev=W/'evidence'/label;ev.mkdir();args=[exe,'-NoProfile','-NonInteractive','-ExecutionPolicy','RemoteSigned','-File',str(legacy),'-ModulePath',str(addon/'scripts/ProximaControl.psm1'),'-ScratchRoot',str(d),'-ReportPath',str(rp),'-EvidenceRoot',str(ev),'-TestCulture',culture]
  else:
   h=harness or common
   script=pre+"[Threading.Thread]::CurrentThread.CurrentCulture=[Globalization.CultureInfo]::GetCultureInfo("+pq(culture)+");[Threading.Thread]::CurrentThread.CurrentUICulture=[Globalization.CultureInfo]::GetCultureInfo("+pq(culture)+");$tk=$null;$er=$null;$ast=[System.Management.Automation.Language.Parser]::ParseFile("+pq(mf)+",[ref]$tk,[ref]$er);[pscustomobject]@{culture=[Globalization.CultureInfo]::CurrentCulture.Name;PSVersion=$PSVersionTable.PSVersion.ToString();errors=@($er|ForEach-Object{$_.Message});requirements=$ast.ScriptRequirements}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "+pq(ap)+" -Encoding UTF8;& "+pq(h)+" -AddonRoot "+pq(addon)+" -ScratchRoot "+pq(d)+" -ReportPath "+pq(rp)+( ' -Counterexamples' if cx else '')+";exit $LASTEXITCODE"
   launch=W/'harness'/(label+'.ps1');launch.write_text(script,encoding='utf-8-sig');args=[exe,'-NoProfile','-NonInteractive','-ExecutionPolicy','RemoteSigned','-File',str(launch)]
  rc,_=run(args,label,env=pe,timeout=180,check=False);assert rp.exists(),('REPORT_ABSENT',label);rr=json.loads(rp.read_text(encoding='utf-8-sig'));assert rr['setup_error'] is None,(label,rr['setup_error'])
  ar=json.loads(ap.read_text(encoding='utf-8-sig')) if ap.exists() else None;row={'rc':rc,'report':rr,'parser':ar,'culture':culture,'shell':psid,'source_harness_sha256':sha(harness or common) if not old else sha(legacy),'manifest_sha256':sha(mf),'prefix':prefix,'shape':shape};phases[label]=row;ledger(label,rr,rc,results[-1]['seconds']);save(W/'phase-progress.json',{'phases':phases,'commands':results});return row
 def pm(row,id):return next(x for x in row['report']['cases'] if x['id']==id)
 def reject(row,semantic=True):
  rr=row['report'];reason=pm(row,'PM01')['reason'];assert row['rc']==1 and pm(row,'PM01')['outcome']=='failed' and rr['runtime_children']==0 and pm(row,'PM04')['reason'].startswith('NOT_EXECUTED:'),(reason,rr)
  assert reason.startswith('EXECUTABLE_STATEMENT:') if semantic else reason.startswith(('EXECUTABLE_STATEMENT:','PARSE_ERROR:'))
 directives=[('version-lower','#requires -Version 5.1\n'),('version-upper','#REQUIRES -Version 5.1\n'),('version-mixed','#ReQuIrEs -Version 5.1\n'),('version-zero','#requires -Version 0.0\n'),('modules','#requires -Modules Microsoft.PowerShell.Management\n'),('assemblies','#requires -Assembly System.Xml\n'),('elevation','#requires -RunAsAdministrator\n'),('edition','#requires -PSEdition Core\n'),('shellid','#requires -ShellId Microsoft.PowerShell\n'),('snapin','#requires -PSSnapin Microsoft.PowerShell.Core\n')]
 for psid,exe in [('ps51',PS51),('ps7',PS7)]:
  q=phase('normal-'+psid,exe,psid,cand);assert q['rc']==0 and q['report']['passed']==q['report']['total']==7
  q=phase('CX-'+psid,exe,psid,cand,cx=True);assert q['rc']==0 and q['report']['passed']==q['report']['total']==12 and all(c.get('credited') is True for c in q['report'].get('counterexamples',[]) if c['id']!='CX00')
  q=phase('legacy-'+psid,exe,psid,cand,old=True);assert q['rc']==0 and q['report']['passed']==q['report']['total']==26
  for culture in ['en-US','tr-TR','az-Latn-AZ']:
   q=phase('comment-'+culture+'-'+psid,exe,psid,cand,prefix='# Requires the S2 hash guard\n',culture=culture);assert q['rc']==0 and q['report']['passed']==q['report']['total']==7
   for name,prefix in directives:
    q=phase(name+'-'+culture+'-'+psid,exe,psid,cand,prefix=prefix,culture=culture);reject(q,semantic=not q['parser']['errors'])
  q=phase('malformed-'+psid,exe,psid,cand,prefix='#requiresX\n');reject(q,semantic=False);assert pm(q,'PM01')['reason'].startswith('PARSE_ERROR:')
  for shape in ['named-end','end-clean','background']:
   q=phase('historical-'+shape+'-'+psid,exe,psid,cand,shape=shape);reject(q,semantic=not q['parser']['errors'])
  q=phase('baseline-comment-'+psid,exe,psid,base,harness=base/MT,prefix='# Requires the S2 hash guard\n');reject(q)
  for culture in ['tr-TR','az-Latn-AZ']:
   q=phase('baseline-upper-'+culture+'-'+psid,exe,psid,base,harness=base/MT,prefix='#REQUIRES -Version 5.1\n',culture=culture);assert q['rc']==0 and q['report']['passed']==7 and q['report']['runtime_children']==2
  q=phase('rollback-'+psid,exe,psid,cand,harness=rollback,prefix='#REQUIRES -Version 5.1\n',culture='tr-TR');assert pm(q,'PM01')['outcome']=='passed' and q['report']['runtime_children']==2
 assert files(base)==M['base_files'] and files(cand)==M['candidate_files'];_,out=run([PS51,'-NoProfile','-NonInteractive','-Command',probe],'host-after',env=env);hostafter=json.loads(out);save(W/'host-after.json',hostafter);assert hostafter['service']==hostafter['process']==0
 save(W/'measurement.json',{'candidate':M['candidate'],'baseline':M['baseline'],'source_export':'Gitcommitted scopedbytes with filehashmanifest; not a nativefullGitcheckout','phases':phases,'commands':results,'originals_unchanged':True,'passed':True,'no_network_inference_activation':True,'finished':now().isoformat()});return 0

rc=2
try:rc=main()
except BaseException as e:
 if W.exists():save(W/'operator-failure.json',{'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc(),'commands':results,'phases':phases,'at':now().isoformat()})
 say({'operator_error':str(e)});rc=2
finally:
 stop.set()
 if thread:thread.join(timeout=5)
 if taken:
  try:
   assert own();lockwrite('');save(W/'lock-release.json',{'session':SID,'released':True,'at':now().isoformat(),'after':LOCK.read_text(encoding='utf-8-sig')})
  except Exception as e:
   if W.exists():save(W/'lock-release-error.json',{'error':str(e)});rc=2
 if lockfile:lockfile.close()
 if W.exists():
  save(W/'terminal.json',{'rc':rc,'at':now().isoformat(),'candidate':M['candidate'],'phase_count':len(phases)})
  # Archive only declared operator/evidence/retained fixture inputs; sparse cloned source bytes are small and retained, .git excluded.
  manifest={str(p.relative_to(W)).replace('\\','/'):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(W.rglob('*')) if p.is_file() and '.git' not in p.relative_to(W).parts and p.name!='source-byte-manifest.json'};save(W/'source-byte-manifest.json',manifest);z=W.parent/(W.name+'-evidence.zip')
  with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as zz:
   for p in sorted(W.rglob('*')):
    if p.is_file() and '.git' not in p.relative_to(W).parts:zz.write(p,str(p.relative_to(W)).replace('\\','/'))
  raw=base64.b64encode(z.read_bytes()).decode();b64=z.with_suffix(z.suffix+'.b64');b64.write_text('\n'.join(raw[i:i+4096] for i in range(0,len(raw),4096)),encoding='ascii')
  save(W.parent/(W.name+'-archive.json'),{'zip':str(z),'bytes':z.stat().st_size,'sha256':sha(z),'b64':str(b64),'base64_bytes':len(raw),'source_files':len(manifest),'rc':rc});say({'terminal_rc':rc,'archive':str(z),'sha256':sha(z),'source_files':len(manifest)})
sys.exit(rc)
