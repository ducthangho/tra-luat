from common import *
import zipfile,concurrent.futures
assert not git('status','--porcelain')
pr=api('repos/ducthangho/tra-luat/pulls/1294');save(W/'PR-merged-readback.json',pr);assert pr['merged'] and pr['merge_commit_sha']==M and pr['head']['sha']==H
assert git('show','-s','--format=%P',M).split()==[D,H] and git('rev-parse',M+'^{tree}')=='f20cb1aa78756ae0a0b818c34e8d90f152b06a2f'
assert M in git('rev-list','--first-parent','origin/master').splitlines()
save(W/'merge-identity.json',{'at':now(),'merge_commit':M,'parents':[D,H],'tree':git('rev-parse',M+'^{tree}'),'head':H,'merged':True,'landed':False})
rid=42564993334;r=api(f'repos/ducthangho/tra-luat/actions/runs/{rid}');save(W/'run.json',r);assert r['event']=='push' and r['head_sha']==M and r['conclusion']=='success'
pages=api(f'repos/ducthangho/tra-luat/actions/runs/{rid}/attempts/{r["run_attempt"]}/jobs?per_page=100',True);save(W/'jobs-pages.json',pages);jobs=[j for p in pages for j in p['jobs']];assert len(jobs)==23 and all(j['conclusion']=='success' and 'ubuntu-latest' in j['labels'] for j in jobs)
L=W/'MCI-job-logs';L.mkdir();rawdir=W/'MCI-job-logs-raw';rawdir.mkdir()
def get(j):
 raw=subprocess.check_output([GH,'api',f'repos/ducthangho/tra-luat/actions/jobs/{j["id"]}/logs'],env=env,timeout=180);t=raw.decode('utf-8');assert t.encode()==raw;(rawdir/(str(j['id'])+'.log')).write_bytes(raw);save(L/(str(j['id'])+'.json'),{'repository':'ducthangho/tra-luat','job_id':j['id'],'content':t,'raw_sha256':hashlib.sha256(raw).hexdigest(),'transport':'Official gh REST; raw original bytes retained'});return {'name':j['name'],'bytes':len(raw)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for row in ex.map(get,jobs):print(json.dumps(row),flush=True)
arts=api(f'repos/ducthangho/tra-luat/actions/runs/{rid}/artifacts?per_page=100',True);save(W/'artifacts-pages.json',arts);a=[x for p in arts for x in p['artifacts'] if x['name']=='gate-evidence-ubuntu-latest-'+str(r['run_attempt'])];assert len(a)==1 and not a[0]['expired'];a=a[0]
z=W/'MCI-official-artifact.zip';z.write_bytes(subprocess.check_output([GH,'api',f'repos/ducthangho/tra-luat/actions/artifacts/{a["id"]}/zip'],env=env,timeout=180));assert a['digest']=='sha256:'+sha(z);save(W/'MCI-official-artifact-metadata.json',a)
q=subprocess.run([sys.executable,'-B',str(P/'ops/ci_provenance.py'),'do-wd','--repo','ducthangho/tra-luat','--run',str(rid),'--out',str(W/'MCI-WD.json')],cwd=P,env=env,capture_output=True);(W/'WD.stdout').write_bytes(q.stdout);(W/'WD.stderr').write_bytes(q.stderr);assert q.returncode==0,(q.stdout,q.stderr)
src=Path('/workspace/scratch/proxima-rest-20261108/collect-S3-CI-final-evidence.py');s=src.read_text();assert sha(src)=='85b968682976f22f02d919ab8c74fb5d552ea6b46f539653789b889cc6d6967b'
s=s.replace("S=pathlib.Path('/workspace/scratch/proxima-rest-20261108')","S=pathlib.Path('/workspace/scratch/wp1285-land-cloud-recovery')").replace('GitHub plugin decoded logs; original remote raw-byte identity not independently asserted','Official gh REST decoded UTF8, original bytes separately retained and hashed')
(W/'collector.py').write_text(s);save(W/'collector-adaptation.json',{'original_sha256':sha(src),'adapted_sha256':sha(W/'collector.py'),'changes':'Scratch path, official gh transport executable and accurate transport label only; unmodified canonical ci_provenance.py consumer'})
q=subprocess.run([sys.executable,'-B',str(W/'collector.py'),str(rid),M,'MCI-final','MCI-job-logs','MCI-WD.json','MCI-official-artifact.zip'],cwd=P,env=env,capture_output=True);(W/'collector.stdout').write_bytes(q.stdout);(W/'collector.stderr').write_bytes(q.stderr);assert q.returncode==0,(q.stdout[-1200:],q.stderr[-1200:])
v=json.loads((W/'MCI-final/validation.json').read_text());assert v['api_head']==v['actual_checkout']==M and v['jobs_total']==23 and v['positive_output']=='1777/1777'
save(W/'MCI-final-source-ready.json',{'run_id':rid,'head':M,'source_ready':True,'jobs':23,'official_artifact_sha256':sha(z),'full_source_AUX':'pending','landed':False,'at':now()});print('SOURCE_READY_AUX_PENDING',flush=True)
