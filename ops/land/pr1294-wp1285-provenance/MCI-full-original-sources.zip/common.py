from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,importlib.util
sys.dont_write_bytecode=True
W=Path('/workspace/scratch/wp1285-land-cloud-recovery');P=Path('/workspace/scratch/wp1285-spec-publish');MIRROR=Path('/workspace/scratch/proxima-p1-s2-20261108/holder-cache.git')
GIT='/usr/bin/git';GH='/workspace/scratch/proxima-p0-tools/gh';H='ecd8cee3ea6da6513a37a9b9aa6c9db65472e41c';E='eefce7fe828a68a13b4b7e3b1e17c1ddb2b6deee';D='4068b3a2a0087db287ea979eccbd372a7a0938d7';M='91be484a05ab40adf6573f11ef6ec0264fc9a3aa'
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',GIT_TERMINAL_PROMPT='0',GH_PROMPT_DISABLED='1')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def git(*a,repo=P):return subprocess.check_output([GIT,'-C',str(repo),*a],env=env,text=True,encoding='utf-8',timeout=120).strip()
def gitb(*a,repo=P):return subprocess.check_output([GIT,'-C',str(repo),*a],env=env,timeout=120)
def api(ep,pages=False):return json.loads(subprocess.check_output([GH,'api']+(['--paginate','--slurp'] if pages else [])+[ep],env=env,timeout=180))
def load_module(n,p):
 sp=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
