from common import *
rid=42564993334
assert len(list((W/'MCI-job-logs').glob('*.json')))==23
arts=api(f'repos/ducthangho/tra-luat/actions/runs/{rid}/artifacts?per_page=100',True);save(W/'artifacts-pages.json',arts);a=[x for p in arts for x in p['artifacts'] if x['id']==13651227268];assert len(a)==1 and a[0]['digest']=='sha256:'+sha(W/'MCI-official-artifact.zip');save(W/'MCI-official-artifact-metadata.json',a[0])
q=subprocess.run([sys.executable,'-B',str(P/'ops/ci_provenance.py'),'do-wd','--repo','ducthangho/tra-luat','--run',str(rid),'--out',str(W/'MCI-WD.json')],cwd=P,env=env,capture_output=True);(W/'WD.stdout').write_bytes(q.stdout);(W/'WD.stderr').write_bytes(q.stderr);assert q.returncode==0,(q.stdout,q.stderr)
src=Path('/workspace/scratch/proxima-rest-20261108/collect-S3-CI-final-evidence.py');assert sha(src)=='85b968682976f22f02d919ab8c74fb5d552ea6b46f539653789b889cc6d6967b'
s=src.read_text().replace("S=pathlib.Path('/workspace/scratch/proxima-rest-20261108')","S=pathlib.Path('/workspace/scratch/wp1285-land-cloud-recovery')")
(W/'collector.py').write_text(s);save(W/'collector-adaptation.json',{'original_sha256':sha(src),'adapted_sha256':sha(W/'collector.py'),'changes':'Scratch path only. GitHub plugin decoded full logs transport; remote raw-byte identity not asserted. Official ZIP SHA matches API. Canonical consumer unmodified.'})
q=subprocess.run([sys.executable,'-B',str(W/'collector.py'),str(rid),M,'MCI-final','MCI-job-logs','MCI-WD.json','MCI-official-artifact.zip'],cwd=P,env=env,capture_output=True);(W/'collector.stdout').write_bytes(q.stdout);(W/'collector.stderr').write_bytes(q.stderr);assert q.returncode==0,(q.stdout[-1200:],q.stderr[-1200:])
v=json.loads((W/'MCI-final/validation.json').read_text());assert v['api_head']==v['actual_checkout']==M and v['jobs_total']==23 and v['positive_output']=='1777/1777'
save(W/'MCI-final-source-ready.json',{'run_id':rid,'head':M,'source_ready':True,'jobs':23,'official_artifact_sha256':sha(W/'MCI-official-artifact.zip'),'full_source_AUX':'pending','landed':False,'at':now()});print('SOURCE_READY_AUX_PENDING',flush=True)
