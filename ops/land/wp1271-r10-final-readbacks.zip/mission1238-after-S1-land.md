# PROXIMA-PLAYWRIGHT — Mission đang thực hiện

**Trạng thái: in_progress. P0 và P1-S1 đã landed; Mission tổng thể chưa complete.** [Packet1239](https://github.com/ducthangho/tra-luat/issues/1239) hoàn tất tại mergecommit `132d376cbbfea0692ff6db284753b33f437c637a`, tree `539a02f355c4ade3cee7c99efa327a4a729e79bb`. [M8 authoritative](https://github.com/ducthangho/tra-luat/issues/1239#issuecomment-6705526770) post/readback đúng; D1–D4rc0, lease không còn holder. [CI canonical](https://github.com/ducthangho/tra-luat/actions/runs/42358749773) SUCCESS23/23Ubuntu jobs; selftest1777/1777 có exactM runtime receipt.

P0 cung cấp tài liệu kế hoạch/khảo sát và thiết kế; P1-S1 bổ sung nền đọc/kiểm tra config Proxima tách biệt, chưa expose runtime. Các unknown/gate cho P1–P6 giữ nguyên trong báo cáo; Proxima/Playwright chưa được cài/kích hoạt/deploy bởi Mission này. Các phase sau cần Packet/lease/authority riêng, không tự mở bằng việc hoàn tất P0. Các owner waiver F1/F2/K3/K4 chỉ áp dụng candidateP0 đã duyệt, không thành ngoại lệ chung.

## Đầu vào
Kế hoạch cuối v1.0 ngày 05/11/2026 trong chat “Thiết lập Proxima Control”, turn 01a1ac24-09e7-7207-bbdf-0a0c4bdb51ce. Bản nguyên văn lưu ngoài repo, SHA256 UTF-8/LF: `5c0c1fa6ad465eaf2037031b79e05f3740118dbbe01fc48ce8278f27f6db9ebb`. Bản trong Git chỉ trở thành nguồn chính thức sau Packet tài liệu hợp lệ.

## Outcome và bất biến
Hai add-on tùy chọn tại `.agents/skills/proxima-control/` và `.agents/skills/playwright-browser/`; bốn tổ hợp none/Proxima/Playwright/both đều giữ core hoạt động. Desktop thử trước → ASUS → VM; VM giữ gateway hiện hữu. Mỗi máy/tài khoản có config và profile riêng ngoài Git. Mutation phải chỉ rõ target; không tự fallback hoặc retry inference. Healthcheck không inference. Claude ưu tiên Executor; Codex review độc lập trên exact head/tree theo protocol.

## Đồ thị dự kiến
- P0: **landed/hoàn tất ghi sổ**, Packet #1239 đóng theo M8; hai tài liệu kế hoạch/khảo sát vào canonical.
- P1-S1: **landed**, Packet #1271, PR #1276, exact merge `efebadf83409a81e42e6c97f1b7255ede76110f5`; strict config reader + sample placeholder + native harness. [M8 authoritative](https://github.com/ducthangho/tra-luat/issues/1271#issuecomment-6714823786) đã post/readback khớp; D1–D4 rc0, lease g10 retired. [Canonical CI](https://github.com/ducthangho/tra-luat/actions/runs/42424728996) SUCCESS23/23Ubuntu,1777/1777, bốn source anchors qua audit độc lập.
- P1-S2/S3 còn mở: Proxima control, WhatIf/ShouldProcess/target/version và publication; chưa có assignment/lease tự động.
- P2 sau P0: Playwright optional, CLI/MCP/library theo nhu cầu và compatibility lock đã test.
- P3 sau P1/P2: Desktop canary và luồng thu bằng chứng → tra-luat xác minh → Proxima khi được yêu cầu.
- P4 sau P0/P3: updater/rollback đã kiểm chứng, ưu tiên cơ chế upstream nếu đáp ứng.
- P5 sau P4: ASUS rồi VM, preflight từng máy.
- P6: review và bàn giao; không gọi Mission complete trước acceptance/readback.
Đây là phase graph đề xuất; chưa phải assignment cho các phase.

## Updater
Check release chính thức hằng ngày; pin runtime; staging ngoài repo; xác minh nguồn/artifact/dependency, idle + lock, snapshot profile khi đóng, Desktop canary/observation, promote đúng digest. Rollback cả binary và dữ liệu tương ứng; lỗi rollback thì pause và giữ recovery. Không cưỡng bức dừng job/browser. Không đủ provenance theo policy, quyền mới/UAC, migration không đảo được, relogin hoặc thiếu đĩa thì dừng trước activation. Chốt retention/soak sau số đo.

## Findings khảo sát sơ bộ — chưa phải nghiệm thu
- Cloud base/remote master đo 05/11: `fe84620f897913c7f6c2ce5a0c7316a49655e82f`, tree `9c5534209694e0a7d71cca91b874c053762106f1`, working tree sạch.
- ASUS canonical khác base (`757bde561d09738858506aecf5de2f050a5f0d5e`) và có untracked công việc khác; chưa sửa/pull/reset.
- ASUS D free 2,831,151,104 bytes lúc khảo sát; chưa chốt cache/retention tại D.
- Upstream Proxima commit `0e92241847c40d1c3b26b6785ab43dc8710888aa`, `electron/main-v2.cjs:16–17` bật autoDownload và autoInstallOnAppQuit; cần chứng minh kiểm soát updater tích hợp trước pin/canary.
- Latest observed: Proxima v5.5.0, Playwright v1.64.1, MCP v0.0.84, CLI v0.1.23. Chưa là bộ lock đã kiểm thử.
- LICENSE upstream giới hạn personal/non-commercial; xác minh fit trước rollout tổ chức. Session routing và API chính thức là hai đường khác nhau.
- Hai device IDs cùng tên VM tra-luat-win; chưa xác minh authoritative ID, chưa chạm gateway.

## Acceptance Mission
Optional isolation; WhatIf không side effect; đúng target; không secrets/profile vào Git; lock package/browser/cache nhất quán; source verification chặn artifact hỏng; busy/lock/file khóa/đĩa đầy xử lý; Desktop fail chặn promote; rollback binary/profile có Windows evidence; rollback fail không loop; healthcheck không inference; review exact SHA và các gate theo protocol.

## Authority và bước kế tiếp
Chủ kho đã ủy quyền toàn quyền triển khai trong hội thoại, được ghi bền tại Packet #1271 comment6708576608; exact-H merge/land authority comment6714107843. Không phải miễn gate/review hoặc quyền LIVE. Mọi successor vẫn cần Packet revision/spec/hash/generation, effective write set, budget, provider và lease hợp lệ trước ghi sản phẩm. S1 closure không tự cấp lease cho S2/S3/P2.

## Nguồn
https://github.com/Zen4-bit/Proxima
https://github.com/microsoft/playwright
https://github.com/microsoft/playwright-cli
https://github.com/microsoft/playwright-mcp
https://playwright.dev/docs/browsers

Provider dispatcher/Land Operator: openai_codex/codex_service/cloud/machine; không tự nhận là product Executor hoặc human auditor. P1-S1 actual Claude Code ghi sản phẩm, fresh Codex CLI review độc lập approve đúng H; chi tiết bằng chứng/giới hạn tại M8 Packet #1271. Các số đo khảo sát sơ bộ ở trên là lịch sử 05/11, không phải trạng thái máy hiện tại.
