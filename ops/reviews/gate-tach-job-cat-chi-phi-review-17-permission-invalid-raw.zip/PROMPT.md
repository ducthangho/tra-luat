Bạn là reviewer CLAUDE độc lập cho #463 lượt17, revision24/generation5, sensitive. Executor Codex gpt-6-astra/xhigh. Context mới; không đọc transcript/context executor. Đọc cross-review-SKILL.md cập nhật, CONTEXT/CLAUDE/protocol8/13, SPEC-r24.md, LEASE-r24.yaml, authority g5-resume-authority-response.json.
Exact reviewed_sha: 79b75cdb6cf2737c3bd911ee7313969c2cfce62e; tree: 41b49168ba2fc322d7bc42fbe9e0a11013049df7; base: bb7013c7669da19304a8769e5b25f8c1f8951e9c.
Sandbox: C:\Users\admin\.codex\visualizations\2026\09\13\01a098aa-a18c-7843-bdb6-3f2043f9d4d9\rv463-r17; cay-kho/ detached READ-ONLY cả lượt, không sửa rồi hoàn nguyên. Chỉ ghi VERDICT.md và scratch/ ngoài clone. Không đọc ngoài sandbox/home/transcript/cây executor; không mạng/GitHub/CI/fullgate/--chay/commit/push/merge. Python/Ruff/actionlint/Git Bash/PowerShell chỉ dùng kiểm targeted/parse-only; KHÔNG thực thi fixture hoặc installer; không cài tool.
Đầu lượt ghi VERDICT.md: verdict: changes_requested và reviewed_sha: 79b75cdb6cf2737c3bd911ee7313969c2cfce62e ở hai dòng đầu, đánh dấu placeholder. Cập nhật lệnh/output/kết luận sau từng phép đo; chốt cuối. Hạn90phút absolute theo launcher, không reset.

M7 do user chốt: chỉ lệnh cài trực tiếp YAML. Không chứng minh hidden script/python-c/env/runtime provenance. Opaque vẫn phải qua grammar; không dùng lỗi runtime thay kiểm miền. Đúng2paths, tối đa1000 additions. Không CI trước merge, CI/A1/A5 not_run (không pass/failed). User cho lặp sửa+Claude cross-review+đăng verdict tới approve, giữ lịch sử.
Ba lớp, mỗi lớp verdict riêng, hai trục Spec + Standards/Security:
1 installer/domain/invocation và job phụ;
2 lexer/structure/expansion/quoting/order/shell carrier;
3 consumer/spec/workflow/fixtures và khả năng fixture bắt mất chốt.
Approve tổng chỉ khi cả ba approve. Không đổi model/provider/hạ assurance.

R16 là verdict hợp lệ: changes_requested P1=0/P2=0/P3=2. Đọc prior-review-16-original.md và PRIOR_HUNT_INDEX, giữ stable slug/subtype:
F-A ruff-fixture-thieu-rang-chot-moi / bien-charset-pwsh-carrier: năm mutant nới bảng chữ cái sống, suite thiếu fixture cô lập. Cả năm đã đo witness end-to-end đổi màu (digit dùng 2fa.sh x).
F-B ruff-docstring-pwsh-carrier-rong-hon-hanh-vi: splitlines nhận NEL/LS/PS ngoài ASCII công bố. R16 đã tự đo PowerShell AST trên5.1/7.6.6, không có bypass installer, nhưng miền công bố sai.
R15 ba finding trước đã được R16 đo ĐÃ VÁ THẬT, giữ lịch sử. Addendum R15 IDENTITY-FAILED KHÔNG là verdict hiệu lực/không đóng finding. R16 main actual modelUsage fable5 hợp lệ, receipt đã đăng; Git chuẩn hoá CRLF→LF, raw bytes có archive bất biến. R24/g5 chỉ thay lease vì heartbeat quá hạn sau gián đoạn, candidate kế thừa exact ff146f16, không reset finding/attempt.

R17 delta chỉ Python, không hunk/prototype reviewer:
- Nhánh PowerShell dùng ranh giới LF tường minh, giữ semantics một LF cuối tùy chọn; rỗng/blank line không được nhận. NEL/LS/PS và ký tự khác ngoài alphabet bị từ chối. Docstring nói dòng LF.
- Fixture end-to-end cô lập dollar trần, quote kép không dollar, semicolon, block, chữ số đầu tên script; phủ thêm từng ký tự punctuation/DEL/non-ASCII, biên ký tự đầu/tail tên lệnh, toàn bộ separator splitlines, blank lines, đối chứng chữ ASCII/tab/LF/script. Hai shell pwsh và powershell. Không viết parser PowerShell tổng quát và không thay workflow.
- Giữ toàn bộ54 mutant R16, thêm mutant nới từng biên carrier/đổi lại splitlines; mỗi mutant phải đổi whole loi_ruff_ci + fixture LỌT + actual mainrc1. Khi main short-circuit do workflow đã đỏ, gọi phan_chung riêng và ghi fixture_run_separate; không lấy crash làm kill.

Executor đo trên frozen exactSHA: registry 671/671,21/21,launcher4/4,Ruff3/3; Ruff F/actionlint rc0; 87/87 semantic mutants. A8 949/1000, đúng2paths; workflow byte-identical3bbc6b46c2fb6066fa64088308ce30fe40f87aa5. Tự tái lập các số cần thiết; phương pháp EXECUTOR_MUTATION_METHOD.py.txt phải đổi ROOT sang clone và output sang scratch, tuyệt đối không chạy ghi cây executor.
Source/clone output registry normalized bằng nhau chỉ chứng minh check đó. Cached remote đầy đủ tên/OID, non-shallow. A9 live reviewer not_measured vì cấm mạng; executor đã đo duy nhất exec6 hai path sau cấp. Master c16bd3293a9d2dc7a8a789b99d77057cb02ce374, base bb7013c7669da19304a8769e5b25f8c1f8951e9c, integration master mới not_measured; không ngoại lệ merge.

ĐỐI CHIẾU từng finding trước: ĐÃ VÁ THẬT / VÁ HỜ / VÁ SINH LỖI MỚI / CHƯA VÁ, kèm tự đo. BẢNG SĂN >=6 hướng MỚI ĐỘC LẬP, >=2 mỗi lớp: giả thuyết+lệnh đã chạy+output thật+kết luận LỖI/KHÔNG PHẢI LỖI/KHÔNG ĐO ĐƯỢC. Replay/baseline/mutant cũ không tính mới; đối chiếu index. Đọc toàn delta và tương tác; clean có giá ngang finding. Không săn META cho đủ số. Finding phải nêu vị trí/nguyên nhân/phản chứng, hướng sửa cấp lớp, fixture/mutant/nguy cơ. Sensitive gate không patch-as-hint; scratch mutant được phép, clone không ghi.
Identity yêu cầu: anthropic_claude / claude-fable-5 / max / claude_code / machine/local. Actual modelUsage sẽ kiểm SAU run, không suy từ lời khai. Nếu approve, cross_approved chỉ code review exactSHA, không quyền merge/land. Verdict vận chuyển nguyên văn lên Issue463 (chưaPR), không GitHub native approval. Kiểm cuối HEAD/tree/status clone; sạch chỉ là phép đọc tại thời điểm đó. Trả ngắn verdict/exactSHA/counts/path.
