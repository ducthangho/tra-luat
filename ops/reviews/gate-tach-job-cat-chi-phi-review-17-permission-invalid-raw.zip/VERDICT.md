verdict: approve
reviewed_sha: 79b75cdb6cf2737c3bd911ee7313969c2cfce62e

> Trạng thái: **HOÀN TẤT** — hai dòng trên là canonical và ĐÃ CHỐT tại mục "KẾT LUẬN CUỐI".
> (Đầu lượt hai dòng ấy là placeholder `changes_requested` đúng quy trình; kết luận cuối là
> `approve` nên đã cập nhật MỘT lần khi đóng — nhật ký đo giữ nguyên bên dưới. P1=0 · P2=0 · P3=0.)
> Reviewer: CLAUDE độc lập — provider **anthropic_claude** · model **claude-fable-5** · effort **max**
> · surface **claude_code** · transport **machine/local**. #463 lượt 17, revision 24 / generation 5, sensitive.

## Trạng thái đo
- [x] Đọc cross-review-SKILL.md (bản cập nhật) · CONTEXT/CLAUDE · PROTOCOL §8 + §13 · SPEC-r24 · LEASE-r24 · g5-resume-authority-response · PRIOR_HUNT_INDEX · prior-review-16-original · delta-r16.patch · TOÀN delta mã và vùng tương tác
- [x] Đ0/Đ6: HEAD/tree/base clone khớp exact, porcelain 0 ở ĐẦU và CUỐI lượt
- [x] Đ1: A8 949/1000, đúng 2 path; workflow byte-identical freeze; delta r16→r17 CHỈ Python
- [x] Đ2: registry 671/671 · 21/21 · 4/4 · 3/3 · rc=0 — tự chạy, diff freeze/sandbox IDENTICAL; Ruff F rc=0; actionlint rc=0 (shellcheck CÓ MẶT)
- [x] Đ3: TÁI LẬP TRỌN 87 mutant — 87/87 GIẾT, per-mutant khớp executor TỪNG cái, đúng 1 fixture_run_separate
- [x] ĐỐI CHIẾU R16: F-A **ĐÃ VÁ THẬT** · F-B **ĐÃ VÁ THẬT** (bằng chứng tự đo, không nhận lời khai)
- [x] BẢNG SĂN 8 hướng MỚI độc lập (lớp 1: H3·H4 · lớp 2: H2·H7·H8 · lớp 3: H1·H5·H6) — 0 LỖI, 8 KHÔNG PHẢI LỖI
- [x] Chuỗi định danh: PROMPT/SPEC/lease/frozen khớp sha256 đủ 64 ký tự

## Nhật ký đo

### Đ0 — Identity clone (đo lúc mở phiên)
```
$ git rev-parse HEAD          → 79b75cdb6cf2737c3bd911ee7313969c2cfce62e  (KHỚP exact reviewed_sha)
$ git rev-parse "HEAD^{tree}" → 41b49168ba2fc322d7bc42fbe9e0a11013049df7  (KHỚP exact tree)
$ git status --porcelain      → 0 dòng (sạch)
$ git rev-list --max-parents=0 HEAD → 394e93468fc8d84ec20938e6df8fb7ab72b2cc37 (KHỚP --expected-root-commit)
```

### Đ1 — A8 + freeze workflow + delta
```
$ git diff --numstat bb7013c7..HEAD → 823+92 ci_dang_ky_test.py · 126+6 ci.yml ⇒ 949 additions, ĐÚNG 2 path (949 ≤ 1000 ✓)
$ git diff --numstat ff146f16..HEAD → 18+2 CHỈ .claude/dev/ci_dang_ky_test.py ⇒ delta R17 chỉ Python ✓
$ delta-r16.patch ≡ git diff ff146f16..HEAD (tự sinh, byte-equal 3346 = 3346) ✓
$ blob ci.yml @HEAD = @ff146f16 = @3bbc6b46(freeze) = cb025a5a704a8f73319fee4ddded0010678e8f02 ⇒ BYTE-IDENTICAL freeze ✓
  (3bbc6b46 là COMMIT freeze — head R10; giff --numstat 3bbc6b46..HEAD chỉ Python 636+191 ✓)
```

### Đ2 — Baseline suite + Ruff + actionlint (trên clone, KHÔNG --chay, KHÔNG CI)
```
$ python -X utf8 -B .claude/dev/ci_dang_ky_test.py (cwd=clone) → rc=0
  ĐĂNG KÝ: 21/21 · LAUNCHER WINDOWS: 4/4 · RUFF CI: 3/3 · PHẢN CHỨNG: 671/671 đỏ đúng · TỔNG: ĐẠT
  grep -c "ĐỘT BIẾN" = 671 — hai số dương BẰNG NHAU, không tin rc trần.
$ diff (r17-freeze-registry.txt trừ dòng rc) vs tự chạy → IDENTICAL (677 = 677 dòng); freeze ≡ sandbox-registry.txt (True)
$ ruff 0.15.15: check --no-cache --select F → All checks passed, rc=0
$ actionlint 1.7.7 (+shellcheck 0.9.0 CÓ MẶT — nền đo MẠNH) ci.yml → rc=0, 0 chẩn đoán
  khớp r17-freeze-{registry,ruff,actionlint}.txt và r17-targeted-summary.json
```

### Đ3 — TÁI LẬP 87 MUTANT (phương pháp EXECUTOR_MUTATION_METHOD.py.txt nguyên văn, chỉ thay neo:
ROOT ghim CLONE cay-kho, mọi artifact vào scratch/mutants-rv17; KHÔNG chạy path executor; KHÔNG ghi clone)
```
KILLED 87/87 — từng mutant: semantic_changed AND ≥1 fixture LỌT AND rc=1 AND "TỔNG: ĐỎ"
fixture_run_separate: đúng 1 — powershell-known-subset (main short-circuit vì ci.yml thật đỏ; phan_chung gọi riêng)
So mutation-r17.json executor: tập tên = nhau (87); (killed, semantic, separate, tập-fixture-LỌT) KHỚP TỪNG MUTANT — 0 lệch.
Đếm tập: 54 mutant R16 GIỮ NGUYÊN VĂN (khối case y hệt) + 33 MỚI (26 widen-arg + 4 widen-first + 2 widen-command + 1 splitlines-revert) = 87.
Bản đồ leak của 33 mutant mới: TẤT CẢ leak vào đúng họ shell-carrier-{alphabet,boundary}, mỗi mutant ≥1 fixture LỌT (H5).
Witness từng mutant mới: baseline 2 lỗi → mutant 0 lỗi qua CHÍNH loi_ruff_ci — semantic thật, không crash-credit.
Hiện vật: scratch/run_mutation_rv17.py · scratch/mutation-rv17.json · scratch/mutants-rv17/ (87×.py + 87×.txt + baseline)
```

### Đ4 — Chuỗi định danh
```
$ sha256(PROMPT.md) = fe779623… ≡ prompt.snapshot ≡ --expected-prompt-sha256 (launch-request.json) ✓
$ sha256(SPEC-r24.md) = 79ba77c35b74c86d0ccc5ad4c1a8ca27b6e53935222095adda016cba76edc121 ≡ spec_hash/spec_sha256 LEASE-r24 ≡ frozen-r17.spec_sha256 ✓
$ frozen-r17.json: head/tree/base/master/branch/additions 949/paths 2/fixtures 671/mutants 87/lease_id exec-6-r24 — TẤT CẢ khớp phép đo độc lập Đ0–Đ3 ✓
$ launch-request: claude-fable-5/max, --require-clean, deadline 02:51:51Z; reviewer-selection: bậc 6 → fable-5/max ✓
$ delivery-r16.json: R16 changes_requested @ff146f16 đã đăng (comment 5657654306) — khớp lịch sử lease/authority; addendum R15 IDENTITY-FAILED KHÔNG dùng làm căn cứ
$ r17-fence.json audit=passed; A9 executor khai unique_exec6_both — reviewer BỊ CẤM MẠNG ⇒ A9 live/refset/metadata_head: KHÔNG ĐO ĐƯỢC tại chỗ, chỉ ghi nhận
```

### Đ5 — Đọc toàn delta r16→r17 (3 hunk) + vùng tương tác
```
hunk 1 (_shell_trong_mien:470-472): splitlines() → body.split("\n") + pop MỘT LF cuối tùy chọn.
  Chứng minh THU HẸP NGHIÊM NGẶT (đọc code + đo): body được nhận ⇒ chỉ gồm ký tự alphabet + \n
  ⇒ splitlines cắt y hệt split("\n") trên body ấy ⇒ tập-được-nhận-mới ⊆ tập-cũ. KHÔNG có chiều fail-open.
  Rỗng/blank/ws-only bị từ chối ("" và " \t" trượt fullmatch — regex đòi [A-Za-z_] đầu từ).
hunk 2 (docstring :503): "invocation/line" → "invocation/dòng LF" — khớp hành vi mới (mọi byte ngoài
  ASCII-alphabet đều bị từ chối; mô hình dòng = LF, không còn là splitlines).
hunk 3 (phan_chung :1109-1122): 140 fixture mới = 2 shell × (63 âm + 7 dương); vị từ tiêu thụ
  `(_loi == 0) if _mong == 0 else (_loi >= 1)`; _them chặn trùng tên (suite qua ⇒ 0 trùng).
Tương tác đã soát: _doc_buoc_ruff (carrier chặn TRƯỚC, thân pwsh được nhận vẫn qua _dong_logic POSIX
  làm backstop) · registry flag -1 khi shell ngoài miền · bash/sh/không-khai KHÔNG đổi hành vi.
```

### Đ6 — Bất biến cuối lượt (đo SAU khi hoàn tất phép đo, trước khi chốt verdict)
```
$ git rev-parse HEAD          → 79b75cdb6cf2737c3bd911ee7313969c2cfce62e  (KHÔNG đổi)
$ git rev-parse "HEAD^{tree}" → 41b49168ba2fc322d7bc42fbe9e0a11013049df7  (KHÔNG đổi)
$ git status --porcelain | wc -l → 0 (sạch — trạng thái chỉ là phép đọc tại thời điểm đó)
Clone không bị ghi trong cả lượt: mutant/probe chạy trên BẢN SAO trong scratch/, ROOT ghim clone chỉ để ĐỌC; python -B.
```

---

## ĐỐI CHIẾU LƯỢT TRƯỚC (R16 — verdict hợp lệ: changes_requested P1=0/P2=0/P3=2)

| finding R16 | trạng thái | bằng chứng TỰ ĐO (không nhận lời khai executor) |
|---|---|---|
| F-A `ruff-fixture-thieu-rang-chot-moi`/bien-charset-pwsh-carrier [P3] — 5 mutant nới bảng chữ cái carrier sống 531/531, suite thiếu fixture cô lập | **ĐÃ VÁ THẬT** | Đ3 (rig của TÔI): cả 5 mutant R16 nêu đích danh nay BỊ GIẾT với leak cô lập ĐÚNG lớp — widen-arg-dollar → alphabet-{pwsh,powershell}-1-0/-1-9 (`echo $X`) · widen-arg-dquote → -1-1 (`echo "ok"`) · widen-arg-semicolon → -1-2 (`echo hi; wc`) · widen-arg-brace → -1-3/-27/-29 (`echo {x}`, `echo a{b`, `echo a}b`) · widen-first-digit → -1-4 và -1-34…43 (`2fa.sh x` + 10 chữ số mở đầu). Witness đổi màu 2→0 qua chính loi_ruff_ci, đúng dạng H5-R16. Hướng sửa R16 (mỗi LỚP một fixture âm, nhân đôi powershell) được thi công VƯỢT mức: 63 fixture âm/shell phủ trọn 28 ký tự punctuation/DEL/é/NBSP + 13 ký tự mở đầu + 3 ký tự đuôi-first-word + 9 separator + 4 blank-line, kèm 7 đối chứng dương/shell |
| F-B `ruff-docstring-pwsh-carrier-rong-hon-hanh-vi` [P3] — splitlines nhận NEL/LS/PS ngoài ASCII công bố | **ĐÃ VÁ THẬT** | Chiều CHẶN đúng như hướng sửa R16: ranh giới dòng CHỈ LF (delta hunk 1), NEL/LS/PS thành ngoài miền — H2 tự đo end-to-end: `echo hi\x85echo ok` và biến thể U+2028/U+2029 nay ≥1 lỗi (fixture alphabet -1-56/-57/-58, cả hai shell, ĐỎ đúng trên HEAD trong 671/671); mutant `powershell-unicode-splitlines` (đổi lại splitlines) BỊ GIẾT, leak ĐÚNG BA fixture ấy (Đ3). Docstring sửa "invocation/line" → "invocation/dòng LF" khớp hành vi (mọi byte ngoài ASCII bị từ chối — Đ5/H2). KHÔNG VÁ SINH LỖI MỚI: phép thu hẹp là subset nghiêm ngặt (chứng minh Đ5), đối chứng dương `echo hi\n` · `echo hi\necho ok\n` giữ 0 lỗi, RUFF CI thật 3/3, bước pwsh thật của ci.yml (dòng 240-241, một dòng alphabet) vẫn trong miền |

Cả hai finding đóng ĐÚNG HỢP ĐỒNG fixture/mutant mà R16 đòi: 5 mutant SỐNG → GIẾT, +1 mutant revert-splitlines, fixture LỌT thật, main rc=1 thật, không crash-credit (witness baseline 2→0 từng cái).

---

## BẢNG SĂN — 8 hướng MỚI độc lập (lớp 1: H3·H4 · lớp 2: H2·H7·H8 · lớp 3: H1·H5·H6)

Đối chiếu PRIOR_HUNT_INDEX.md: các bề mặt dưới đây (đóng/mở của bộ mutant theo ký tự tương-đương, bề mặt
chấp-nhận MỚI trailing-LF/multi-line, ground-truth AST trên tập được-nhận-mới, backtracking regex carrier,
phân hoạch 140 fixture, nghĩa vụ installer xuyên carrier ĐA DÒNG) không có trong R7–R16 (grep index:
"tương đương/trailing/CommandAst/backtracking" → 0 hướng cũ trùng). Replay Đ2/Đ3 KHÔNG tính vào N.
Script + JSON: `scratch/hunt_rv17.py` · `scratch/hunt-rv17.json` · `scratch/ps_probe_rv17.ps1` · `scratch/ps_probe_out_rv17_{51,7}.json`.

### H1 [LỚP 3] — ĐÓNG/MỞ của bộ mutant mới: 3 ký tự KHÔNG có mutant (`(` `)` `` ` ``) có phải lỗ răng? — KHÔNG PHẢI LỖI
giả thuyết : nếu widen-arg-( / ) / ` là mutant GIẾT ĐƯỢC mà executor bỏ sót thì lưới fixture thiếu răng đúng chỗ đó
lệnh       : tự dựng 3 mutant nới từng ký tự ấy vào arg-class (scratch/rv17-widen-{paren-open,paren-close,backtick}.py), đo loi_ruff_ci trên 40+ thân probe (kể cả dạng CÂN BẰNG `echo (x)` `echo a()b` ``echo `x` ``) + chạy TRỌN suite từng mutant
output     : cả 3 mutant: 0 flip trên toàn corpus, suite 671/671 rc=0 (SỐNG, không fixture nào LỌT)
kết luận   : KHÔNG PHẢI LỖI — ba mutant này TƯƠNG ĐƯƠNG NGỮ NGHĨA ở mức loi_ruff_ci, và tương đương có CHỨNG MINH CẤU TRÚC: thân qua carrier-nới không thể chứa quote/escape/# (ngoài alphabet), nên mọi `(` `)` `` ` `` tới POSIX backstop đều TRẦN → "ngoặc trần/backtick ngoài miền" → cùng KPT/-1 như khi carrier tự chặn → thông điệp lỗi Y HỆT. Bỏ chúng khỏi bộ 87 là ĐÚNG (doctrine: mutant sống ≠ test yếu). Đối chứng RĂNG cùng lệnh: mutant thứ 4 tự dựng widen-arg-NEL (\x85 vào arg-class — ký tự KHÔNG có trong bộ executor) → flip `echo hi\x85echo ok` 2→0, suite rc=1, LỌT đúng alphabet-1-56 cả hai shell ⇒ lưới fixture CÓ răng vượt ra ngoài chính bộ mutant executor chọn

### H2 [LỚP 2] — Biên chấp nhận MỚI của carrier LF: ws-line/CRLF/BOM/NBSP/LF-cuối — KHÔNG PHẢI LỖI
giả thuyết : nếu pop-LF-cuối hoặc split("\n") nhận nhầm dòng rỗng/ws/CR thì miền công bố sai chiều NHẬN
lệnh       : loi_ruff_ci end-to-end (fixture 3 bước chuẩn) trên 10 thân biên (scratch/hunt-rv17.json khóa H2)
output     : `echo hi\n \t\necho ok`→2 · `echo hi\n \t\n`→2 · `echo hi\r\necho ok`→2 · `echo hi\r\n`→2 · `echo hi\n\n`→2 · BOM+echo→2 · NBSP-đầu→2 || `echo hi\n`→0 · `echo hi\necho ok\n`→0 · `echo\t<toàn-alphabet-arg>`→0
kết luận   : KHÔNG PHẢI LỖI — đúng miền công bố: MỘT LF cuối tùy chọn, mọi dòng phải là invocation ASCII; dòng chỉ-whitespace (ca không có fixture riêng) vẫn bị chặn vì regex đòi từ đầu [A-Za-z_]; CRLF bị chặn vì \r ở lại TRONG dòng LF

### H3 [LỚP 1] — Nghĩa vụ installer XUYÊN bề mặt LF mới (đa dòng + LF cuối — dạng R16 chưa đo) — KHÔNG PHẢI LỖI
giả thuyết : nếu hợp đồng pin/probe/registry không hoàn tất được (hoặc hoàn tất NHẦM) qua carrier đa-dòng-LF-cuối thì M7 gãy trên bố cục pwsh thật
lệnh       : loi_ruff_ci trên: job pwsh trọn hợp đồng · sai pin · case-trap · uv pip · job phụ thiếu/đủ probe · defaults pwsh mức JOB và mức WORKFLOW cho TOÀN BỘ bước (kể cả _ruff/_reg thật)
output     : `pip install ruff==0.15.15\nruff --version\n`+reg→0 · sai pin 0.15.14→3 · `Pip …`→3 (KPT, không thành KHONG) · `uv pip …\n`→0 · phu pin-không-probe→1 lỗi nêu ĐÚNG `(job: ['phu'])` · phu đủ→0 · workflow-defaults-pwsh toàn bộ→0 · job-defaults-powershell toàn bộ→0
kết luận   : KHÔNG PHẢI LỖI — carrier đủ chỗ cho trọn hợp đồng M7 ở cả hai shell và cả ba tầng khai shell; nghĩa vụ giữ per-job; ngoài miền vẫn đỏ

### H4 [LỚP 1] — "Ngoài miền không thành KHONG" trên bề mặt mới + không đúc GHIM — KHÔNG PHẢI LỖI
giả thuyết : nếu một dạng installer lạ đi qua carrier rồi được KHONG-hóa (hoặc đúc GHIM) thì lớp nhận dạng họ installer thủng
lệnh       : loi_ruff_ci với pip.exe/-r requirements/global-opt/poetry/uninstall qua pwsh, mỗi dạng ở CÙNG job và ở JOB KHÁC; + _phan_loai_cai_ruff trực tiếp
output     : cả 5 dạng: cùng-job→1 · job-khác→2 (không dạng nào 0); _phan_loai_cai_ruff(pip.exe…)→KPT · (pip --quiet install…)→KPT
kết luận   : KHÔNG PHẢI LỖI — mọi dạng lạ đỏ ở mọi vị trí, không đường đúc GHIM, đúng chỉ thị lease "ngoài miền không được biến thành KHONG"

### H5 [LỚP 3] — Phân hoạch 140 fixture mới + bản đồ leak 33 mutant mới — KHÔNG PHẢI LỖI
giả thuyết : nếu đếm fixture không khớp cấu trúc vòng lặp, hoặc mutant mới leak vào fixture NGOÀI họ carrier, thì lời khai "cô lập từng lớp" sai
lệnh       : đếm từ suite output thật + soát mutation-rv17.json (của TÔI)
output     : alphabet = 140 dòng, 140 "ĐỎ đúng", 70/70 theo shell, 63 âm + 7 dương (pwsh); 671 − 531 = 140 ✓; 33/33 mutant mới leak CHỈ vào shell-carrier-{alphabet,boundary}, không mutant nào 0-leak
kết luận   : KHÔNG PHẢI LỖI — phân hoạch khớp từng con số; tên fixture không trùng (guard _them + suite ĐẠT)

### H6 [LỚP 3] — A7 + hai phản chứng trên ci.yml THẬT giữ màu qua delta — KHÔNG PHẢI LỖI
giả thuyết : nếu delta carrier làm đổi màu 4 fixture A7 hoặc 2 phản chứng pin/probe trên workflow thật thì tương thích-lùi M7 gãy
lệnh       : soát suite output các ca ruff-ci-{chua-tach-tuong-thich-lui,da-tach-dung,da-tach-thieu-ruff,da-tach-ruff-sau-registry} + ruff-pin-required + ruff-version-probe-required
output     : cả 6 "ĐỎ đúng" (đúng màu kỳ vọng từng ca, trong 671/671)
kết luận   : KHÔNG PHẢI LỖI — A7 nguyên màu, phản chứng trên chính ci.yml thật còn răng

### H7 [LỚP 2] — Độ phức tạp regex carrier trên input dài (parse-only) — KHÔNG PHẢI LỖI
giả thuyết : nếu `(?:[ \t]+[…]+)*` backtrack tổ hợp thì một thân pwsh dài làm bước test registry treo trên CI
lệnh       : đo perf_counter loi_ruff_ci với dòng 50k ký tự + NUL, 20k space + NUL, 10k từ xen kẽ + `!`
output     : 0.046s · 0.023s · 0.039s (đều trả 2 lỗi đúng)
kết luận   : KHÔNG PHẢI LỖI — các lớp ký tự kề nhau rời nhau nên không có nổ tổ hợp

### H8 [LỚP 2] — Ground truth PowerShell trên tập ĐƯỢC NHẬN MỚI (parse-only, cả 5.1 lẫn 7.6.6) — KHÔNG PHẢI LỖI
giả thuyết : nếu một thân được carrier mới cấp 0-lỗi mà PS parse ra statement KHÔNG-phải-invocation (hoặc parse error) thì câu "chỉ nhận invocation/dòng LF" sai với chính shell được nêu tên
lệnh       : ParseInput (ps_probe_rv17.ps1) trên 6 thân đại diện tập mới: đa dòng LF-cuối, tab full-alphabet-arg, dẫn whitespace, tên script có -/., pin+probe, registry — PS 5.1.26100.9278 VÀ pwsh 7.6.6
output     : 12/12 phép đo (6 thân × 2 phiên bản): n_parse_errors=0, MỌI statement là PipelineAst[CommandAst], số statement = số dòng LF (2/1/1/1/2/1)
kết luận   : KHÔNG PHẢI LỖI — mô hình "mỗi dòng LF một invocation" khớp AST của cả hai phiên bản PS bắt buộc trên đúng tập vừa được mở

---

## BẢNG ĐO — lời khai executor ↔ đo được (độc lập)
| khẳng định executor | đo được (reviewer) | khớp? |
|---|---|---|
| exact head/tree/base 79b75cdb…/41b49168…/bb7013c7… | rev-parse đầu VÀ cuối lượt, porcelain 0 cả hai lần | Có |
| A8 949/1000, đúng 2 path | numstat 823+126=949, đúng 2 path | Có |
| workflow byte-identical 3bbc6b46 | blob `cb025a5a70…` @HEAD = @ff146f16 = @freeze; delta sau freeze CHỈ Python | Có |
| registry 671/671 + 21/21 + 4/4 + 3/3, rc=0 | tự chạy KHÔNG `--chay`: y hệt; grep 671 = 671; diff freeze/sandbox: IDENTICAL | Có |
| Ruff F rc=0 · actionlint rc=0 | tự chạy: All checks passed (ruff 0.15.15) · rc=0 0 chẩn đoán (actionlint 1.7.7 + shellcheck 0.9.0 CÓ MẶT) | Có |
| 87/87 semantic mutants, fixture LỌT + main rc=1, separate cho ca short-circuit | tái lập TRỌN 87 trên clone: 87/87; (killed, semantic, separate, tập LỌT) khớp TỪNG mutant; đúng 1 separate (powershell-known-subset) | Có |
| Giữ toàn bộ 54 mutant R16 + mutant nới TỪNG biên carrier + revert splitlines | 54 case đầu giữ nguyên văn; 33 mới phủ 25 ký tự arg + 4 first-char + 2 command-tail + revert; 3 ký tự vắng mutant chứng minh TƯƠNG ĐƯƠNG (H1) | Có |
| Delta R17 chỉ Python, không hunk/prototype reviewer | delta-r16.patch ≡ tự sinh; 3 hunk thuần sản phẩm/fixture; KHÔNG hint_provenance cần khai (sensitive — R16 chỉ mô tả hướng bằng lời, đúng §8) | Có |
| spec_hash lease r24 · prompt sha256 | sha256 tự tính khớp đủ 64 ký tự cả hai | Có |
| A1/A5/A2/A6/CI · integration master mới | not_run / not_measured theo chỉ thị — KHÔNG đọc thành passed/failed; không ngoại lệ merge | Đúng trạng thái |
| A9 live · refset/metadata_head/master c16bd329 | reviewer bị cấm mạng ⇒ KHÔNG ĐO ĐƯỢC tại chỗ; chỉ ghi nhận executor khai unique_exec6_both + fence audit=passed | Đúng phạm vi |

## KẾT LUẬN THEO LỚP (trục Spec + Standards/Security cho từng lớp)
| lớp | verdict | căn cứ |
|---|---|---|
| 1. Installer/domain/invocation + job phụ | **approve** | Delta không đụng lớp nhận dạng; carrier CHỈ THU HẸP (chứng minh subset — Đ5) nên không mở đường cài mới; H3: trọn hợp đồng M7 đi qua carrier đa-dòng-LF ở cả ba tầng khai shell, nghĩa vụ per-job đúng chỗ; H4: 5 dạng ngoài miền đỏ ở mọi vị trí, không đúc GHIM, không KHONG-hóa |
| 2. Lexer/structure/expansion/quoting/order/shell carrier | **approve** | Ranh giới LF tường minh, một LF cuối tùy chọn, rỗng/blank/ws bị từ chối (H2); NEL/LS/PS/CR/C0/BOM/NBSP ngoài miền — F-B đóng theo chiều CHẶN; POSIX backstop giữ nguyên cho thân pwsh được nhận; ground truth AST cả 5.1 lẫn 7.6.6: tập được-nhận = thuần CommandAst theo dòng LF, 0 parse error (H8); không nổ backtracking (H7); bash/sh/không-khai không đổi hành vi |
| 3. Consumer/spec/workflow/fixtures | **approve** | Tiêu chí lớp ("fixture bắt được mất chốt") nay ĐẠT bằng phép đo: 87/87 mutant GIẾT trong rig của TÔI, leak cô lập đúng lớp ký tự; 140 fixture mới phủ trọn bảng chữ cái bị loại + separator + blank + đối chứng dương, 63+7 ×2 shell khớp 671−531; 3 ký tự không mutant là tương đương có chứng minh + lưới vẫn răng với ký tự ngoài bộ (widen-NEL tự dựng BỊ GIẾT — H1); A7 4 ca + 2 phản chứng ci.yml thật giữ màu (H6); workflow byte-identical freeze; A8 trong trần |

Approve tổng đòi CẢ BA lớp approve ⇒ **approve** (không hạ assurance, không đổi model/provider).

## KẾT LUẬN CUỐI (hai dòng đầu tệp là canonical và ĐÃ CHỐT — không còn là placeholder)
- verdict: **approve** · reviewed_sha `79b75cdb6cf2737c3bd911ee7313969c2cfce62e` (tree `41b49168ba2fc322d7bc42fbe9e0a11013049df7`).
- Findings: **P1=0 · P2=0 · P3=0.** Không finding hành vi, không finding lưới fixture, không finding công bố-miền trên HEAD này.
- Đối chiếu R16: F-A [P3] **ĐÃ VÁ THẬT** · F-B [P3] **ĐÃ VÁ THẬT** — cả 5 mutant sống của R16 + revert-splitlines nay CHẾT với leak cô lập đúng mệnh đề, tự đo trong rig reviewer; KHÔNG VÁ SINH LỖI MỚI (phép thu hẹp là subset nghiêm ngặt, đối chứng dương + A7 + workflow thật giữ màu).
- Bảng săn: 8 hướng mới (2 lớp-1 · 3 lớp-2 · 3 lớp-3), 4 mutant closure tự dựng (3 chứng minh tương đương + 1 chứng minh lưới còn răng ngoài bộ executor), 10 probe biên carrier, 12 phép đo AST hai phiên bản PS, 12 probe installer/aux-job, phân hoạch 140 fixture — **0 LỖI mới**; clean có bằng chứng chạy được từng hướng.
- **Phạm vi của approve này — nói tường minh:** `cross_approved` CHỈ là code review trên exact SHA `79b75cdb…`; KHÔNG mang quyền merge/land/deploy; KHÔNG thay các phép đo chưa chạy: **CI/A1/A2/A5/A6 not_run · A9-live/integration-master-mới not_measured** theo chỉ thị chủ kho (không CI trước merge) — các tiêu chí ấy vẫn phải đo đúng như SPEC-r24 quy định ở pha land, và `A1` có thể ĐỎ như một KẾT QUẢ ĐO. Verdict vận chuyển nguyên văn lên Issue #463 (chưa có PR), không phải GitHub native approval.
- Identity actual: provider **anthropic_claude** · model **claude-fable-5** · effort **max** · surface **claude_code** · transport **machine/local** — validator so `modelUsage` thô SAU run, không suy từ lời khai này.
- Bất biến cuối lượt (Đ6): clone HEAD/tree không đổi, porcelain 0 dòng; sạch chỉ là phép đọc tại thời điểm đó. Hiện vật reviewer: `VERDICT.md` + `scratch/` (suite-head-rv17.txt · run_mutation_rv17.py · mutation-rv17.json · mutation-rv17.out · mutants-rv17/ 87+1 tệp · hunt_rv17.py · hunt-rv17.json · rv17-widen-{paren-open,paren-close,backtick,nel}.py · ps_probe_rv17.ps1 · ps_probe_input_rv17.json · ps_probe_out_rv17_{51,7}.json · delta-check.patch) — TẤT CẢ NGOÀI clone.
