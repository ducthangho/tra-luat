import importlib.util,pathlib,unittest,io,contextlib,json
new=pathlib.Path('/workspace/local-gates-executor/.claude/dev/local_gate_checks.py');old=pathlib.Path('/workspace/argon-review-1003/.claude/dev/local_gate.py')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
checks=load('checks',new);checks.gate=load('oldgate',old);checks.RUNNER=old
names=['test_receipt_temp_symlink_is_not_followed','test_both_plans_run_behavior_checks','test_explicit_worker_tuning_and_isolated_temp']
report=[]
for name in names:
 output=io.StringIO()
 with contextlib.redirect_stdout(output):result=unittest.TextTestRunner(stream=output).run(checks.RunnerChecks(name))
 assert not result.wasSuccessful(),name+' unexpectedly passed on old code'
 report.append({'test':name,'against_sha':'c0b7711850ecee2e7165564df2f84cb92afe5fa0','expected':'red','testsRun':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'output':output.getvalue()})
pathlib.Path('/workspace/agy-preflight/extra-red-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps([{k:v for k,v in r.items() if k!='output'} for r in report],indent=2))
