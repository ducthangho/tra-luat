import importlib.util,pathlib,sys,json,os,signal
p=pathlib.Path('/workspace/local-gates-executor/.claude/dev/local_gate_checks.py');s=importlib.util.spec_from_file_location('checks',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
t=m.RunnerChecks();t.setUp();pid=None
try:
 pidfile=t.base/'orphan.pid'
 child=f'import os,time; from pathlib import Path; Path({str(pidfile)!r}).write_text(str(os.getpid())); time.sleep(60)'
 t.make_plan(f'import subprocess,sys,time; subprocess.Popen([sys.executable,"-c",{child!r}],start_new_session=True); time.sleep(.2); print("POSITIVE")')
 rc=t.run_gate();pid=int(pidfile.read_text());alive=t.process_alive(pid)
 result={'run_rc':rc,'orphan_alive_after_root_success':alive,'cleanup_complete':json.loads((t.out/'receipt.json').read_text())['steps'][0]['cleanup_complete']}
 assert rc==0 and not alive
 pathlib.Path('/workspace/agy-preflight/orphan-exit-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:
 if pid and t.process_alive(pid):os.kill(pid,signal.SIGKILL)
 t.doCleanups()
