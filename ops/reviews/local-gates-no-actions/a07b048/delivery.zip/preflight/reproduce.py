import importlib.util,json,os,pathlib,signal,subprocess,sys,tempfile,time
p=pathlib.Path('/workspace/argon-review-1003/.claude/dev/local_gate_checks.py')
s=importlib.util.spec_from_file_location('checks',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
results={}
for field,value in [('approval',True),('full_ci_equivalence',True),('checkout_unchanged','false'),('tree','invalid')]:
 t=m.RunnerChecks();t.setUp()
 try:
  assert t.run_gate()==0
  r=json.loads((t.out/'receipt.json').read_text());r[field]=value;(t.out/'receipt.json').write_text(json.dumps(r))
  results['F01_'+field]={'verify_rc':m.gate.verify(t.out,t.head,t.plan),'tampered_value':value}
 finally:t.doCleanups()
t=m.RunnerChecks();t.setUp()
try:
 (t.root/'.gitignore').write_text('ignored/\n');t.git('add','.gitignore');t.git('-c','user.name=test','-c','user.email=t@example.invalid','-c','commit.gpgsign=false','commit','-qm','ignore');t.head=t.git('rev-parse','HEAD').strip()
 t.make_plan('from pathlib import Path; Path("ignored").mkdir(); Path("ignored/output").write_text("mutation"); print("POSITIVE")')
 rc=t.run_gate();results['F02']={'run_rc':rc,'ignored_write_exists':(t.root/'ignored/output').exists(),'checkout_unchanged':json.loads((t.out/'receipt.json').read_text())['checkout_unchanged']}
finally:t.doCleanups()
t=m.RunnerChecks();t.setUp();child_pid=None
try:
 pidfile=t.base/'detached.pid'
 child=f'import os,time; from pathlib import Path; Path({str(pidfile)!r}).write_text(str(os.getpid())); time.sleep(60)'
 t.make_plan(f'import subprocess,sys,time; subprocess.Popen([sys.executable,"-c",{child!r}],start_new_session=True); time.sleep(60)',timeout=1)
 rc=t.run_gate();child_pid=int(pidfile.read_text());stat=pathlib.Path(f'/proc/{child_pid}/stat').read_text().rsplit(')',1)[1].split()[0]
 results['F03']={'run_rc':rc,'detached_pid':child_pid,'detached_state_after_timeout':stat}
finally:
 if child_pid:
  try:os.kill(child_pid,signal.SIGKILL)
  except ProcessLookupError:pass
 t.doCleanups()
pathlib.Path('/workspace/agy-preflight/reproduction-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
