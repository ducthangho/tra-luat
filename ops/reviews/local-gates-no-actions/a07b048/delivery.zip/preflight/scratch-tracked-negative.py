import importlib.util,pathlib,sys,json
path=pathlib.Path('/workspace/local-gates-executor/.claude/dev/local_gate_checks.py')
s=importlib.util.spec_from_file_location('checks',path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
t=m.RunnerChecks();t.setUp()
try:
 before=m.gate.identity(t.root)
 try:m.gate.scratch_run(t.root,[sys.executable,'-B','-c','from pathlib import Path; Path("probe.py").write_text("changed"); print("POSITIVE")'])
 except ValueError as e:result={'rejected':True,'error':str(e),'source_unchanged':m.gate.identity(t.root)==before}
 else:raise AssertionError('Tracked mutation in scratch was accepted')
 assert result['source_unchanged']
 pathlib.Path('/workspace/agy-preflight/scratch-tracked-negative.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
finally:t.doCleanups()
