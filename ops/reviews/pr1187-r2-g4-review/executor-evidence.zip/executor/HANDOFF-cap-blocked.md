# Packet #1187 r2/g4 checkpoint — CAP BLOCKED

Executor: OpenAI Codex / codex_service / machine / cloud. No subagents or model reviews.
Start/frozen candidate H29ee9ca74d61544fbddd56c39dabbe194d26408e, tree996c6af444aeb22d69587ed7852b78f35102eb9b.
Immutable acceptance base1f0941e9bba1d1d517eda4174167b81963c06bd5. Candidate source remains untouched and clean.
Grant2026-11-05T03:23:42Z; hard deadline04:53:42Z (lease expiry does not extend this run).

Complete proposed source diff lives in proposed-complete.patch, SHA25628ea685432950eaaba2f9e39c616087140642251de60502c1bdaaacab63af642.
Direct base comparison is five net files/+1176/-11, exceeding the still-effective +1000 cap by176.
No admission, source commit, new-head review, codepush, PR, ready, merge, land or deploy was attempted.

The proposed diff addresses mixed-case suffix identity and all six advisory scopes. It is a proposal, not accepted final code.
Light scratch diagnostics loaded the proposal before the final dynamic actual-own-H test improvement:213 measured cases,211 passed.
Two assertions failed because tests demand `K4: --expires-utc ...` while actual intentional rc12 output says `K4 review offline: --expires-utc ...`.
Both actual overflow inputs intentionally reject with no traceback. Correct assertion text after cap authority; do not count these tests passed yet.
Dynamic actual-own-H case must also be measured after approval.
Shared positive-control selection needs a scoped exception for pre-existing tightening mutant `r1187_drop_human_call`, which intentionally disables all human K4.
No false unaffected-control claim is made for cli_transition under that mutant. All102 r1187 mutant anchors exist.

Synthetic first-parent rollout graphs in blob consumer tests are explicitly labelled synthetic; they do not certify canonical ADR0063 rollout.
Actual source OID/path/hash receipts for wp1178r3, ownr1/r2 are in actual-blob-readbacks.json and scratch diagnostic log.
Canonical current master ancestry/admission and final committed-head gates are not claimed. Current master differs from immutable acceptance base.

Pending actual cap authority, the frozen proposal and candidate remain unchanged. After authority: correct disclosed test/control issues,
apply only two authorized source paths, commit final H, run canonical pinned-code admission and ancestry/runtime receipts before heavy gates,
then targeted consumer/mutant controls, full tl selftest and supporting gates. Root owns read-only fullstandard allowance and native Windows validation.
Primary human audit, connector/M9 and later lifecycle actions remain root duties; oldH evidence cannot certify newH.
