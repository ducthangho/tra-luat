from pathlib import Path
import sys,subprocess,json,hashlib,datetime,os
art=Path(__file__).resolve().parent;c=art.parent/'candidate';canon=Path('/workspace/tra-luat');script=canon/'ops/lease_publish.py'
def git(root,*a):return subprocess.check_output(['git','-C',str(root),*a],text=True).strip()
h=git(c,'rev-parse','HEAD');t=git(c,'rev-parse','HEAD^{tree}');s=git(c,'rev-parse','refs/remotes/origin/master')
actual=hashlib.sha256(script.read_bytes()).hexdigest();pinned=subprocess.check_output(['git','-C',str(c),'show',s+':ops/lease_publish.py']);assert hashlib.sha256(pinned).hexdigest()==actual
meta=dict(H=h,T=t,actual_current_S=s,canonical_code_path=str(script),canonical_code_sha256=actual,canonical_code_matches_current_S=True,immutable_acceptance_base='1f0941e9bba1d1d517eda4174167b81963c06bd5',is_shallow=git(c,'rev-parse','--is-shallow-repository'),runs=[])
for label,base in [('immutable-base','1f0941e9bba1d1d517eda4174167b81963c06bd5'),('current-master',s)]:
 cmd=[sys.executable,str(script),'kiem-thu-hoi-github',h,'--canonical-base',base,'--nhanh-mac-dinh','master','--root',str(c),'--receipt',str(art/f'admission-{label}.json')]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(cmd,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 (art/f'admission-{label}.stdout').write_bytes(r.stdout);(art/f'admission-{label}.stderr').write_bytes(r.stderr)
 meta['runs'].append(dict(label=label,command=cmd,started=start,ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),rc=r.returncode,canonical_base=base,ancestry_rc=subprocess.run(['git','-C',str(c),'merge-base','--is-ancestor',base,h],capture_output=True).returncode))
 print(label,r.returncode,r.stdout.decode(errors='replace')[-150:],r.stderr.decode(errors='replace')[-300:])
(art/'canonical-admission-execution.json').write_text(json.dumps(meta,indent=2)+'\n')
assert meta['runs'][0]['rc']==0
assert meta['runs'][1]['ancestry_rc']==1 and meta['runs'][1]['rc']!=0
