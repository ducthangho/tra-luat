from pathlib import Path
base=Path('/workspace/scratch/pr1187-r2-g4/candidate/.claude/dev')
out=Path('/workspace/scratch/pr1187-r2-g4/artifacts/proposal/.claude/dev')
p=(base/'packet_loop.py').read_text()
p=p.replace('r"\\b(?:packet_id|revision)\\s*:"','r"(?i)\\b(?:packet_id|revision)\\s*:"')
p=p.replace('r"(?i)\\s*# .* r\\S+"','r"(?i)\\s*# .* r[0-9]\\S*"')
p=p.replace('    return d.astimezone(timezone.utc)','    try:\n        return d.astimezone(timezone.utc)\n    except OverflowError:\n        _die(RC_ARG, f"--expires-utc vượt biên UTC: {chuoi!r}")')
p=p.replace('        r = _doc_json(a.offline_run_json, RC_GATE)[0]','        if not (a.offline_run_json and a.offline_stdout):\n            raise ValueError("thiếu cặp --offline-run-json/--offline-stdout")\n        r = _doc_json(a.offline_run_json, RC_GATE)[0]')
(out/'packet_loop.py').write_text(p)
t=(base/'packet_loop_test.py').read_text().replace('import importlib.util\n','import importlib.machinery\nimport importlib.util\n')
t=t.replace('r\\"(?i)\\\\s*# .* r\\\\S+\\"','r\\"(?i)\\\\s*# .* r[0-9]\\\\S*\\"') if False else t
# Existing mutation follows the revised numeric revision-lookalike trigger.
t=t.replace('r\\"(?i)\\\\s*# .* r\\\\S+\\"','r\\"(?i)\\\\s*# .* r[0-9]\\\\S*\\"')
t=t.replace('r"(?i)\\\\s*# .* r\\\\S+"','r"(?i)\\\\s*# .* r[0-9]\\\\S*"')
t=t.replace('# Target individual checks, with unchanged setup/import and positive controls in every mutant run.','# Target individual checks. The runner adds cross-family controls; consumer positives below add measured controls for r1187 mutants.')
t=t.replace('    m = importlib.util.module_from_spec(sp := importlib.util.spec_from_file_location("docs1187", c.script)); sp.loader.exec_module(m)','    try:\n        m = importlib.util.module_from_spec(sp := importlib.util.spec_from_file_location("docs1187", c.script)); sp.loader.exec_module(m)\n    except (Exception, SystemExit) as ex:\n        raise CliSapDo("docs1187 import crashed") from ex')
# Guard setup operations independently of semantic assertions.
start=t.index('    w=Path(tempfile.mkdtemp(prefix="docs1187-"')
end=t.index('    rc,_,e=run(c.script,["adr-song"',start)
t=t[:start]+'    try:\n'+''.join('    '+line+'\n' for line in t[start:end].splitlines())+'    except (Exception, SystemExit) as ex:\n        raise CliSapDo("docs1187 setup crashed") from ex\n'+t[end:]
t=t.replace('    rc,_,e=run(c.script,["adr-song","--root",w],c.sd()); _doi(0,rc,e,"ADR0063 positive")','    rc,_,e=_docs_run1187(c,w); _doi(0,rc,e,"ADR0063 positive")')
t=t.replace('        rc,_,e=run(c.script,["adr-song","--root",w],c.sd()); _doi(9,rc,e,"ADR0063 missing anchor")','        rc,_,e=_docs_run1187(c,w); _doi(9,rc,e,"ADR0063 missing anchor")')
# Transition import and dispatch must never turn infrastructure exceptions into semantic deaths.
start=t.index('    m = importlib.util.module_from_spec(sp := importlib.util.spec_from_file_location("transition_cli", script))')
end=t.index('\n\ndef _transition_cli1187',start)
old=t[start:end]
new='''    try:
        m = importlib.util.module_from_spec(sp := importlib.util.spec_from_file_location("transition_cli", script))
        sys.path.insert(0, str(script.parent)), sp.loader.exec_module(m)
        m.ADR0062_OID = milestone
        out, err = __import__("io").StringIO(), __import__("io").StringIO()
    except (Exception, SystemExit) as ex:
        raise CliSapDo("transition1187 setup/import crashed") from ex
    try:
        with __import__("contextlib").redirect_stderr(err), __import__("contextlib").redirect_stdout(out):
            try:
                rc = m.main(["--state-dir", str(sd), *map(str, args)])
            except SystemExit as ex:
                rc = ex.code
        if rc not in (0, 2, 12) or _co_banner(out.getvalue().encode()) or _co_banner(err.getvalue().encode()):
            raise CliSapDo("transition1187 CLI crashed")
    except (Exception, SystemExit) as ex:
        raise CliSapDo("transition1187 dispatch crashed") from ex
    return rc, out.getvalue().encode(), err.getvalue().encode()
'''
t=t[:start]+new+t[end:]
# Preserve original diagnostic cases, strengthen their assertions.
t=t.replace('_c1106_ca(12,"K4",doi=lambda x,w,h:h and x.update(missing_model_run=True))','_c1106_ca(12,"thiếu cặp --offline-run-json/--offline-stdout",cam="TypeError",doi=lambda x,w,h:h and x.update(missing_model_run=True))')
t=t.replace('_c1106_ca(12,"K4",doi=lambda x,w,h:h and x.update(missing_model_stdout=True))','_c1106_ca(12,"thiếu cặp --offline-run-json/--offline-stdout",cam="TypeError",doi=lambda x,w,h:h and x.update(missing_model_stdout=True))')
(out/'packet_loop_test.py').write_text(t)
