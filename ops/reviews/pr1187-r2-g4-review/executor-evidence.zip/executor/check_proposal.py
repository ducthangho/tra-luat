import sys,os,importlib.util,json,time,datetime
from pathlib import Path
sys.dont_write_bytecode=True
art=Path(__file__).resolve().parent
candidate=art.parent/'candidate'
dev=art/'proposal/.claude/dev'
sys.path.insert(0,str(dev))
sp=importlib.util.spec_from_file_location('proposal_tests',dev/'packet_loop_test.py')
m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
m.ROOT=candidate;m.HERE=candidate/'.claude/dev'
names=[n for n,f in m.CASES if n.startswith('r1187_')]
start=time.time();results=m.chay_suite(dev/'packet_loop.py',art/'proposal-targeted-fixtures',chi_chay=set(names))
rows=[dict(name=n,result='passed' if v is None else 'false_credit' if isinstance(v,m._TinDungGia) else 'failed',detail=str(v) if v else '') for n,v in results.items()]
report=dict(scope='scratch proposed patch diagnostics only; not committed-head gates/admission',started=datetime.datetime.fromtimestamp(start,datetime.timezone.utc).isoformat(),seconds=time.time()-start,rows=rows)
(art/'proposal-targeted-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for row in rows:
 if row['result']!='passed':print(json.dumps(row,ensure_ascii=False),flush=True)
print('RESULT',len(rows),sum(r['result']=='passed' for r in rows),flush=True)
sys.exit(any(r['result']!='passed' for r in rows))
