import sys,subprocess,json,os,datetime
from pathlib import Path
art=Path(__file__).resolve().parent;c=art.parent/'candidate';label=sys.argv[1];cmd=sys.argv[2:];h=subprocess.check_output(['git','-C',str(c),'rev-parse','HEAD'],text=True).strip();out=art/('gates-'+h[:8]);out.mkdir(exist_ok=True)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/(label+'.log')).open('wb') as f:
 p=subprocess.run(cmd,cwd=c,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
r=dict(H=h,T=subprocess.check_output(['git','-C',str(c),'rev-parse',h+'^{tree}'],text=True).strip(),command=cmd,started=start,ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),rc=p.returncode,log=str(out/(label+'.log')),head_unchanged=subprocess.check_output(['git','-C',str(c),'rev-parse','HEAD'],text=True).strip()==h)
(out/(label+'.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(p.returncode)
