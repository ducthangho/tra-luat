from pathlib import Path
import sys,os,json,importlib.util,datetime,time,hashlib,subprocess
sys.dont_write_bytecode=True
art=Path(__file__).resolve().parent;c=art.parent/'candidate';dev=c/'.claude/dev';h=subprocess.check_output(['git','-C',str(c),'rev-parse','HEAD'],text=True).strip();out=art/('targeted-'+h[:8]);out.mkdir(exist_ok=True)
sys.path.insert(0,str(dev));sp=importlib.util.spec_from_file_location('final_targeted',dev/'packet_loop_test.py');m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
start=datetime.datetime.now(datetime.timezone.utc).isoformat();source=(dev/'packet_loop.py').read_text();tests=(dev/'packet_loop_test.py').read_text();rows=[]
# Same committed consumers, real objects and crash classification as the standard suite.
result=m.chay_suite(dev/'packet_loop.py',out/'baseline',chi_chay={n for n,f in m.CASES if n.startswith('r1187_')})
for n,v in result.items():
 rows.append(dict(phase='baseline',name=n,status='passed' if v is None else m._phan_loai_giet(v),detail=str(v) if v else ''))
 if v is not None: print('BASELINE_FAILURE',n,repr(v),flush=True)
print('BASELINE',len(result),sum(v is None for v in result.values()),flush=True)
(out/'baseline.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
if any(v is not None for v in result.values()):sys.exit(1)
for name,(old,new,targets) in m.MUTANTS.items():
 if not name.startswith('r1187_'):continue
 cap=m._cap_thay_the(old,new);body,test_mutant,missing=m._phan_loai_dot_bien(name,cap,source,tests)
 assert not missing,(name,missing)
 d=out/('mut-'+hashlib.sha256(name.encode()).hexdigest()[:16]);d.mkdir(exist_ok=True)
 for a,b in cap:body=body.replace(a,b,1)
 script=d/'packet_loop.py';script.write_text(source if test_mutant else body,encoding='utf-8',newline='\n');(d/'launcher.py').write_bytes((dev/'launcher.py').read_bytes())
 suite=m
 if test_mutant:
  t=d/'packet_loop_test.py';t.write_text(body,encoding='utf-8',newline='\n');sp=importlib.util.spec_from_file_location('mut_'+name,t);suite=importlib.util.module_from_spec(sp);sys.modules[sp.name]=suite;sp.loader.exec_module(suite);suite.HERE=dev;suite.ROOT=c
 controls=suite._doi_chung_khac_ho(targets)+suite._controls1187(name,targets)
 res=suite.chay_suite(script,d/'cases',chi_chay=set(targets)|set(controls))
 alive=[n for n in targets if res.get(n) is None];false=[n for n in targets if suite._phan_loai_giet(res.get(n))=='TIN_DUNG_GIA'];skip=[n for n in targets if isinstance(res.get(n),suite.BoQua)];control_fail=[n for n in controls if res.get(n) is not None]
 row=dict(phase='mutant',name=name,targets=targets,controls=controls,alive=alive,false_credit=false,skipped=skip,control_failures=control_fail,status='passed' if not(alive or false or skip or control_fail) else 'failed',results={n:(None if v is None else str(v)) for n,v in res.items()})
 rows.append(row);(out/'results.json').write_text(json.dumps(dict(H=h,started=start,rows=rows),ensure_ascii=False,indent=2)+'\n');print(name,row['status'],json.dumps(dict(alive=alive,false=false,skip=skip,controls=control_fail)),flush=True)
end=datetime.datetime.now(datetime.timezone.utc).isoformat();assert subprocess.check_output(['git','-C',str(c),'rev-parse','HEAD'],text=True).strip()==h
report=dict(H=h,T=subprocess.check_output(['git','-C',str(c),'rev-parse','HEAD^{tree}'],text=True).strip(),command=[sys.executable,__file__],started=start,ended=end,source_sha256=hashlib.sha256(source.encode()).hexdigest(),test_sha256=hashlib.sha256(tests.encode()).hexdigest(),baseline_cases=len(result),mutants=sum(r['phase']=='mutant' for r in rows),rows=rows,rc=int(any(r['status']!='passed' for r in rows)))
(out/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('TARGETED_FINAL',report['baseline_cases'],report['mutants'],report['rc'],flush=True);sys.exit(report['rc'])
