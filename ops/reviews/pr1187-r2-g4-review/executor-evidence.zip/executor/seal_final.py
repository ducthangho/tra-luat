from pathlib import Path
import sys,subprocess,json,hashlib,datetime,platform,shutil,gzip,stat,os
art=Path(__file__).resolve().parent;c=art.parent/'candidate';expected='33df4b678e3d1f12e68a9c9d362dc0446f0dd5c2';base='1f0941e9bba1d1d517eda4174167b81963c06bd5';old='29ee9ca74d61544fbddd56c39dabbe194d26408e'
def git(*args):return subprocess.check_output(['git','-C',str(c),*args],text=True).strip()
h=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');assert h==expected
report=json.loads((art/('targeted-'+h[:8])/'results.json').read_text());assert report['H']==h and report['rc']==0
assert report['baseline_cases']==222 and report['mutants']==102
out=art/('gates-'+h[:8]);gates=[]
for label in ('tl-selftest','doctrine','adr','eol','doc-claims-required','diff-check'):
 r=json.loads((out/(label+'.json')).read_text());assert r['H']==h and r['rc']==0 and r['head_unchanged'];gates.append(r)
assert '== tl selftest 1776/1776 ==' in (out/'tl-selftest.log').read_text()
admission=json.loads((art/'canonical-admission-execution.json').read_text());assert admission['H']==h
assert [(x['rc'],x['ancestry_rc']) for x in admission['runs']]==[(0,0),(12,1)]
lease=Path('/workspace/scratch/pr1187-recovery/infra-g4-grant/ops/leases/pr1184-merge-contract-r2-g4-codex-service.yaml')
assert hashlib.sha256(lease.read_bytes()).hexdigest()=='877c93882bfc2277a617ca68bdae30f61b82a97a6d972f997130eca44ea70639'
# Source and immutable inherited blobs; all generated evidence remains outside the clone.
for name,args in [('final-full.diff',['diff','--binary',base,h]),('final-numstat.txt',['diff','--numstat',base,h]),('final-g4.diff',['diff','--binary',old,h]),('final-name-status.txt',['diff','--name-status',base,h])]:
 (art/name).write_bytes(subprocess.check_output(['git','-C',str(c),*args]))
num=[]
for line in (art/'final-numstat.txt').read_text().splitlines():
 a,d,p=line.split('\t');num.append(dict(path=p,added=int(a),deleted=int(d)))
assert len(num)==5 and sum(x['added'] for x in num)==1227 and sum(x['deleted'] for x in num)==11
changed=git('diff','--name-only',old,h).splitlines();assert changed==['.claude/dev/packet_loop.py','.claude/dev/packet_loop_test.py']
inherited=[]
for p in ('docs/PROTOCOL_DA_PHIEN.md','docs/adr/0063-merge-spec-ref-va-human-audit.md','ops/specs/PR1184-MERGE-CONTRACT-r2.md'):
 a,b=git('rev-parse',old+':'+p),git('rev-parse',h+':'+p);assert a==b
 inherited.append(dict(path=p,inherited_blob=a,final_blob=b,sha256=hashlib.sha256((c/p).read_bytes()).hexdigest()))
(art/'final-inherited-proof.json').write_text(json.dumps(dict(H=h,T=tree,g4_changed_paths=changed,unchanged_inherited_files=inherited),indent=2)+'\n')
# All test processes have terminated. Preserve hashes and copies before removing only this run's generated ignored files.
assert not git('status','--porcelain=v1','--untracked-files=all')
ignored=subprocess.check_output(['git','-C',str(c),'ls-files','--others','--ignored','--exclude-standard','-z']).decode().split('\0');ignored=[p for p in ignored if p]
allowed=('references/golden/fixtures/','scripts/.tl_state/','scripts/__pycache__/','scripts/tl_core/__pycache__/')
assert all(p.startswith(allowed) for p in ignored),ignored
saved=art/'saved-selftest-generated-final';records=[];parents=set()
for p in ignored:
 f=c/p;rec=dict(path=p,bytes=f.lstat().st_size)
 if f.is_symlink():rec['symlink_target']=os.readlink(f)
 else:
  rec['sha256']=hashlib.sha256(f.read_bytes()).hexdigest();to=saved/p;to.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,to)
 records.append(rec);f.unlink();parents.update(f.parents)
for p in sorted(parents,key=lambda p:len(p.parts),reverse=True):
 if p!=c and c in p.parents:
  try:p.rmdir()
  except OSError:pass
(art/'selftest-generated-ignored-files.json').write_text(json.dumps(dict(H=h,removed_only_recorded_files=True,files=records),indent=2)+'\n')
clean=git('status','--porcelain=v1','--ignored','--untracked-files=all');assert clean==''
(art/'final-clean-proof.json').write_text(json.dumps(dict(H=h,T=tree,status_porcelain_including_ignored=clean,normal_clone=(c/'.git').is_dir(),branch=git('branch','--show-current'),generated_files_saved_and_removed=len(records),time=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2)+'\n')
# Preserve file hashes of completed scratch fixtures; keep raw failures and all logs in place.
fixture_manifest=art/'fixture-sha256.jsonl.gz';count=0
with gzip.open(fixture_manifest,'wt',encoding='utf-8') as z:
 for root in sorted([p for p in art.iterdir() if p.is_dir() and (p.name.startswith('targeted-') or p.name=='proposal-targeted-fixtures')]):
  for f in sorted(root.rglob('*')):
   if f.is_file() and not f.is_symlink():
    z.write(json.dumps(dict(path=str(f.relative_to(art)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))+'\n');count+=1
# Same explicit expanded diagnostic on H29 and finalH; this tree OID is intentionally not a commit.
expanded=json.loads((out/'doc-claims-expanded-diagnostic.json').read_text());paired=json.loads((art/'paired-H29-docclaims.json').read_text());assert expanded['rc']==paired['rc']==2 and expanded['command']==paired['command']
a=json.loads((out/'doc-claims-expanded-diagnostic.log').read_text());b=json.loads((art/'paired-H29-docclaims.log').read_text());assert a['flags']==b['flags']
paired_proof=dict(final_H=h,baseline_H=old,command=expanded['command'],final_rc=2,baseline_rc=2,flags_identical=True,flags=a['flags'],oid_type=git('cat-file','-t','94da193973b02d28e7f67d222e968dea66342f7f'),frozen_spec_sha256=inherited[-1]['sha256'])
(art/'docclaims-paired-proof.json').write_text(json.dumps(paired_proof,indent=2)+'\n')
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
text=f'''# Packet #1187 r2/g4 — frozen Executor handoff

Final H `{h}`; tree `{tree}`. Branch `agent/pr1187-r2-g4-codex-service`, normal Git clone `{c}`.
Provider/surface/transport: OpenAI Codex / codex_service / machine, cloud Linux. No subagents, local model review, GitHub writes, source push, PR, ready, merge, land or deploy.
Frozen at {now}; grant2026-11-05T03:23:42Z, unchanged hard writerdeadline2026-11-05T04:53:42Z. Source work is terminal; no further edits planned.

## Result and scope

Mixed-case identity suffix P2 and all six advisory scopes are repaired in the only two writable paths, `.claude/dev/packet_loop.py` and `.claude/dev/packet_loop_test.py`.
Against immutable1f0941e9bba1d1d517eda4174167b81963c06bd5: five net files/+1227/-11, within owner-approved1250cap at https://github.com/ducthangho/tra-luat/issues/1187#issuecomment-6648984609.
The three inherited spec/protocol/ADR blobs are unchanged from H29; see final-inherited-proof.json. Full base diff, g4-only diff and numstat are adjacent artifacts.
Actual wp1178r3, own frozenr1/r2 and actual final-own-H blobs have committed regressions and exactOID/path/SHA receipts. Their rollout graph is explicitly SYNTHETIC; it is not canonical rollout authority.
Benign H1, owner anchor/alias/wrongrepo/invalidhuman+validmodel, packet types, realOID/ref forms, docs/transition fault boundaries, partial model input and UTC boundary diagnostics are covered by committed cases.
Alias screening overlaps anchor screening; empty/None identities have additional grammar/binding guards. No unique mutation credit is claimed for those redundant checks.

## Measured on this exact head

- Targeted r1187 baseline222/222,102/102 mutants with actual targets and controls: rc0. No false-credit kills or skipped targets. See targeted-{h[:8]}/results.json and targeted-{h[:7]}.log.
- Full `python -u -B scripts/tl.py --selftest`:1776/1776,rc0.
- Doctrine, ADR, indexed EOLall, default required `doc-claims-check --strict`, diffcheck:rc0; commands/times/H/tree in gates-{h[:8]}/*.json.
- Canonical admission uses /workspace/tra-luat/ops/lease_publish.py, hashverified equalcurrentS4d258cc8831b5c6169114d1e8e88a8782096d6f6. Immutable1f S→H admissionrc0 with actual verified Git objects/runtime; actualcurrentmaster4d admissionrc12 and ancestryrc1. Currentmasteradmission is BLOCKED, not passed; root handles drift.
- Clean Git status including ignored files; {len(records)} generated ignored files hashrecorded, saved outside clone and removed individually only after terminal gates. Scratch fixture file hashes: {count} entries in fixture-sha256.jsonl.gz; raw failures/logs retained.

Required default docclaims is green. Separate expanded scan including frozenr2spec is rc2 on both finalH and unchanged H29 with exactly identical flags: spec line9 explicitly labels94da193...as tree, and Git confirms type tree; L2 calls it SHA_NOT_A_COMMIT. See docclaims-paired-proof.json. Frozen spec was not edited.

## Honest control and attempt history

The broad historical drop_human_call mutant disables human K4, so transitionCLI is not an unaffected control there. The historical drop_run_time mutant reroutes modern audits to legacytransition, so modernCLIhuman is not an unaffected control there. Both exclusions are explicit, retain the original positive CASES, and keep actual directhuman/legacytransition/other controls. The narrow audit-order mutant remains separately measured.
Intermediate failures were preserved and repaired, not credited: alias/type fixture transition identity, expected overflow diagnostic text, and overbroad control claims. A rethrow-overflow mutation correctly received FALSECREDIT; final semantic mutation coerces invalid time to a healthy UTC fixture instant. A committed overflow crash probe verifies crashes still receive no semantic credit.
Earlier H599/dd2 fulltl results and scratch diagnostics remain historical and cannot substitute for final-head evidence. H71 targeted run was interrupted after a source boundary improvement; its partial output remains intact.

## Remaining controller work — not run by Executor

Full packet-loop standard under the separate read-only180minute allowance; native WindowsM3 on this exactH; independent primary human personally auditing full finaldiff/spec; any exactH K4bootstrap decision; codepushonce/newPR/exactheadconnector/M9/CI/land authority and lifecycle. None is claimed passed or waived here. No oldH review/audit/land authority is transferred.

Hint provenance: P2 derives from connector5779358121/inline4476177126 and controller reproduction. P3 guidance derives from the approved operational addendum and historical r3 remediation/triage_review4.py diagnostics. Executor rederived the implementation and fixtures, applied only its own scratch proposal after actual cap authority, and ran the measured branch tests; no blind external patch application or independent-review claim.
'''
(art/'HANDOFF.md').write_text(text)
manifest=dict(schema='pr1187_executor_handoff.v1',status='executor_frozen_controller_validation_pending',H=h,T=tree,branch=git('branch','--show-current'),immutable_base=base,writer_grant='2026-11-05T03:23:42Z',writer_deadline='2026-11-05T04:53:42Z',sealed_at=now,provider='openai_codex',execution_surface='codex_service',transport='machine',cap=1250,numstat=num,added=1227,deleted=11,source_changed_paths=changed,source_sha256={p:hashlib.sha256((c/p).read_bytes()).hexdigest() for p in changed},gates=gates,targeted=dict(command=report['command'],started=report['started'],ended=report['ended'],rc=report['rc'],baseline_cases=222,mutants=102,result_path=f'targeted-{h[:8]}/results.json'),admission=admission,expanded_docclaims=paired_proof,generated_cleanup_count=len(records),fixture_hash_count=count,environment=dict(python=sys.version,platform=platform.platform(),git=git('--version')),not_run_by_executor=['full packet-loop standard (assigned root180min)','native Windows (assigned root)','independent primary human audit','new-head connector/M9/CI/land'],local_model_review_calls=0,github_writes=0,source_pushes=0)
files=[p for p in art.iterdir() if p.is_file() and p.name!='manifest.json']+list(out.glob('*.json'))+list(out.glob('*.log'))+[art/('targeted-'+h[:8])/'results.json',art/('targeted-'+h[:8])/'baseline.json']
manifest['evidence']=[dict(path=str(f.relative_to(art)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in sorted(set(files))]
(art/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=manifest['status'],H=h,T=tree,added=1227,removed_generated_files=len(records),fixture_hashes=count,sealed_at=now)))
