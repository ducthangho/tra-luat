import pathlib,sys,os,json,subprocess,hashlib,base64,datetime,time,importlib.util,tempfile,csv,traceback,platform
S=pathlib.Path(__file__).resolve().parent
CFG=json.loads((S/"config.json").read_text(encoding="utf-8"))
REPO=S/"repo"; LOCK=S.parent/"KHOA.txt"; SID=S.name
BASE="1f0941e9bba1d1d517eda4174167b81963c06bd5"
HEAD=CFG["head"]
TREE=CFG["tree"]
BUNDLE_SHA=CFG["bundle_sha256"]
os.environ.update(PYTHONUTF8="1",PYTHONIOENCODING="utf-8",PYTHONDONTWRITEBYTECODE="1",GIT_TERMINAL_PROMPT="0")
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
LAST_HEARTBEAT=0
def ownlock():
    global LAST_HEARTBEAT
    value=LOCK.read_text(encoding="utf-8-sig")
    if not value.startswith(SID+"\t"): raise RuntimeError("Own lock lost")
    if time.monotonic()-LAST_HEARTBEAT>600:
        fields=value.split("\t");now=datetime.datetime.now(datetime.timezone.utc);fields[2]=(now+datetime.timedelta(hours=2)).isoformat();fields[-1]=now.isoformat();LOCK.write_text("\t".join(fields),encoding="utf-8");LAST_HEARTBEAT=time.monotonic()
def git(*args):
    p=subprocess.run(["git","-C",str(REPO),*args],capture_output=True,text=True,encoding="utf-8",timeout=180)
    if p.returncode: raise RuntimeError("git "+str(args)+": "+p.stderr[-1500:])
    return p.stdout.strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
result={"schema":"pr1187_windows_paired.v1","session":SID,"machine":os.environ.get("COMPUTERNAME"),"surface":"native_windows","os":platform.system(),"single_invocation":True,"baseline":BASE,"candidate":HEAD,"started_at_utc":utc(),"runs":[],"errors":[],"limitations":["Selected common legacy/CLI tests and native-Windows canonical case; candidate-only new r1187 tests are explicit. This is not full standard suite, GitHub Windows CI or M9."]}
def save(): (S/"paired-evidence.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
def logrow(phase,h,passed,total,elapsed,note):
    path=S.parent/"do-luong.csv"; fields=["thoi_diem","session","packet","sha","bo_test","dat","tong","ca_do","thoi_luong_s","phat_hien_boi","loi_that","da_va","ghi_chu"]
    exists=path.exists() and path.stat().st_size>0
    with path.open("a",encoding="utf-8",newline="") as f:
        w=csv.writer(f)
        if not exists:w.writerow(fields)
        w.writerow([utc(),SID,"1187",h,phase,passed,total,total-passed,round(elapsed,3),"local","not_classified","no","may="+result["machine"]+"; "+note])
try:
    ownlock()
    b=base64.b64decode((S/"candidate.bundle.b64").read_text())
    if hashlib.sha256(b).hexdigest()!=BUNDLE_SHA:raise RuntimeError("Bundle hash mismatch")
    (S/"candidate.bundle").write_bytes(b)
    if REPO.exists():raise RuntimeError("Session clone already exists; do not overwrite")
    # Real GitHub clone; borrow only the verified previous OWN isolated clone object cache.
    clonecmd=["git","clone","--no-checkout","--reference-if-able",r"D:\tl-win\codex-wp1178-g4-ef864d6-m3-20261105\repo","https://github.com/ducthangho/tra-luat.git",str(REPO)]
    began=time.monotonic();print("CLONE_STARTED",utc(),flush=True)
    with (S/"clone.log").open("wb") as cf:
        q=subprocess.Popen(clonecmd,stdout=cf,stderr=subprocess.STDOUT)
        result["clone_command"]=clonecmd;result["own_clone_pid"]=q.pid;save()
        while True:
            try:clone_rc=q.wait(timeout=30);break
            except subprocess.TimeoutExpired:
                ownlock();print("CLONE_PROGRESS",round(time.monotonic()-began),"seconds",flush=True)
                if time.monotonic()-began>360:
                    if q.poll() is None:
                        subprocess.run(["taskkill","/PID",str(q.pid),"/T","/F"],capture_output=True)
                    raise RuntimeError("Own GitHub clone deadline360s exceeded; own child tree stop attempted")
    result["clone_rc"]=clone_rc;save()
    if clone_rc:raise RuntimeError("GitHub clone rc"+str(clone_rc))
    print("CLONE_COMPLETED",round(time.monotonic()-began),"seconds",flush=True)
    git("config","core.autocrlf","false");git("config","core.eol","lf");git("config","core.abbrev","7")
    git("bundle","verify",str(S/"candidate.bundle"))
    git("fetch",str(S/"candidate.bundle"),"HEAD:refs/heads/candidate-local")
    git("sparse-checkout","init","--no-cone")
    git("sparse-checkout","set","--no-cone","/.claude/","/.agents/","/docs/","/ops/KE_HOACH_THI_CONG_CLAUDE_CODEX.md","/.github/","/CLAUDE.md","/CONTEXT.md","/AGENTS.md")
    result["common_and_candidate_ids_expected"]=CFG["r1187_case_ids"]
    ids=None
    for label,h in [("baseline",BASE),("candidate",HEAD)]:
        ownlock();git("checkout","--detach",h)
        if git("rev-parse","HEAD")!=h:raise RuntimeError("Checkout head mismatch")
        tree=git("rev-parse","HEAD^{tree}")
        if label=="candidate" and tree!=TREE:raise RuntimeError("Candidate tree mismatch")
        start=time.monotonic()
        run={"label":label,"sha":h,"tree":tree,"parents":git("show","-s","--format=%P","HEAD"),"started_at_utc":utc(),"tests":[],"source_sha256":{}}
        result["runs"].append(run);save()
        for rel in [".claude/dev/packet_loop.py",".claude/dev/packet_loop_test.py"]:
            p=REPO/rel;compile(p.read_bytes(),str(p),"exec");run["source_sha256"][rel]=sha(p)
        run["tests"].append({"id":"python-compile","ket_qua":"passed","rc":0,"command":["python","compile()","packet_loop.py","packet_loop_test.py"],"positive":"COMPILED=2"})
        git("diff","--check",BASE,h)
        run["tests"].append({"id":"git-diff-check","ket_qua":"passed","rc":0,"command":["git","diff","--check",BASE,h]})
        p=REPO/".claude/dev/packet_loop_test.py";sys.path.insert(0,str(p.parent))
        sp=importlib.util.spec_from_file_location("paired_"+label,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
        common={n for n,_ in m.CASES if n.startswith(("cong_c_","wp1124_","m9_")) or n=="luong_canonical_chay_that"}
        if ids is None:ids=common;result["common_test_ids"]=sorted(ids)
        if common!=ids:raise RuntimeError("Common case IDs differ")
        selected=sorted(common)
        if label=="candidate":
            extra=sorted(n for n,_ in m.CASES if n.startswith("r1187_"))
            if extra!=CFG["r1187_case_ids"]:raise RuntimeError("Candidate r1187 inventory differs from frozen exactH catalog")
            selected+=extra;run["candidate_only_test_ids"]=extra
        with tempfile.TemporaryDirectory(prefix=label+"-",dir=str(S)) as d:
            for n in selected:
                ownlock()
                if time.monotonic()-start>3600:raise RuntimeError("Paired phase deadline exceeded")
                rr=m.chay_suite(m.CANONICAL,pathlib.Path(d),{n})
                if set(rr)!={n}:raise RuntimeError("Case missing or empty:"+n)
                err=rr[n];record={"id":n,"ket_qua":"passed" if err is None else "failed","rc":0 if err is None else 1,"command":["python","run_paired.py","chay_suite",n],"candidate_only":label=="candidate" and n.startswith("r1187_")}
                if err is not None:record["error"]=str(err)
                run["tests"].append(record)
                print(label,n,record["ket_qua"],str(err or ""),flush=True);save()
        run["elapsed_seconds"]=time.monotonic()-start
        passed=sum(t["ket_qua"]=="passed" for t in run["tests"]);logrow(label,h,passed,len(run["tests"]),run["elapsed_seconds"],"common paired inventory plus2static; every frozen candidate r1187 case, counts measured")
        save()
    ownlock()
    native=subprocess.run([sys.executable,"-B","-u",str(S/"native_mutant.py"),str(REPO),str(S/"windows-only")],capture_output=True,timeout=900)
    (S/"native.stdout.log").write_bytes(native.stdout);(S/"native.stderr.log").write_bytes(native.stderr)
    result["native_mutant_rc"]=native.returncode
    if native.returncode:raise RuntimeError("Native semantic mutant failed rc"+str(native.returncode))
    nativeproof=json.loads((S/"windows-only/windows-only-mutant.json").read_text(encoding="utf-8"));assert nativeproof["passed"] and nativeproof["sha"]==HEAD
    result["native_mutant_receipt"]=nativeproof
    errors=[(r["label"],t["id"],t.get("error")) for r in result["runs"] for t in r["tests"] if t["ket_qua"]!="passed"]
    result["errors"]=errors;result["completed_at_utc"]=utc();result["rc"]=1 if errors else 0
    candidate=result["runs"][-1]
    windows={"schema_version":1,"os":platform.system(),"sha":HEAD,"tree":TREE,"machine":result["machine"],"tests":candidate["tests"],"comparison_scope":result["limitations"],"paired_evidence":"paired-evidence.json"}
    (S/"windows.json").write_text(json.dumps(windows,ensure_ascii=False,indent=2),encoding="utf-8")
    total=sum(len(r["tests"]) for r in result["runs"]);passed=sum(t["ket_qua"]=="passed" for r in result["runs"] for t in r["tests"])
    print("PAIRED_RESULT="+str(passed)+"/"+str(total),flush=True)
except BaseException as e:
    result["errors"].append({"exception":str(e),"traceback":traceback.format_exc()});result["rc"]=2
    print(traceback.format_exc(),flush=True)
finally:
    save()
    try:
        ownlock();LOCK.write_bytes(b"");print("LOCK_RELEASED",flush=True)
    except Exception as e:print("LOCK_NOT_RELEASED:"+str(e),flush=True)
    print("PAIRED_SUITE_RC="+str(result.get("rc",2)),flush=True)
sys.exit(result.get("rc",2))
