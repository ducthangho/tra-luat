"""Supplemental native Windows semantic mutant. Does not replace standard suite/M9.
Run: python -u -B windows-only-mutant.py <exact-H-source-root> <own-scratch-out>
No source edits; requires original exact-H plan/code/test/launcher assets.
"""
from pathlib import Path
import hashlib,importlib.util,json,os,platform,subprocess,sys
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
H=json.loads((Path(__file__).resolve().parent/"config.json").read_text(encoding="utf-8"))["head"];name='luong_canonical_chay_that_dao_os_name';plan='ops/KE_HOACH_THI_CONG_CLAUDE_CODEX.md'
assert os.name=='nt' and platform.system()=='Windows','native Windows measurement required'
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()==H
assets=['.claude/dev/packet_loop.py','.claude/dev/packet_loop_test.py','.claude/dev/launcher.py',plan]
hashes={}
for p in assets:
 b=(root/p).read_bytes();expected=subprocess.check_output(['git','-C',str(root),'show',H+':'+p]);assert b==expected,('source mismatch',p);hashes[p]=hashlib.sha256(b).hexdigest()
def load(p,n):
 sp=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(sp);sys.modules[n]=m;sp.loader.exec_module(m);return m
p=root/'.claude/dev/packet_loop_test.py';sys.path.insert(0,str(p.parent));m=load(p,'native_original')
assert m.ROOT==root and (m.ROOT/plan).is_file(),'positive control plan must exist;no early return'
old,new,targets=m.MUTANTS[name];pairs=m._cap_thay_the(old,new);product=m.CANONICAL.read_text(encoding='utf-8');test=p.read_text(encoding='utf-8');body,is_test,missing=m._phan_loai_dot_bien(name,pairs,product,test);assert is_test and not missing
controls=m._doi_chung_khac_ho(targets);selected=set(targets)|set(controls)
print('NATIVE POSITIVE',sorted(selected),flush=True)
positive=m.chay_suite(m.CANONICAL,out/'positive',selected)
assert all(t in positive and positive[t] is None for t in selected),{t:str(v) for t,v in positive.items()}
mutroot=out/'mutant';dev=mutroot/'.claude/dev';dev.mkdir(parents=True,exist_ok=True)
for a,z in pairs:body=body.replace(a,z,1)
(dev/'packet_loop.py').write_text(product,encoding='utf-8',newline='\n');(dev/'packet_loop_test.py').write_text(body,encoding='utf-8',newline='\n');(dev/'launcher.py').write_bytes((root/'.claude/dev/launcher.py').read_bytes());(mutroot/plan).parent.mkdir(parents=True,exist_ok=True);(mutroot/plan).write_bytes((root/plan).read_bytes())
suite=load(dev/'packet_loop_test.py','native_harness_mutant');suite.HERE=m.HERE
assert suite.ROOT==mutroot and (suite.ROOT/plan).is_file(),'mutant plan must exist;no missing-plan early return'
print('NATIVE MUTANT',name,flush=True)
result=suite.chay_suite(dev/'packet_loop.py',out/'mutant-run',selected)
bo_qua=[t for t in targets if isinstance(result.get(t),suite.BoQua)];song=[t for t in targets if result.get(t) is None];oan=[t for t in controls if result.get(t) is not None];gia=[t for t in targets if suite._phan_loai_giet(result.get(t))=='TIN_DUNG_GIA']
assert set(result)==selected
assert not(bo_qua or song or oan or gia),dict(skipped=bo_qua,survivors=song,control_failures=oan,false_credit=gia)
assert all('AssertionError: phải chạy trên Windows'==str(result[t]) for t in targets),{t:str(result[t]) for t in targets}
receipt=dict(sha=H,os='Windows',supplemental_only=True,not_GitHub_M9=True,mutant=name,classification_test_harness=is_test,target_tests=targets,controls=list(controls),positive={t:'passed' for t in positive},mutant_target_results={t:str(result[t]) for t in targets},mutant_control_results={t:'passed' for t in controls},bo_qua=bo_qua,survivors=song,control_failures=oan,false_credit=gia,source_sha256=hashes,passed=True)
(out/'windows-only-mutant.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps(receipt,ensure_ascii=False),flush=True)