import json,pathlib,subprocess,sys
source=pathlib.Path('/source/ops/environment/update-linux.sh'); text=source.read_text(); code=text.split("<<'UPDATER_SELFTEST'\n",1)[1].split('\nUPDATER_SELFTEST\n',1)[0]
variants={'malformed-import':code.replace('import hashlib,','import nonexistent_harness_module,',1),'zero-tests':code.split('with tempfile.TemporaryDirectory',1)[0]+code[code.index('passed = sum'): ]}
results=[]
for label,variant in variants.items():
 r=subprocess.run([sys.executable,'-B','-',str(source)],input=variant,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print(label,'rc='+str(r.returncode)); print(r.stdout)
 ok=r.returncode==1 and ('nonexistent_harness_module' in r.stdout if label=='malformed-import' else 'SELFTEST 0/0' in r.stdout)
 results.append((label,ok)); assert ok
print('HARNESS_INTEGRITY',json.dumps(results)); print('HARNESS_INTEGRITY %d/%d'%(sum(ok for _,ok in results),len(results)))
