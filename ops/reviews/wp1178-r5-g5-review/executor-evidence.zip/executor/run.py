import datetime, hashlib, json, os, pathlib, subprocess, sys
ROOT = pathlib.Path('/workspace/scratch/wp1178-r5-g5')
REPO = ROOT / 'candidate'
OUT = ROOT / 'artifacts'
name, *command = sys.argv[1:]
assert name and command
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
for key in list(env):
    if key.startswith('TL_') or key in ('GITHUB_PAT', 'CLAUDE_CODE_OAUTH_TOKEN', 'CI_DUONG_NHANH_CHE_DO', 'CI_DUONG_NHANH_CAY', 'DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH'):
        env.pop(key)
identity = subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=REPO, text=True).splitlines()
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
log = OUT / (name + '.log')
assert not log.exists(), 'preserve prior attempts'
with log.open('w') as stream:
    result = subprocess.run(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT)
receipt = dict(head=identity[0], tree=identity[1], command=command, cwd=str(REPO), started_at=start, finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), rc=result.returncode, log=str(log), sha256=hashlib.sha256(log.read_bytes()).hexdigest(), bytes=log.stat().st_size, head_tree_unchanged=identity == subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=REPO, text=True).splitlines())
(OUT / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
sys.exit(result.returncode)
