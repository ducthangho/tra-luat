import datetime, hashlib, json, os, pathlib, re, shutil, subprocess

root = pathlib.Path('/workspace/scratch/wp1178-r5-g5/candidate')
out = root.parent / 'artifacts'
H = '91686a66d855a9ddae9dcf4567b13ddaa092cbc2'
T = 'e9d2b287343f44ac29a0713e0c0ea6b909aa408c'
EC = 'ec1b18a2a007fc2e697249c727a2ca8391ab209e'
EF = 'ef864d6b3192a08487cd7fc0e526633afcb693d9'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
def data(name):
    return json.loads((out / name).read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert git('rev-parse', 'HEAD') == H and git('rev-parse', 'HEAD^{tree}') == T
names = ['admission-H-immutable-fullOID', 'full-policy-H-capable', 'ubuntu-root-H', 'ubuntu-nonroot-H', 'tl-full-H', 'workflow-controls-H', 'actionlint-verbose-H', 'eol-H', 'doctrine-H', 'adr-H', 'syntax-H', 'login-syntax-H', 'shellcheck-H', 'diffcheck-H', 'docclaims-H', 'workflow-audit-H', 'golden-H', 'determinism-H', 'gen-instructions-H', 'worker-manifest-H', 'worker-verify-H']
accepted = {}
for name in names:
    receipt = data(name + '.json')
    assert receipt['head'] == H and receipt['tree'] == T and receipt['head_tree_unchanged'] and receipt['rc'] == 0, (name, receipt)
    log = pathlib.Path(receipt['log'])
    assert sha(log) == receipt['sha256'], name
    accepted[name] = receipt
policy = (out / 'full-policy-H-capable.log').read_text()
assert 'CA: 118/118 dat · 0 do · 0 hong' in policy
assert 'DOT BIEN: 431/431 bi giet dung ly do' in policy
assert 'TU KIEM PHAN HANG: DAT' in policy and 'TONG: DAT' in policy
assert not re.search(r'^\[(?:HONG|DO|DOT BIEN KHONG BI GIET DUNG|TU KIEM)\]', policy, re.M)
tl = (out / 'tl-full-H.log').read_text()
counts = re.findall(r'^== tl selftest ([1-9]\d*)/([1-9]\d*) ==$', tl, re.M)
assert len(counts) == 1 and counts[0][0] == counts[0][1], counts
instruction_counts = re.findall(r'^== gen_instructions selftest ([1-9]\d*)/([1-9]\d*) ==$', (out / 'gen-instructions-H.log').read_text(), re.M)
assert len(instruction_counts) == 1 and instruction_counts[0][0] == instruction_counts[0][1], instruction_counts
updaters = {}
for name in ['ubuntu-root-H', 'ubuntu-nonroot-H']:
    log = (out / (name + '.log')).read_text()
    assert 'SELFTEST 48/48' in log and 'COUNTS {"cases": 48, "mutants": 6, "mutant_controls": 6}' in log
    labels = re.findall(r'^PASS (.+)$', log, re.M)
    assert len(labels) == len(set(labels)) == 48 and not re.search(r'^FAIL ', log, re.M)
    updaters[name] = dict(results=labels, entrypoint_invocations=len(re.findall(r'^CASE ', log, re.M)), mutants=[x for x in labels if x.startswith('mutant-') and not x.startswith('mutant-control-')], controls=[x for x in labels if x.startswith('mutant-control-')])
    assert updaters[name]['entrypoint_invocations'] == 46
for name in ['docclaims-H', 'workflow-audit-H', 'golden-H', 'determinism-H', 'worker-manifest-H', 'worker-verify-H', 'eol-H']:
    assert data(name + '.log')['ok'] is True, name
controls = data('workflow-controls-results.json')
assert len(controls['contracts']) == 7 and len(controls['controls']) == 4 and all(x['passed'] for x in controls['controls'])
old = data('old-ef-five-policy-reds.json')
inventory = data('full-policy-inventory-H.json')
assert len(old['cases']) == 5 and all(x['rc'] == 3 and x['case'] in inventory['cases'] for x in old['cases'])
paired = [dict(case=x['case'], old_ef_rc=x['rc'], old_evidence='old-ef-five-policy-reds.json', final_H_status='passed as member of complete 118/118 inventory', final_evidence='full-policy-H-capable.log') for x in old['cases']]
assert git('diff', '--name-only', EF, H) == '.github/workflows/ci.yml'
assert not git('diff', '--name-only') and not git('diff', '--cached', '--name-only')
# Initial snapshot had zero ignored/untracked paths; archive only files created by this run.
generated = data('generated-file-cleanup.json') if (out / 'generated-file-cleanup.json').exists() else []
paths = subprocess.check_output(['git', 'ls-files', '-o', '-i', '--exclude-standard', '-z'], cwd=root).decode().split('\0')
parents = set()
for rel in filter(None, paths):
    source = root / rel
    assert source.is_file() and not source.is_symlink(), ('unexpected generated entry', rel)
    dest = out / 'generated-files' / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)
    assert sha(source) == sha(dest)
    generated.append(dict(path=rel, bytes=source.stat().st_size, sha256=sha(source), archived=str(dest.relative_to(out))))
    parent = source.parent
    while parent != root:
        parents.add(parent)
        parent = parent.parent
    source.unlink()
for parent in sorted(parents, key=lambda p: len(p.parts), reverse=True):
    try:
        parent.rmdir()
    except OSError:
        pass
(out / 'generated-file-cleanup.json').write_text(json.dumps(generated, indent=2) + '\n')
assert not git('status', '--porcelain=v1', '--ignored')
assert git('rev-parse', 'HEAD') == H and git('rev-parse', 'HEAD^{tree}') == T
for row in data('five-inherited-blobs-H.json'):
    assert git('hash-object', row['path']) == row['H_blob'] == row['ef_blob']
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
assert now < '2026-11-05T06:41:01', now
summary = dict(head=H, tree=T, parent=EF, immutable_baseline=EC, sealed_at=now, identity=dict(provider='codex', model_family='openai', execution_surface='codex_service', transport='machine', environment='cloud', role='executor', session_id='/root/wp1178_r5_executor'), accepted_gates=accepted, full_policy=dict(cases='118/118', mutants='431/431', positive_lines=[x for x in policy.splitlines() if x.startswith(('CA:', 'DOT BIEN:', 'KIEM KE:', 'TU KIEM PHAN HANG:', 'TONG:'))]), tl_selftest='/'.join(counts[0]), updaters=updaters, paired_policy=paired, five_inherited_blobs=data('five-inherited-blobs-H.json'), workflow_byte_proof=data('workflow-baseline-byte-proof-H.json'), freeze=data('freeze.json'), source_clean_including_ignored=True, generated_files_archived_then_removed=len(generated), failed_or_partial_attempts=data('attempt-disposition.json'), current_master_admission=dict(status='failed', rc=12, S='e62664871b6dfe48b0bed54a7d1eb9a81796e372', qualification='current at direct remote probe, later canonical moved; not ancestor of H; not a green current-master admission', evidence='admission-H-current-e626.json'), external_controller_evidence=dict(native_windows_path='/workspace/scratch/wp1178-r5-g5/windows/controller-verification.json', qualification='controller-owned measurement; no Executor native Windows execution claim'), actionlint_limit='actionlint 1.7.7 reports zero parse/total errors; optional pyflakes executable absent and its rule disabled; no bare Ruff claim', optional_preparations_not_executed=['baseline-a7-update-linux.sh', 'harness-integrity.py'], publication=dict(sourcepush=False, github_write=False, model_review=False, merge=False, land=False, deploy=False))
(out / 'final-evidence-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
handoff = dict(schema_version=1, packet_id='wp1178', revision=5, generation=5, spec_hash='da794b6d67489851d05eae3e64d3b08686bf0b4cd76c96a022d1958943c5afe6', **summary['identity'], base_sha=EC, continuation_base_sha=EF, head_sha=H, tree_sha=T, status='needs_followup', summary='Approved single existing CI run body implemented; required Executor offline gates passed on committed H. Current-master nonancestry admission remains rc12 for controller drift disposition.', changed_paths=['.github/workflows/ci.yml'], tests=[dict(name=n, status='passed', evidence=n+'.json') for n in names], test_selection=dict(gate_tier='T2', selector_policy_sha=sha(out/'spec.frozen'), tested_sha=H, selected_groups=['full policy suite', 'full tl selftest', 'actual embedded Ubuntu root/nonroot', 'workflow contracts and run controls', 'supporting offline gates'], full_fallback_reason='Sensitive workflow change; frozen r5 A5 mandates full actual suites'), remaining_work=['Controller native M3 receipt integration', 'Independent personal human audit exact H before sourcepush', 'Controller sourcepublication/connector/PR CI/M9 and provenance', 'Actual ADR0063 land and K0–K7 before product land', 'Exact-H owner land authority, drift/integrated-tree/postmerge gates, M8/D1–D4 and lease release'], next_role='human', manual_next_action='Read frozen r5 spec and full ec1-to-H.patch on exact H; controller consumes sealed offline evidence and separate native Windows receipt, then follows authorized publication and land gates.', copyable_prompt='Continue controller duties for wp1178 r5/g5 on exact '+H+' tree '+T+'. Executor source is frozen; do not edit or rebase it. Use HANDOFF.md and final-evidence-summary.json, perform personal audit/publication/CI/connector/land within separately granted authority.', failure=dict(fingerprint=None, category=None), successors=[])
(out/'handoff.json').write_text(json.dumps(handoff, ensure_ascii=False, indent=2)+'\n')
text = f'''Executor handoff — wp1178 r5/g5 — sealed {now}

Source frozen at {H}, tree {T}, sole parent {EF}. Immutable acceptance baseline {EC}. Checkout /workspace/scratch/wp1178-r5-g5/candidate, inherited physical branch agent/wp1178-g4-codex-service. Identity: Codex / openai family / codex_service / cloud / machine; Executor only. Git author configuration was inherited as Duc Thang <ducthangho@gmail.com>; the source writer was this separate Executor.

Authority: owner decision https://github.com/ducthangho/tra-luat/issues/1178#issuecomment-6650226071. Frozen spec e631c7aa6d5b9865613ce6c7697978c3ca5d3a9a:ops/specs/wp1178-r5-ci.md SHA256 da794b6d67489851d05eae3e64d3b08686bf0b4cd76c96a022d1958943c5afe6. Lease 2816c7c865d33abfa5655f2c630159975c17ba3f:ops/leases/wp1178-r5-g5-codex-service.yaml SHA256 b0d25ff243f4680f1381d6f4c142784848f9e74b329e45aaa8265147091516ac. Local authoritative bytes verified equal. Grant 05:11:01Z; hard deadline 06:41:01Z, unchanged. Authority and history remain in authority.json and frozen bytes.

Only ci.yml changed from ef: +6/-5. Full ec1..H: six files/+1183/-1, within approved six/+1300 cap. All five environment blobs, including updater and embedded harness, remain exact ef. Entire workflow outside the one existing lease-publish run scalar is byte-identical ec1: all names, if/shell/env, step order, setup/G5, jobs/matrices/triggers/permissions are preserved. The standalone updater step was removed and the existing Bash run body now enables fail-fast, executes the original wrapper first, then uses POSIX test to invoke updater selftest only on Linux. Exact workflow bytes independently rederived from frozen spec match the approved proposal SHA256 aed785d6f1911f390fe1190d5caa575de58a5531252afc6f83981ca19681be67. Source patches: ef-to-H.patch and ec1-to-H.patch.

Final committed-H measurements:
- Full actual ops/ci_duong_nhanh_test.py: rc0,118/118 cases,431/431 semantic mutants killed correctly, built-in healthy controls and classification selfchecks DAT; TONG:DAT. Full inventory and positive lines are bound in final-evidence-summary.json. The five old ef policy refusals each reproduced with rc3 and are paired with membership in the final complete passing inventory.
- Actual embedded updater entrypoints: root rc0,48/48; UID1000 rc0,48/48. Each has six semantic mutants, six healthy mutant controls,46 actual --apply fixture invocations, and harness crash/import/mutation/network/zero-test controls. This is fixture behavior, with stubs and ephemeral HOME/repo/PATH; no real installers or credentials. Ubuntu24.04.5/Python3.12.3/procps4.0.4; cached image sha256:47777daafd44f5a8e0bec4ee5c4d59a22b90bad58890a5a7d75dbb09052b96c2, source read-only, --network none, separate container scratch, no credential/config mounts or secret env flags.
- Full tl.py --selftest: rc0,{summary['tl_selftest']} on host Python3.12.14. Configured TL/provider credential variables removed. This is Linux host evidence, separate from native Windows.
- Seven canonical registry workflow contracts, four workflow statics and four actual run-body controls passed: Linux baseline+updater; Windows baseline-only; baseline failure stops; updater failure propagates. Actionlint1.7.7 verbose: zero parse/total errors; optional pyflakes unavailable, rule disabled. No bare Ruff claim.
- EOL rc0,ok=true,11195 checked/11225 scanned,30 policy skips,zero violations. Doctrine/ADR checks, updater/login Bash syntax, ShellCheck and diffcheck passed. Docclaims/workflow/golden/determinism, gen_instructions and temporary worker manifest/strict verify passed. Exact commands,rc,time,H/tree,log sizes and hashes are in per-gate JSON and final-evidence-summary.json.

Admission: actual canonical checker bytes from directly measured e62664871b6dfe48b0bed54a7d1eb9a81796e372, blob f405aef1f17fa1a80b43ccb427d6dd9e9fcd1ec1, SHA256 a4bf95b539e077edbb706afee6fc37b157815c0c246ca1bb01b307106d7be480. Immutable ec1 S→H admission rc0 with exact H/tree receipt. Separately, e626(current at probe) S→H admission rc12: S is not an ancestor; direct ancestry rc1. This is a measured failure, not current-master admission green. Canonical later moved, and the controller owns drift/integrated-tree/postmerge disposition.

Failure history is preserved. First full-policy attempt in default sandbox encountered real AF_UNIX socket PermissionError at t20zo: case phase117/118,0DO/1HONG. Its verified own PID tree was operator-stopped, rc-15, mutant phase incomplete, excluded from credit. Same actual case passed with scoped runtime capability, then the entire suite passed in that capable runtime. One literal-HEAD admission command was rejected rc2; corrected full-OID command passed. Initial Docker socket sandbox denial is recorded. No crash/setup/timeout/empty test output is treated as pass. Unexecuted prepared baseline/harness helper files carry no gate credit. R4 historical evidence stays untouched.

Tracked/untracked/ignored checkout is clean after archiving and removing only {len(generated)} files generated by this run; initial snapshot was empty. Source H/tree and all inherited blobs are unchanged. Machine handoff: handoff.json. Evidence index: final-evidence-summary.json. Manifest hashes all artifacts, including raw failures and archived generated fixtures. The evidence index is an aid; omissions found by the human auditor remain findings.

Controller work remains: separate native Windows M3 evidence integration (controller-verification.json already supplied under ../windows; no Executor native execution claim), personal human audit of this exact new H before sourcepush, authorized publication/connector/PR CI/M9 with provenance, actual ADR0063 land and K0–K7, owner exact-H land authority, drift/integration/postmerge gates, M8/D1–D4, lease release and mission accounting. No sourcepush, GitHub write, model review, approval, ready, merge, land, deploy or LIVE action was performed by this Executor. No source changes are planned after seal.
'''
(out/'HANDOFF.md').write_text(text)
manifest = dict(head=H, tree=T, sealed_at=now, files=[dict(path=str(p.relative_to(out)), bytes=p.stat().st_size, sha256=sha(p)) for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ('evidence-manifest.json','evidence-manifest.sha256')])
(out/'evidence-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
digest = sha(out/'evidence-manifest.json')
(out/'evidence-manifest.sha256').write_text(digest+'  evidence-manifest.json\n')
print(json.dumps(dict(head=H,tree=T,tl_selftest=summary['tl_selftest'],full_policy='118/118;431/431',ubuntu='root48/48;nonroot48/48',generated_files=len(generated),manifest_sha256=digest,handoff=str(out/'HANDOFF.md'))))
