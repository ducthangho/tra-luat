import hashlib, importlib.util, json, os, pathlib, subprocess, tempfile, yaml
root = pathlib.Path('/workspace/scratch/wp1178-r5-g5/candidate')
out = root.parent / 'artifacts'
canonical = 'e62664871b6dfe48b0bed54a7d1eb9a81796e372'
registry_bytes = subprocess.check_output(['git', 'show', canonical + ':.claude/dev/ci_dang_ky_test.py'], cwd=root)
registry_path = out / 'canonical-ci-dang-ky.py'
registry_path.write_bytes(registry_bytes)
spec = importlib.util.spec_from_file_location('canonical_registry', registry_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
source = (root / '.github/workflows/ci.yml').read_text()
data = yaml.safe_load(source)
results = {}
for name in ('loi_ruff_ci', 'loi_ci_dispatch_windows'):
    value = getattr(module, name)(source=source)
    assert not value[0] and value[1] > 0, (name, value)
    results[name] = value
for name in ('loi_gate_nhanh', 'loi_vung_thiet_lap', 'loi_env_registry', 'loi_g5_workflow'):
    value = getattr(module, name)(data)
    assert not value, (name, value)
    results[name] = value
value = module.loi_workflow_dot_bien_du(yaml.safe_load((root / '.github/workflows/ci-dot-bien-du.yml').read_text()), data)
assert not value, value
results['loi_workflow_dot_bien_du'] = value
steps = data['jobs']['gate-ops']['steps']
step = next(s for s in steps if s.get('name') == 'lease-publish selftest (đo lại setup sau G5)')
body = step['run']
assert body == 'set -euo pipefail\nbash ops/chay_lease_publish_test.sh\nif test "$RUNNER_OS" = Linux; then\n  bash ops/environment/update-linux.sh --selftest\nfi\n'
assert sum('bash ops/environment/update-linux.sh --selftest' in s.get('run', '') for s in steps) == 1
assert not any(s.get('name') == 'Linux updater selftest (wp1178)' for s in steps)
baseline_data = yaml.safe_load(subprocess.check_output(['git', 'show', 'ec1b18a2a007fc2e697249c727a2ca8391ab209e:.github/workflows/ci.yml'], cwd=root, text=True))
baseline_steps = baseline_data['jobs']['gate-ops']['steps']
assert [s.get('name', s.get('uses')) for s in steps] == [s.get('name', s.get('uses')) for s in baseline_steps]
baseline_step = next(s for s in baseline_steps if s.get('name') == step['name'])
assert {k:v for k,v in step.items() if k != 'run'} == {k:v for k,v in baseline_step.items() if k != 'run'}
controls = []
with tempfile.TemporaryDirectory(prefix='wp1178-ci-controls-', dir='/tmp') as tmp:
    directory = pathlib.Path(tmp)
    (directory / 'ops/environment').mkdir(parents=True)
    (directory / 'ops/chay_lease_publish_test.sh').write_text('printf "baseline\\n" >> "$FIX_LOG"\nexit "$BASELINE_RC"\n')
    (directory / 'ops/environment/update-linux.sh').write_text('test "$1" = --selftest || exit 91\nprintf "updater --selftest\\n" >> "$FIX_LOG"\nexit "$UPDATER_RC"\n')
    script = directory / 'actual-run-body.sh'
    script.write_text(body)
    for name, runner, baseline_rc, updater_rc, expected_rc, expected_calls in [
        ('Linux-baseline-and-updater', 'Linux', 0, 0, 0, ['baseline', 'updater --selftest']),
        ('Windows-baseline-only', 'Windows', 0, 0, 0, ['baseline']),
        ('baseline-failure-stops-updater', 'Linux', 23, 0, 23, ['baseline']),
        ('updater-failure-propagates', 'Linux', 0, 29, 29, ['baseline', 'updater --selftest']),
    ]:
        log = directory / 'calls.log'
        log.write_text('')
        env = {'PATH': '/usr/bin:/bin', 'RUNNER_OS': runner, 'BASELINE_RC': str(baseline_rc), 'UPDATER_RC': str(updater_rc), 'FIX_LOG': str(log)}
        result = subprocess.run(['/bin/bash', str(script)], cwd=directory, env=env, capture_output=True, text=True)
        calls = log.read_text().splitlines()
        assert result.returncode == expected_rc and calls == expected_calls, (name, result.returncode, calls)
        controls.append({'id': name, 'command': result.args, 'runner_os': runner, 'baseline_rc': baseline_rc, 'updater_rc': updater_rc, 'expected_rc': expected_rc, 'actual_rc': result.returncode, 'calls': calls, 'passed': True})
report = {'registry_source_commit': canonical, 'registry_source_sha256': hashlib.sha256(registry_bytes).hexdigest(), 'contracts': results, 'workflow_statics': {'one_updater_invocation': True, 'no_standalone_step': True, 'existing_step_metadata_preserved': True, 'baseline_step_order_preserved': True}, 'actual_run_body': body, 'actual_run_body_sha256': hashlib.sha256(body.encode()).hexdigest(), 'controls': controls}
(out / 'workflow-controls-results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
print('REGISTRY_CONTRACTS 7/7; WORKFLOW_STATICS 4/4; ACTUAL_RUN_BODY_CONTROLS 4/4')
