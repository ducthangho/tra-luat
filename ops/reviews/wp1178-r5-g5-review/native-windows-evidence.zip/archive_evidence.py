import pathlib,json,hashlib,base64,zipfile
s=pathlib.Path(__file__).resolve().parent;d=json.loads((s/'paired-evidence.json').read_text(encoding='utf8'));assert d['rc']==0 and [len(r['tests']) for r in d['runs']]==[4,7] and all(t['ket_qua']=='passed' for r in d['runs'] for t in r['tests']);assert (s.parent/'KHOA.txt').stat().st_size==0
names=[p.name for p in s.iterdir() if p.is_file() and p.suffix in ('.json','.log','.py') and p.name!='archive-manifest.json'];m={'head':d['candidate'],'scope':'native Windows baseline4/candidate7; no Linux installer credit','lock_bytes_after_driver':0,'files':{}}
for n in sorted(names):
 b=(s/n).read_bytes();m['files'][n]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(s/'archive-manifest.json').write_text(json.dumps(m,indent=2)+'\n',encoding='utf8')
with zipfile.ZipFile(s/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for n in names+['archive-manifest.json']:z.write(s/n,n)
b=(s/'evidence.zip').read_bytes();(s/'evidence.zip.b64').write_text(base64.b64encode(b).decode(),encoding='ascii');print(json.dumps({'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'files':len(names)+1,'lock_released':True}))
