import pathlib, subprocess, os, sys, json, hashlib, datetime, time, csv, traceback, platform, base64
S=pathlib.Path(r'D:\tl-win\codex-wp1178-g5-91686a6-m3-20261105')
R=S/'repo'; L=S.parent/'KHOA.txt'; SID=S.name
BASE='ec1b18a2a007fc2e697249c727a2ca8391ab209e'
HEAD='91686a66d855a9ddae9dcf4567b13ddaa092cbc2'
TREE='e9d2b287343f44ac29a0713e0c0ea6b909aa408c'
BASH=r'C:\Program Files\Git\bin\bash.exe'
PWSH=r'D:\Program Files\PowerShell\7\pwsh.exe'
os.environ.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',GIT_TERMINAL_PROMPT='0')
os.environ['PATH']=r'C:\Program Files\Git\bin;C:\Program Files\Git\usr\bin;'+os.environ['PATH']
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(b):return hashlib.sha256(b).hexdigest()
result={'schema':'wp1178_windows_paired.v1','session':SID,'machine':platform.node(),'os':platform.system(),'single_orchestrator':True,'baseline':BASE,'candidate':HEAD,'started_at_utc':utc(),'runs':[],'errors':[], 'limitations':['Native Windows selected common checks and candidate updater check/login; Linux regression measured separately on Ubuntu. No Apply/Latest/installer/profile/credential operations.']}
def save(): (S/'paired-evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
def lock():
    if not L.read_text(encoding='utf-8-sig').startswith(SID+'\t'):raise RuntimeError('Coordination lock lost')
def heartbeat():
    lock();fields=L.read_text(encoding='utf-8-sig').split('\t');fields[-1]=utc();L.write_text('\t'.join(fields),encoding='utf-8')
def cmd(args,tag,timeout=180):
    lock();p=subprocess.run(args,cwd=R if R.exists() else S,capture_output=True,timeout=timeout)
    raw=p.stdout+b'\n--- STDERR ---\n'+p.stderr;(S/(tag+'.log')).write_bytes(raw)
    return {'command':args,'rc':p.returncode,'stdout_sha256':digest(p.stdout),'stderr_sha256':digest(p.stderr),'log':tag+'.log','log_sha256':digest(raw)},p.stdout.decode('utf8','replace')
def git(*args):
    p=subprocess.run(['git','-C',str(R),*args],capture_output=True,timeout=180)
    if p.returncode:raise RuntimeError('Git failed '+repr(args)+': '+p.stderr.decode('utf8','replace')[-1000:])
    return p.stdout.decode('utf8','replace').strip()
def record(run,name,info,ok,extra=None):
    row={'id':name,**info,'ket_qua':'passed' if ok else 'failed'}
    if extra:row.update(extra)
    run['tests'].append(row);print(run['label'],name,row['ket_qua'],flush=True);save()
def logrun(run):
    fields=['thoi_diem','session','packet','sha','bo_test','dat','tong','ca_do','thoi_luong_s','phat_hien_boi','loi_that','da_va','ghi_chu']
    path=S.parent/'do-luong.csv';exists=path.exists() and path.stat().st_size>0
    passed=sum(t['ket_qua']=='passed' for t in run['tests']);total=len(run['tests'])
    with path.open('a',encoding='utf8',newline='') as f:
        w=csv.writer(f)
        if not exists:w.writerow(fields)
        w.writerow([utc(),SID,'1178',run['sha'],run['label'],passed,total,total-passed,round(run['elapsed_seconds'],3),'local','not_classified','no','may=ASUS-LAPTOP; selected native paired; no Apply; no Linux credit'])
try:
    lock();assert platform.system()=='Windows'
    data=base64.b64decode((S/'candidate.bundle.b64').read_text())
    assert digest(data)=='cc8ca59369c2f86baf7746d1927a0e555db73776a1fe8dcbb83117f365b579e5'
    (S/'candidate.bundle').write_bytes(data)
    assert not R.exists(),'Do not overwrite an existing clone'
    info,out=cmd(['git','clone','--no-checkout','--reference-if-able',r'D:\tl-win\codex-wp1178-g4-ef864d6-m3-20261105\repo','https://github.com/ducthangho/tra-luat.git',str(R)],'clone',240)
    assert info['rc']==0,'Clone failed'
    git('config','core.autocrlf','false');git('config','core.eol','lf');git('config','core.abbrev','7')
    git('bundle','verify',str(S/'candidate.bundle'))
    git('fetch',str(S/'candidate.bundle'),'HEAD:refs/heads/candidate-local')
    git('sparse-checkout','init','--no-cone')
    git('sparse-checkout','set','--no-cone','/.claude/','/.agents/','/ops/','/scripts/','/docs/','/.github/','/AGENTS.md','/CLAUDE.md','/CONTEXT.md','/tl-setup.ps1')
    for label,h in [('baseline',BASE),('candidate',HEAD)]:
        heartbeat();git('checkout','--detach',h);assert git('rev-parse','HEAD')==h
        tree=git('rev-parse','HEAD^{tree}');assert label!='candidate' or tree==TREE
        start=time.monotonic();run={'label':label,'sha':h,'tree':tree,'parents':git('show','-s','--format=%P','HEAD'),'started_at_utc':utc(),'tests':[]};result['runs'].append(run);save()
        info,out=cmd(['git','diff','--check',BASE,h],label+'-diff');record(run,'git-diff-check',info,info['rc']==0)
        info,out=cmd(['python','ops/cong_cu.py','kiem-tra','--json'],label+'-checker',180)
        d=json.loads(out);tools=d.get('cong_cu');canary=d.get('canary');good=info['rc']==0 and d.get('trang_thai_tong')=='DAT' and isinstance(tools,list) and bool(tools) and all(x.get('trang_thai')=='DAT' for x in tools) and isinstance(canary,list) and bool(canary) and all(x.get('trang_thai')=='DAT' for x in canary)
        record(run,'shared-checker-nonempty-canary-DAT',info,good,{'tool_results':tools,'canary_results':canary,'summary':d.get('trang_thai_tong')})
        tracked=git('ls-files').splitlines();ps=[x for x in tracked if x.endswith('.ps1') and (R/x).is_file()];sh=[x for x in tracked if x.endswith('.sh') and (R/x).is_file()];assert ps and sh
        (S/(label+'-ps-inventory.json')).write_text(json.dumps(ps),encoding='utf8')
        parse="$ErrorActionPreference='Stop'; $files=Get-Content -Raw -LiteralPath '"+str(S/(label+'-ps-inventory.json'))+"' | ConvertFrom-Json; $bad=0; foreach($f in $files) { $tok=$null;$err=$null; [System.Management.Automation.Language.Parser]::ParseFile((Join-Path '"+str(R)+"' $f),[ref]$tok,[ref]$err)|Out-Null; if($err.Count){$bad++; Write-Output ('BAD '+$f);$err|ForEach-Object{$_.Message}} }; Write-Output ('PARSED='+$files.Count+' BAD='+$bad); if($bad){exit 1}"
        info,out=cmd([PWSH,'-NoProfile','-Command',parse],label+'-ps-parser');record(run,'powershell-parser-inventory',info,info['rc']==0 and 'PARSED='+str(len(ps))+' BAD=0' in out,{'inventory':ps})
        rows=[]
        for i,path in enumerate(sh):
            inf,output=cmd([BASH,'-n',path],label+'-bash-'+str(i));rows.append({'path':path,**inf})
        record(run,'bash-syntax-inventory',{'command':[BASH,'-n','each tracked .sh'],'rc':0 if all(x['rc']==0 for x in rows) else 1},bool(rows) and all(x['rc']==0 for x in rows),{'inventory':rows})
        if label=='candidate':
            info,out=cmd([PWSH,'-NoProfile','-File','ops/environment/update-windows.ps1','-Repo',str(R)],'candidate-updater-check',180)
            record(run,'updater-check-only',info,info['rc']==0 and 'Checker exit code: 0.' in out)
            login="$ErrorActionPreference='Stop'; $before=[Environment]::GetEnvironmentVariable('Path','User'); . '"+str(R/'ops/environment/login-windows.ps1')+"'; $one=$env:Path; . '"+str(R/'ops/environment/login-windows.ps1')+"'; if($env:Path -cne $one){throw 'PATH not idempotent'}; if($env:TL_REPO -cne '"+str(R)+"'){throw 'TL_REPO mismatch'}; if([Environment]::GetEnvironmentVariable('Path','User') -cne $before){throw 'Persistent PATH changed'}; Write-Output 'LOGIN_IDEMPOTENT=1 PERSISTENT_PATH_UNCHANGED=1'"
            info,out=cmd([PWSH,'-NoProfile','-Command',login],'candidate-login-idempotence');record(run,'login-idempotence',info,info['rc']==0 and 'LOGIN_IDEMPOTENT=1 PERSISTENT_PATH_UNCHANGED=1' in out)
            import yaml
            wf=yaml.safe_load((R/'.github/workflows/ci.yml').read_text(encoding='utf8'))
            steps=wf['jobs']['gate-ops']['steps']; matches=[x for x in steps if x.get('name','').startswith('lease-publish selftest')];assert len(matches)==1
            body=matches[0]['run']; assert 'bash ops/environment/update-linux.sh --selftest' in body and 'if test "$RUNNER_OS" = Linux' in body
            pre='bash() { if [ "$1" = ops/chay_lease_publish_test.sh ]; then echo BASELINE_ONLY=1; else echo UNEXPECTED_LINUX_CALL; return 77; fi; }\nexport RUNNER_OS=Windows\n'
            info,out=cmd([BASH,'-c',pre+body],'candidate-existing-CI-step-Windows-guard')
            record(run,'existing-CI-runbody-Windows-skips-Linux',info,info['rc']==0 and out.strip()=='BASELINE_ONLY=1',{'actual_yaml_run_body':body,'method':'Actual run bytes, stub baseline command only; Windows native Bash and RUNNER_OS Windows; Linux actual entrypoints measured separately on Ubuntu'})
            inherited=['ops/environment/'+x for x in ['README.md','login-linux.sh','login-windows.ps1','update-windows.ps1','update-linux.sh']]
            run['inherited_blobs']={x:{'ef':git('rev-parse','ef864d6b3192a08487cd7fc0e526633afcb693d9:'+x),'H':git('rev-parse',HEAD+':'+x)} for x in inherited};assert all(x['ef']==x['H'] for x in run['inherited_blobs'].values())
        run['elapsed_seconds']=time.monotonic()-start;run['completed_at_utc']=utc();logrun(run);save()
    result['rc']=0 if all(t['ket_qua']=='passed' for r in result['runs'] for t in r['tests']) else 1
    candidate=result['runs'][-1];(S/'windows.json').write_text(json.dumps({'sha':HEAD,'tree':TREE,'os':'Windows','machine':platform.node(),'tests':candidate['tests'],'paired_evidence':'paired-evidence.json'},ensure_ascii=False,indent=2),encoding='utf8')
except BaseException as e:
    result['rc']=2;result['errors'].append({'error':str(e),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:
    result['completed_at_utc']=utc();save()
    try:lock();L.write_bytes(b'');print('LOCK_RELEASED',flush=True)
    except Exception as e:print('LOCK_NOT_RELEASED:'+str(e),flush=True)
    print('PAIRED_RC='+str(result.get('rc',2)),flush=True)
sys.exit(result.get('rc',2))
