import pathlib,subprocess,os,hashlib,json,datetime,csv,sys
W=pathlib.Path(r'C:\tl-win\wp1271-r9-field-key-probe-v2');I=pathlib.Path(r'C:\tl-win\wp1271-g8-measure-inputs')
R=pathlib.Path(r'C:\tl-win\wp1271-r8-g8\final-d04745248666\candidate')
LOCK=pathlib.Path(r'C:\tl-win\KHOA.txt');SID='wp1271-r9-field-key-H6-advisory-v2';taken=False;rows=[]
PS51=r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe';PS7=r'C:\Program Files\PowerShell\7\pwsh.exe';GIT=r'C:\tl-win\wp1271-tools\mingit-2.56.0.4\cmd\git.exe'
MODULE=R/'.agents/skills/proxima-control/scripts/ProximaConfig.psm1'
def now():return datetime.datetime.now(datetime.timezone.utc)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(n,v):(W/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env['PSModulePath']=r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules';env.update(PYTHONUTF8='1',PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
for k in list(env):
 if k.startswith('TL_') or k in ['GH_TOKEN','GITHUB_TOKEN','CLAUDE_CODE_OAUTH_TOKEN','ANTHROPIC_API_KEY','OPENAI_API_KEY','CODEX_AUTH_JSON']:env.pop(k,None)
def run(args,label,allowed=(0,),pe=None):
 p=subprocess.run(args,env=pe or env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
 (W/(label+'.log')).write_bytes(p.stdout);rows.append(dict(label=label,command=args,rc=p.returncode,output_sha256=hashlib.sha256(p.stdout).hexdigest()))
 if p.returncode not in allowed:raise RuntimeError(label+' rc='+str(p.returncode))
 return p.returncode,p.stdout.decode('utf-8-sig',errors='replace').strip()
def beat():
 if LOCK.read_text(encoding='utf-8-sig').split('\t')[0]!=SID:raise RuntimeError('Lost own lock; no overwrite')
 n=now();assert n<start+datetime.timedelta(hours=2)
 LOCK.write_text('\t'.join([SID,start.isoformat(),(start+datetime.timedelta(hours=2)).isoformat(),'H6 schema-key advisory PS51+7',n.isoformat()])+'\n',encoding='utf-8');save('heartbeat.json',dict(at=n.isoformat(),readback=LOCK.read_text(encoding='utf-8-sig')))
try:
 before=LOCK.read_text(encoding='utf-8-sig') if LOCK.exists() else ''
 if before.strip():raise RuntimeError('Host lock occupied; do not steal')
 if W.exists():raise RuntimeError('Probe directory exists; do not rerun')
 W.mkdir();start=now();LOCK.write_text(SID+'\t'+start.isoformat()+'\t'+(start+datetime.timedelta(hours=2)).isoformat()+'\tH6 schema-key advisory\t'+start.isoformat()+'\n',encoding='utf-8');taken=True;beat();save('lock-acquisition.json',dict(before=before,readback=LOCK.read_text(encoding='utf-8-sig')))
 if sha(MODULE)!='2457a18e3c4e337b142cffc630d382693de7601b83f4ebf3b3a6b6a709552b97':raise RuntimeError('Wrong H6 module bytes')
 _,head=run([GIT,'-C',str(R),'rev-parse','HEAD'],'head-before');assert head=='d047452486663c5e9c3bf234f3a62a3254213065'
 _,tree=run([GIT,'-C',str(R),'rev-parse','HEAD^{tree}'],'tree-before');assert tree=='e05d76ce4109463d69026b7b44306ba2b437e2c3'
 _,status=run([GIT,'-C',str(R),'status','--porcelain'],'status-before');assert not status
 load="Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | Select-Object ProcessId,ParentProcessId,CreationDate | ConvertTo-Json -Compress"
 run([PS51,'-NoProfile','-NonInteractive','-Command',load],'load-before')
 policy="if((Get-ExecutionPolicy -Scope MachinePolicy) -ne 'Undefined' -or (Get-ExecutionPolicy -Scope UserPolicy) -ne 'Undefined'){throw 'Managed policy'};Get-ExecutionPolicy -List|ConvertTo-Json -Compress"
 run([PS51,'-NoProfile','-NonInteractive','-Command',policy],'policy')
 results={}
 for name,exe in [('ps51',PS51),('ps7',PS7)]:
  pe=env.copy();pe['PSModulePath']=(r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules' if name=='ps51' else r'C:\Program Files\PowerShell\7\Modules')+r';C:\Program Files\WindowsPowerShell\Modules'
  report=W/(name+'.json');rc,_=run([exe,'-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(I/'field-key-h6-probe.ps1'),'-ModulePath',str(MODULE),'-RepositoryRoot',str(R),'-Scratch',str(W/(name+'-scratch')),'-ReportPath',str(report)],name,allowed=(0,1),pe=pe)
  d=json.loads(report.read_text(encoding='utf-8-sig'));assert d['cleanup_ok'] and d['module_unchanged'] and d['total']==38 and all(c['input_bytes_unchanged'] for c in d['cases'])
  results[name]=dict(child_rc=rc,total=d['total'],expected_matches=d['expected_matches'],accepted_unknown_keys=sum(c['accepted'] and c['expected']=='UnknownField' for c in d['cases']),culture_equal_count=sum(c['culture_contains'] for c in d['comparisons']),report_sha256=sha(report),report_bytes=report.stat().st_size,ps_version=d['ps_version']);beat()
  ledger=pathlib.Path(r'C:\tl-win\do-luong.csv');exists=ledger.exists() and ledger.stat().st_size
  with ledger.open('a',encoding='utf-8',newline='') as f:
   w=csv.writer(f)
   if not exists:w.writerow(['thoi_diem','session','packet','sha','bo_test','dat','tong','ca_do','thoi_luong_s','phat_hien_boi','loi_that','da_va','ghi_chu'])
   w.writerow([now().isoformat(),SID,'wp1271',head,'advisory-field-key-'+name,d['expected_matches'],d['total'],'unknown-key-collation',0,'independent-review4','pending-native-trace','no','not_acceptance;rc='+str(rc)])
 _,after=run([GIT,'-C',str(R),'status','--porcelain'],'status-after');assert not after and sha(MODULE)=='2457a18e3c4e337b142cffc630d382693de7601b83f4ebf3b3a6b6a709552b97'
 run([PS51,'-NoProfile','-NonInteractive','-Command',load],'load-after')
 save('receipt.json',dict(kind='advisory_not_acceptance',head=head,tree=tree,host=os.environ.get('COMPUTERNAME'),account=os.environ.get('USERNAME'),operator_sha256=sha(__file__),probe_sha256=sha(I/'field-key-h6-probe.ps1'),results=results,commands=rows,finished_at=now().isoformat()));print(json.dumps(results),flush=True);rc=0
except Exception as e:
 print(type(e).__name__+': '+str(e),flush=True);rc=2
 if W.exists():save('operator-error.json',dict(error=str(e),commands=rows))
finally:
 if taken and LOCK.read_text(encoding='utf-8-sig').split('\t')[0]==SID:
  final=LOCK.read_text(encoding='utf-8-sig');LOCK.write_text('',encoding='utf-8');save('lock-release.json',dict(before=final,after=LOCK.read_text(encoding='utf-8-sig'),released=True))
sys.exit(rc)
