param([string]$ModulePath,[string]$RepositoryRoot,[string]$Scratch,[string]$ReportPath)
$ErrorActionPreference='Stop'
$cases=[Collections.Generic.List[object]]::new();$comparisons=[Collections.Generic.List[object]]::new();$i=0
$before=(Get-FileHash -LiteralPath $ModulePath -Algorithm SHA256).Hash.ToLowerInvariant()
Import-Module $ModulePath -Force
$fields='schemaVersion','targetId','mode','basePath','connectionUri','configurationName'
$escape=[string][char]92+'u0000'
foreach($field in $fields){foreach($position in 0,([Math]::Floor($field.Length/2)),$field.Length){
 $actual=$field.Insert([int]$position,[string][char]0)
 $comparisons.Add([ordered]@{field=$field;position=$position;culture_contains=($fields -ccontains $actual);ordinal_equal=[string]::Equals($field,$actual,[StringComparison]::Ordinal)})
}}
function Measure-One([string]$Id,[string]$Json,[bool]$Reject){
 $p=Join-Path $Scratch ($Id+'.json');[IO.File]::WriteAllText($p,$Json,[Text.UTF8Encoding]::new($false));$hash=(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash
 $accepted=$false;$eid=$null;$properties=@()
 try{$out=Read-ProximaConfig -ConfigPath $p -RepositoryRoot $RepositoryRoot -ErrorAction Stop;$accepted=$true;$properties=@($out.PSObject.Properties.Name)}catch{$eid=$_.FullyQualifiedErrorId}
 $match=$(if($Reject){-not $accepted -and $eid -match '^ProximaConfig\.UnknownField(,|\z)'}else{$accepted})
 $cases.Add([ordered]@{id=$Id;expected=$(if($Reject){'UnknownField'}else{'accepted'});accepted=$accepted;error_id=$eid;expected_match=[bool]$match;returned_properties=$properties;input_bytes_unchanged=((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ceq $hash)})
}
$cleanup=$null
try{
 [IO.Directory]::CreateDirectory($Scratch)|Out-Null
 foreach($remote in $false,$true){
  $base=$(if($remote){'{"schemaVersion":1,"targetId":"probe-target","mode":"Remote","basePath":"C:\\px","connectionUri":"https://gw.example.invalid/wsman","configurationName":"Probe.Endpoint"}'}else{'{"schemaVersion":1,"targetId":"probe-target","mode":"Local","basePath":"C:\\px"}'})
  $mode=$(if($remote){'Remote'}else{'Local'});Measure-One "$mode-valid" $base $false
  foreach($field in $fields){foreach($pos in 0,([Math]::Floor($field.Length/2)),$field.Length){
   $i++;$key=$field.Insert([int]$pos,$escape);$json=$base.Substring(0,$base.Length-1)+',"'+$key+'":"extra"}';Measure-One "$mode-extra-$i" $json $true
  }}
 }
}finally{
 if([IO.Directory]::Exists($Scratch)){[IO.Directory]::Delete($Scratch,$true)}
 $cleanup=-not [IO.Directory]::Exists($Scratch)
 $after=(Get-FileHash -LiteralPath $ModulePath -Algorithm SHA256).Hash.ToLowerInvariant()
 $report=[ordered]@{kind='advisory_not_acceptance';head='d047452486663c5e9c3bf234f3a62a3254213065';ps_version=[string]$PSVersionTable.PSVersion;module_sha256=$before;module_unchanged=($before -ceq $after);comparisons=@($comparisons.ToArray());cases=@($cases.ToArray());total=$cases.Count;expected_matches=@($cases|Where-Object{$_.expected_match}).Count;cleanup_ok=$cleanup}
 [IO.File]::WriteAllText($ReportPath,($report|ConvertTo-Json -Depth 12),[Text.UTF8Encoding]::new($false))
}
if(-not $cleanup -or @($cases|Where-Object{-not $_.input_bytes_unchanged}).Count){exit 2}
if(@($cases|Where-Object{-not $_.expected_match}).Count){exit 1}
exit 0
