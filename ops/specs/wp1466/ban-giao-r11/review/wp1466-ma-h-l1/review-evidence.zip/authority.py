import hashlib,json,os,pathlib,subprocess,sys,unicodedata
OUT=pathlib.Path(__file__).resolve().parent; R=OUT.parent/'cay-kho'
def git(*args):return subprocess.check_output(['git','-C',str(R),*args],env=dict(os.environ,GIT_OPTIONAL_LOCKS='0'),text=True).strip()
import yaml
lease=yaml.safe_load(git('show','origin/ops/wp1466-r9-g2-lease:ops/leases/wp1466-r9-g2-claude.yaml'))
paths=git('diff','--name-only','695916e','da4e876').splitlines()
sha=hashlib.sha256(json.dumps(sorted(unicodedata.normalize('NFC',p).casefold() for p in paths),ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
checks={
 'head':git('rev-parse','HEAD')=='da4e876890a1ebe99bb87de9e9a3b4f63c9fd5dd',
 'lease_commit':git('rev-parse','origin/ops/wp1466-r9-g2-lease')=='c9a7a9838e82145ef7323ae34cac04c89f973706',
 'base':lease['base_sha']=='695916ea3bfffdd7b2e8fcb94b0740b3c421fe70',
 'ancestry':subprocess.run(['git','-C',str(R),'merge-base','--is-ancestor',lease['base_sha'],'HEAD']).returncode==0,
 'revision_generation':(lease['revision'],lease['generation'])==(9,2),
 'write_set':sorted(paths)==sorted(lease['write_set']),
 'write_set_hash':sha==lease['write_set_hash'],
 'spec_blob':git('rev-parse','HEAD:'+lease['spec_path'])==lease['spec_blob'],
 'spec_hash':hashlib.sha256((R/lease['spec_path']).read_bytes()).hexdigest()==lease['spec_hash'],
 'three_commits':git('rev-list','--count',lease['base_sha']+'..HEAD')=='3',
 'abbrev_7':git('config','core.abbrev')=='7',
 'not_shallow':git('rev-parse','--is-shallow-repository')=='false',
 'diff_clean':subprocess.run(['git','-C',str(R),'diff','--check',lease['base_sha'],'HEAD']).returncode==0,
}
print(json.dumps(checks,ensure_ascii=False,indent=2))
print('AUTHORITY',sum(checks.values()),'/',len(checks),'tree',git('rev-parse','HEAD^{tree}'))
print('LEASE_UNTIL',lease['lease_until'],'BRANCH',lease['branch'])
print('NUMSTAT\n'+git('diff','--numstat',lease['base_sha'],'HEAD'))
print('MODES\n'+git('diff','--raw',lease['base_sha'],'HEAD'))
print('COMMITS\n'+git('log','--format=%H %s',lease['base_sha']+'..HEAD'))
assert all(checks.values())
