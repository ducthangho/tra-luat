import json,os,pathlib,sys
out=pathlib.Path(__file__).resolve().parent
root=out/'base'
sys.path.insert(0,str(root/'.claude/dev'))
os.chdir(root)
import packet_loop_test as t
names={n for n,f in t.CASES if n.startswith(('cong_b4_vc_','cong_b4_gt4_'))}
print('BASE B4 SELECT',len(names),sorted(names),flush=True)
kq=t.chay_suite(t.CANONICAL,out/'b4-base-cases',names)
rows={n:{'pass':v is None,'skip':isinstance(v,t.BoQua),'result':None if v is None else str(v)} for n,v in kq.items()}
(out/'b4-base-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
for n,v in rows.items():print(n,json.dumps(v,ensure_ascii=False),flush=True)
print('BASE B4',sum(v['pass'] for v in rows.values()),'/',len(names),'SKIP',sum(v['skip'] for v in rows.values()),flush=True)
sys.exit(int(not all(v['pass'] for v in rows.values())))
