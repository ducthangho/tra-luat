import json, pathlib, re
out = pathlib.Path(__file__).resolve().parent
spec = (out.parent / 'cay-kho/ops/specs/wp1466.md').read_text()
table = spec.split('| chốt | luật |')[1].split('**Tập bắt buộc**')[0]
cases = set(re.findall(r'`(doctrine_inv_[a-zA-Z0-9_]+)`', table))
for stem in ('xoa', 'crlf', 'cach_cuoi'):
    cases.update(f'doctrine_inv_{stem}_K{i:02d}' for i in range(1,8))
mutants = set(re.findall(r'`((?:inv_|t1466_)[a-zA-Z0-9_]+)`', table))
mutants.update(f'inv_bo_khoa_K{i:02d}' for i in range(1,8))
log = (out / 'logs/registry-list.log').read_text()
new_cases = json.loads(next(x[4:] for x in log.splitlines() if x.startswith('T = ')))
new_mutants = json.loads(next(x.split(' = ',1)[1] for x in log.splitlines() if x.startswith('ĐỘT BIẾN MỚI = ')))
print('SPEC CASES', len(cases), 'MATCH', len(cases & set(new_cases)), 'MISSING', sorted(cases - set(new_cases)))
print('SPEC MUTANTS', len(mutants), 'MATCH', len(mutants & set(new_mutants)), 'MISSING', sorted(mutants - set(new_mutants)))
print('EXTRA CASES', sorted(set(new_cases)-cases))
print('EXTRA MUTANTS', sorted(set(new_mutants)-mutants))
assert len(cases)==57 and cases <= set(new_cases)
assert len(mutants)==26 and mutants <= set(new_mutants)
print('REQUIRED: 57/57 ca, 26/26 đột biến')
