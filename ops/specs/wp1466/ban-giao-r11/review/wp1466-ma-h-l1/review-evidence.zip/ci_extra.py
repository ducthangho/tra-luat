import pathlib,subprocess,sys
OUT=pathlib.Path(__file__).resolve().parent
H=OUT/'h'
jobs=[
 ('workflow-audit',['scripts/tl.py','workflow-audit','--strict','--json']),
 ('golden',['scripts/tl.py','golden-test','--json']),
 ('determinism',['scripts/tl.py','determinism-audit','--strict','--json']),
 ('release-check',['scripts/tl.py','release-check','--full','--json']),
 ('release-verify',['scripts/tl.py','release-verify','RELEASE_MANIFEST.json','--strict','--json']),
 ('eol',['.githooks/eol_policy.py','--all','--json']),
 ('ci-scope',['.github/checks/ci_phamvi.py','--kiem-bam']),
 ('ci-scope-tests',['.github/checks/ci_phamvi_test.py']),
]
for label,args in jobs:
    subprocess.run([sys.executable,'-B',str(OUT/'run_logged.py'),label,str(H),sys.executable,'-u','-B']+args)
