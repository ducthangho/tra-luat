from pathlib import Path
out=Path(__file__).resolve().parent
p=out/'VERDICT.md'
old=p.read_text()
findings=old[old.index('### phep-dem-ban-sao-khong-phu-ca-tep'):]
findings=findings.replace('packet_loop.py:1771','packet_loop.py:1774')
findings=findings.replace('ĐÃ THỬ NGHIỆM: `reviewer-mutants-stock.log`:', 'ĐÃ THỬ NGHIỆM: `reviewer-id-all-stock.log`: toàn bộ 63/63 ca mới và đối chứng vẫn đạt khi chỉ nhận ID 99. `reviewer-mutants-stock.log`:')
header='''verdict: blocked
reviewed_sha: da4e876890a1ebe99bb87de9e9a3b4f63c9fd5dd
base_sha: 695916ea3bfffdd7b2e8fcb94b0740b3c421fe70
spec_sha256: 28de9d574cb617442845c47db3ec5c65cd832386511775dfdd68ee7243ea6f7c
reviewer: {provider: codex, model_family: openai, surface: codex_cli, transport: machine, effort: high, session_id: KHONG_DO_DUOC}
review_axes: [Spec, Correctness, Tests, Standards/Security]
assurance: chưa cấp cross_approved; đích human_audited sau audit chủ kho
dem: {so_lop_mo: 2, so_bieu_hien_mo: 5, P0: 0, P1: 0, P2: 1, P3: 1}

Không đủ điều kiện approve. Còn một lớp P2 về hợp đồng đếm bản sao (Q3 chưa quyết) và một lớp P3 về độ phủ kiểm ID. Chọn **blocked** theo đặc tả §11: tìm thấy thiếu sót của đặc tả phải ra revision mới. Định nghĩa vận hành của phép (3) hẹp hơn lời hứa “nhân đôi … ở chỗ hiển thị bất kỳ”; không quy lỗi cho executor vì đã thực hiện đúng định nghĩa hẹp. Các gate chưa có bằng chứng dương được ghi riêng, không tự chuyển thành finding mới hay gọi là đã đạt.

Đây là review mã lượt 1, lời gọi Codex 11/13 theo giao việc; không tính các lượt review đặc tả thành lượt review mã. Không sửa kho, không push, không gọi API ghi. `effort: high` là cấu hình yêu cầu trong PROMPT; model/effort thực phục vụ và session ID không có biên nhận để kiểm độc lập. Không dùng danh tính executor làm bằng chứng cho reviewer.

## BẢNG LỚP — lớp MỞ

| slug lớp | finding IDs/biểu hiện | hạng cao nhất còn mở | nguồn lượt/SHA | phương án vá chung | phép kiểm đóng lớp |
|---|---|---|---|---|---|
| `phep-dem-ban-sao-khong-phu-ca-tep` | F01.a–d: chữ dính trước/sau khối; dòng chỉ dấu cách; trọn mục có đoạn nối; bản sao dính chữ ở đầu tệp | P2 | executor lượt 1 Q3; reviewer mã lượt 1 / da4e876 | chốt hợp đồng chung về bản sao, đồng bộ đặc tả/ADR/phép đếm | 7 khoá × vị trí × biên; nếu giữ lời hứa, bản sao thêm chữ phải đỏ, bản che xanh; đột biến đếm trọn đơn vị phải chết |
| `ca-id-chi-do-mot-gia-tri` | F02: sáu ca G8 đều quy về ID 99 | P3 | reviewer mã lượt 1 / da4e876 | thêm đại diện miền số và mutant chỉ nhận 99 | nền bổ sung xanh; mutant bị ca ID khác 99 giết; ba đối chứng khác họ sống |

Số biểu hiện đếm theo bốn dạng F01 và một dạng F02; 23 đầu vào lọt không phải 23 finding. F01 giữ đúng slug executor đã đặt; HANDOFF mục 7 đã nối nó với họ lịch sử `khoa-khong-neo-vi-tri-va-duy-nhat` (P1 của review đặc tả). Không đổi tên hay xoá lịch sử P1, không tính cùng phản chứng hai lần. Hạng P2 ở đây phản ánh mâu thuẫn hợp đồng về bản sao; không thấy đường sửa nội dung tại địa chỉ gốc mà vẫn qua băm.

Q3 chưa được miễn. Q0, Q2, Q4 và miễn Windows được dùng đúng nội dung chủ kho cung cấp trong PROMPT. Điều kiện của packet trong đặc tả §1 còn chặt hơn M1 mặc định: mọi P3 phải đóng, không dùng miễn P3. Review này không tạo nợ hoặc miễn mới.

## BẢNG LỚP ĐÃ ĐÓNG/ĐÃ KIỂM

Đối chiếu lịch sử §19 và handoff trên H. “Đã kiểm” chỉ áp dụng phạm vi ghi trong cột bằng chứng; không tuyên bố đóng nợ kế nhiệm.

| slug/nhóm đã có | kết luận trên H | bằng chứng dương và giới hạn |
|---|---|---|
| `neo-sai-don-vi-khop`, `neo-thieu-nghia-vu` | giữ phần đã vá: băm trọn 7 đơn vị tại địa chỉ | N5 7/7; các ca xoá câu/xoá khoá và mutant đều đạt; F01 riêng về bản sao |
| `kiem-chuoi-khong-doc-cau-truc` | giữ phần byte thô đã vá trong wp1466 | 35/35 biến thể byte độc lập; CRLF, splitlines, rstrip, che tại chỗ có mutant bị giết; phần ngữ nghĩa #1469 không nghiệm thu ở đây |
| `khoa-khong-neo-vi-tri-va-duy-nhat` | địa chỉ và bản sao đứng thành đơn vị đã kiểm; không kết luận đóng toàn bộ tính duy nhất | đổi tiêu đề cha rc9, hai mục cùng đường rc9, 7 bản sao nguyên đơn vị rc9; F01 là giới hạn còn mở được nối từ handoff |
| `tieu-chi-dong-xoa-khong-do-hanh-vi` | phạm vi cú pháp của H đạt | cả hai khối N8 in ĐẠT; đăng ký cũ giữ nguyên; không tái chạy toàn bộ 65 biến thể phá khối N8 của lịch sử |
| `dem-khong-khai-tap-ca`, `nghiem-thu-khoa-so-ca-trai-quyen-them` | tập đếm và quyền thêm được giữ | 57/57 ⊆ T=60; 26/26 ⊆ 29 mới; chênh CASES và Linux đều 60 |
| `doi-chung-khac-ho-chon-nham-doctrine`, `ma-tran-dem-doi-loi-thay-doi-mau` | vòng đo thật đạt trong tập yêu cầu | 29/29 mới và 21/21 cũ: ca đích chết, mỗi mutant có 3 đối chứng khác họ sống |
| `moc-dot-bien-tu-khop-trong-khai-bao`, `doi-diem-goi-cong-chua-du-yeu-cau` | giữ phần đã vá | ca kiểm mốc nằm trong nền 63/63; mutant bỏ lời gọi giết 54 ca; rc6 cũ vẫn giữ |
| Q0: con trỏ ca bị hiểu là selftest | đã kiểm sửa theo lớp trên r9 | protocol byte-exact với p1–p6; `doc-claims-check --strict` H và base đều `ok:true`, 0 flags |
| Q2: bỏ sót khối trước tiêu đề đầu | đã vá đúng phần khối độc lập; lớp F01 vẫn mở | ba mutant phần đầu giết 2/1/1 ca; mutant reviewer bỏ khối ngắn bị giết 1; bản sao dính chữ còn lọt |
| Q4: trạng thái ADR dẫn r9 | đúng quyết định | N1 byte-exact; ngày 2026-11-26, URL kết thúc `issuecomment-7192181084` |

Các lớp đã chuyển theo E2/E5 sang #1469, #1470, #1484 giữ nguyên trạng thái lịch sử, không tính là được vá bởi H này. Review mã lượt 1 không có tỷ lệ hội tụ giữa hai lượt mã để báo; không lấy số đóng của review đặc tả làm tử số cho mã.

## BẢNG SĂN

Lệnh chạy từ thư mục giao việc, trừ khi ghi `out/h`. `run_logged.py` lưu nguyên argv, cwd, output, rc và thời gian tại `logs/<nhãn>.log`. Các script kiểm độc lập và JSON phản chứng nằm cạnh verdict. Với hướng đường dẫn/chuỗi độc hại chỉ dùng fixture có sẵn; không tự dựng payload. Bảng có hơn tám giả thuyết độc lập; dòng phần đầu là kiểm bổ sung cùng F01, không tính như lớp mới.

| hướng/giả thuyết | lệnh đã chạy | OUTPUT THẬT/kết quả |
|---|---|---|
| Địa chỉ có phụ thuộc tiêu đề cha, và có bắt oan tiêu đề con ngoài vùng khoá? | `python3 -B out/probes.py` | `ancestor/rename-root-heading: rc=9`; `ancestor/insert-child-before-K03: rc=0`, 2/2 đúng |
| Hai mục có cùng đường tiêu đề có bị lọt? | `python3 -B out/extra_probes.py` | `same-path-duplicate-K01 rc 9 expected 9`; K03 cùng kết quả |
| Byte có bị chuẩn hoá ngầm ở cuối đơn vị? | `python3 -B out/probes.py` | `raw-byte`: total35, matched35; 7 khoá × CR/TAB/NBSP/U+2028/BOM, tất cả rc9; BOM đầu tệp rc9 |
| Ranh giới dòng rỗng có bị đếm nhầm thành khối? | cùng lệnh | `blank-boundary`: 5/5, rc0; `eof/remove-final-newline: rc=0` |
| Vùng che có bị đếm như bản hiển thị? | `python3 -B out/extra_probes.py` | 14/14 bản sao trong fence/comment của 7 khoá rc0; tổng `EXTRA 25 / 25` |
| Chốt HTML có thực sự được gọi? | `python3 -B out/run_cases.py out/h out/base out/cases db-moi` | `inv_bo_chan_html → giết 1 ca đích · 3 đối chứng khác họ còn sống`; nền63/63; dùng ca HTML có sẵn |
| Gốc resolve và liên kết trong/ngoài có phân biệt? | cùng lệnh | `inv_bo_kiem_duoi_goc → giết 1 ca đích · 3 đối chứng khác họ còn sống`; ca liên kết nội bộ xanh, không skip |
| Hậu tố/chuẩn hoá ID có làm lọt hay bắt oan tên nợ? | `python3 -B out/probes.py`; `python3 -B out/extra_probes.py` | `id-boundary`8/8, fullwidth rc9; `ID-debt-outside rc 0`; `prose-id-no-pipe rc 0`; ID00/01/09/10/28/98/99 đều rc9 |
| Bộ test có phân biệt miền ID với một giá trị cố định? | `python3 -B out/reviewer_mutants.py all-stock`; `… extended` | `ALL-STOCK 63 / 63 SKIP 0` dưới mutant chỉ99; bổ sung nền69/69, mutant bị giết6, đối chứng3 sống ⇒ F02 |
| Bản sao có thêm chữ ngoài đơn vị có còn bị đếm? | `python3 -B out/probes.py` | `copies`: total33, matched15, green18; `preamble`: total10, matched5, green5 ⇒ F01 |
| Bản vá phần đầu có ca đủ nhạy với độ dài khối? | `python3 -B out/reviewer_mutants.py extended` | `rv_preamble_drop_short_blocks → giết 1 ca đích · 3 đối chứng khác họ còn sống`; `TỔNG: ĐẠT` |
| Nguồn hỏng có biến thành im lặng xanh? | `python3 -B out/probes.py` | `input-error/invalid-utf8: rc=2`; `input-error/empty: rc=2`, đều có lỗi, không xanh. Cổng nguồn cũ chạy trước cổng mới; đây không đo nhánh đọc lỗi ở lần đọc thứ hai |
| Chữ mới có phá bộ dò claim hoặc sinh lỗi lint? | doc-claims H/base và `python3 -B out/lint_delta.py` | cả hai `ok:true`, `flags:[]`, advisory392; Ruff thêm0/mất0 |

JSON `probes.json` lưu stdout/stderr thật của từng CLI. Script cố ý trả rc0 sau khi thu phản chứng; **không dùng rc của script ấy để gọi hành vi đạt**. 99 đầu vào trong `probes.py`: 76 đúng kỳ vọng, 23 phản chứng cho F01. `extra_probes.py`: 25/25 đúng. Dạng HTML giữa dòng trong Q3 chỉ được mô tả, chưa dựng thêm; không tính là phản chứng thực nghiệm thứ năm.

## BẢNG ĐO

| khẳng định (đặc tả/handoff) | khai | đo được | khớp? |
|---|---|---|---|
| Exact H, kiểm đầu tiên | da4e876890a1ebe99bb87de9e9a3b4f63c9fd5dd | HEAD đúng; tree `84018dbd9db5edcb1397e63d81911fc0320247aa` | có |
| Đặc tả đóng băng, kiểm trước review | sha256 28de9d57…ea6f7c | đúng toàn bộ băm ở metadata; blob `823e62c4f50c45425b38d2c71c04852e1dfc1543` | có |
| Lease/nguồn/pạm vi | r9 g2, base695916e, nhánh claude/wp1466-r9-g2 | `AUTHORITY 13 / 13`; snapshot lease c9a7a98…9706, hết hạn 2026-11-29T17:05Z; hash write set/spec khớp | có, trong snapshot |
| N1 ADR | khối adr, thay đúng giá trị | `N1 byte_exact=True`, 14.385 byte; sha256 `2da0db8a25bbbef3eba520353e07f4ad808f0bba0db3864d724b6b4a4fb945cc` | có |
| Sáu số Cưỡng chế | 0,11,0,0,0,0 | tự chạy đúng sáu lệnh; cùng số. `grep -c` rc1 ở kết quả0 là quy ước grep, không phải phép đo vắng | có |
| N2 protocol | base + đúng p1–p6 | `N2 byte_exact=True`; sha256 `3453ab9b6d7d7d803c4f852a03e1179e65884230f1723a5ef1ca62a95d80e29a` | có |
| N3 adr-song | H67/67; base66/66 | đúng, output sạch; 40/40 ca adr_song đạt, không skip | có |
| N4 doctrine-scan | sạch trên H và cổng chặn vi phạm | cây gốc và clone H đều quét12 tệp sạch; ca bắt buộc đạt, nhưng F01 có23 phản chứng | một phần |
| N5 băm độc lập | 7 khoá = khoa = hằng mã | `N5 7/7 tự băm = khoa = INV_KHOA_PROTOCOL`; parser riêng không import mã/hàm che sản phẩm | có |
| N6(a–d,f), đăng ký | 57 bắt buộc, T60; tổng1864/Linux1863 | 57/57; T60; 1804→1864, Linux1803→1863; nền63/63 không skip | có |
| N6(e) toàn bộ nền | 16 mảnh + hai CA_DAI | **ĐANG CẬP NHẬT:** xem phần gate dài dưới đây | chưa cấp đạt |
| N7 đột biến mới | 26 bắt buộc, thực29 | 26/26 có mặt; nền63/63; 29/29 chết đúng lý do, mỗi mutant3 đối chứng sống, TỔNG ĐẠT | có |
| N8 phạm vi mã/test | hai chế độ đạt | `PHẠM VI [ma]: ĐẠT`; `PHẠM VI [test]: ĐẠT`, khối trích nguyên từ spec | có |
| N9 hành vi cũ | doctrine132, ADR40, kiểm mốc, mutant21 | nền132/132 +21/21; ADR40/40; ca mốc đã đạt trong nền63/63 của N7 | có |
| N10 Ruff F delta | base3+13, H3+13 | cùng16 lỗi; thêm0/mất0 theo bộ mã/thông điệp bỏ số dòng/dòng nguồn; tl.py cùng12 lỗi có sẵn | có; không phải lint sạch |
| Ký tự lạ trong .py | không thêm | packet_loop0→0; test12→12, giữ số thật của base hiện tại | có |
| N11 selftest/diff-check | handoff khai1789/1789 | H1773/1789; base1773/1789, cùng16 tên lỗi; diff-check sạch | không tái lập N/N |
| N12 kích thước | 4 tệp,+443−4,3 commit | 78/−1;170/−1;46/−2;149/−0; tất cả mode100644; 443≤450,4≤6 | có |
| doc-claims strict | r9 hết3 cờ L12 | H/base đều `ok:true`, `flags:[]`, `claims_flagged:392`, advisory392 | có |
| N13 CI PR | sáu nhãn job success trên exact H | chỉ chạy được các bước cục bộ; H chưa push | KHÔNG ĐO ĐƯỢC |
| N14 full mutant audit | ci-dot-bien-du.yml success đúng H | không có run CI; chỉ29 mới+21 cũ và2 mutant reviewer tại chỗ | KHÔNG ĐO ĐƯỢC |
| N15 kiem-merge/master | đủ điều kiện trên H | chưa có PR/CI/assurance; không chạy hành động ghi | KHÔNG ĐO ĐƯỢC |
| N16 sau land | push master và đột biến đêm xanh | chưa land | CHƯA ĐẾN GIAI ĐOẠN |

Lệnh N1/N2/N5: `python3 -B out/independent.py`. Tệp `units.json` có đường tiêu đề, vị trí và băm; các khoảng dòng H lần lượt K01 49–82, K02 31–47, K03 851–894, K04 747–751, K05 1170–1176, K06 1178–1183, K07 1185–1188. N8: `python3 -B out/do-pham-vi.py ma out/base-packet_loop.py out/h-packet_loop.py` và chế độ `test` trên hai blob test. Sổ: `python3 -B out/so-dang-ky.py out/base out/h`. Các argv còn lại đầy đủ ở dòng đầu mỗi log.

Bộ chạy `run_cases.py` sao từ script executor sau khi đọc; dùng API thật `packet_loop_test_manh.chay`, không lấy kết quả executor làm bằng chứng. Phép băm, dò độc lập, mutant reviewer, so lint và kiểm authority do reviewer tự viết. Không tuyên bố mọi script là triển khai độc lập.

## Các gate cục bộ bổ sung và giới hạn môi trường

**ĐANG CẬP NHẬT GATE DÀI.**

Đã đạt: idiom nền7/7 và vòng mutant `TỔNG: ĐẠT`; gen_instructions44/44; command_registry10 tests/OK; ci_phamvi7/7 và kiểm băm đạt. `workflow-audit --strict`, `golden-test`, `determinism-audit --strict`, `release-check --full`, `release-verify RELEASE_MANIFEST.json --strict` đều có `ok:true`. EOL kiểm18.092 tệp, `ok:true`, `violations:[]`. Đây là bằng chứng bước cục bộ, không thay job GitHub.

Selftest H/base cùng16 lỗi: 8 ca r973_bootstrap, r226, r268, 5 ca wp433, wp727_tl_gws_refresh; tên đầy đủ và output ở `logs/selftest.log`, `logs/selftest-base.log`, `summary.json`. Không có lỗi mới trong phép so tập. Môi trường có `.git` bảo vệ trên đường tổ tiên của thư mục tạm, ảnh hưởng các phép kiểm home/credential; một số fixture Git còn vướng dịch vụ ký commit bị sandbox chặn. Chỉ khẳng định nguyên nhân khi output cho thấy; không suy mọi lỗi đều cùng nguyên nhân.

`codex_cred_test` H/base đều13/18, cùng5 ca đỏ; không tính hồi quy của H. `pre_push_test` mặc định cả hai sập khi ký commit. Chạy lại cả H/base với cấu hình Git chỉ áp dụng cho tiến trình (`GIT_CONFIG_GLOBAL=/dev/null GIT_CONFIG_SYSTEM=/dev/null GIT_CONFIG_COUNT=0`) cho9/9 mỗi phía. Không sửa cấu hình Git chung. Những điều chỉnh này không biến selftest hoặc CI đầy đủ thành đạt.

Môi trường Linux, Python3.13.18, Git2.43, Ruff0.15.15; không đồng nhất ảnh CI Python3.12. Không chạy Windows, theo miễn C3/E2 đã được cung cấp. Không xác minh tình trạng GitHub hiện thời hoặc lease mới ngoài ảnh ref ngày26-11; không thể suy từ snapshot rằng không có lease phát sinh sau đó. Không chạy hai ca dài CA_DAI, không chạy toàn bộ2106 mutant, không có biên nhận GitHub N13–N16. Chưa tái lập được một bộ nền đầy đủ xanh nên không cấp assurance.

## Thẩm quyền, phạm vi và dấu vết git plumbing

Đã đọc nguyên văn chỉ thị cross-review của kho, các mục protocol được yêu cầu, M1–M12/ADR0060, ADR0062, ADR0063 và CLAUDE.md; áp dụng đặc tả r9, quyết định đã cung cấp, lease trong snapshot. Kho clone độc lập đầy đủ, ghim core.abbrev7. Tất cả script, fixture và log viết trong `out/`; source `cay-kho` chỉ đọc.

HANDOFF lượt1 thừa nhận đã dùng git plumbing sau khi chốt ghi tệp từ chối; lượt2/3 dùng git apply. Trên exact H, kiểm tree/diff cho đúng4 đường dẫn write set, mode100644, không tệp thứ năm, không lệch nội dung ADR/protocol hay phần AST cũ. Không thấy dấu vết nội dung nằm ngoài phạm vi do cách ghi ấy để lại. Điều này **không chứng minh thao tác lịch sử đã được cho phép**, cũng không xoá sự kiện đi vòng chốt; giữ sự kiện cho audit human_audited của chủ kho. Commit đầu còn nhãn r8 g1 trong subject, hai commit sau đưa nội dung về r9 g2; không dùng subject thay lease/spec của H.

So băm toàn bộ cây gốc trước/sau:19.076 tệp,0 đường thay đổi; HEAD/tree/status không đổi (`snapshot-delta.json`). Đầu ra kiểm và clone dùng thử nằm ngoài kho gốc. Không có patch giao nộp, không hành động land/merge trong lượt reviewer này.

'''
p.write_text(header+findings)
print('wrote',p,'bytes',p.stat().st_size)
