import json, os, pathlib, subprocess,sys
OUT=pathlib.Path(__file__).resolve().parent
R=OUT.parent/'cay-kho'
g=(R/'docs/PROTOCOL_DA_PHIEN.md').read_bytes()
units=json.loads((OUT/'units.json').read_text())
p=OUT/'extra-probe-root'/'docs'/'PROTOCOL_DA_PHIEN.md';p.parent.mkdir(parents=True,exist_ok=True)
results=[]
def check(name,data,rc):
    p.write_bytes(data)
    r=subprocess.run([sys.executable,'-B',str(R/'.claude/dev/packet_loop.py'),'doctrine-scan','--root',str(p.parent.parent)],capture_output=True,text=True)
    results.append(dict(name=name,expected=rc,rc=r.returncode,stdout=r.stdout,stderr=r.stderr))
    print(name,'rc',r.returncode,'expected',rc,flush=True)
for name,u in units.items():
    text=u['text'].encode()
    check('hidden-fence-'+name,g+b'\n\n```\n\n'+text+b'\n\n```\n',0)
    check('hidden-comment-'+name,g+b'\n\n<!--\n\n'+text+b'\n\n-->\n',0)
for name in ['K01','K03']:
    text=units[name]['text'].encode()
    check('same-path-duplicate-'+name,g.replace(text,text+b'\n\n'+text,1),9)
for n in [0,1,9,10,28,98,99]:
    check('real-id-'+str(n),g+f'\n\n## Kiểm ID\n\n| INV-{n:02d} | ghi chú |\n'.encode(),9)
check('ID-debt-outside',g+b'\n\n## ID debt\n\n| INV-01-NO | ghi chu |\n',0)
check('prose-id-no-pipe',g+b'\n\n## ID prose\n\nINV-01\n',0)
(OUT/'extra-probes.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('EXTRA',sum(r['rc']==r['expected'] for r in results),'/',len(results))
assert all(r['rc']==r['expected'] for r in results)
