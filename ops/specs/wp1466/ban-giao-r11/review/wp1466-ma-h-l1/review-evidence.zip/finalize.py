import hashlib,json,os,pathlib,subprocess,zipfile
from prepare import snapshot
out=pathlib.Path(__file__).resolve().parent
os.environ['GIT_OPTIONAL_LOCKS']='0'
before=json.loads((out/'snapshot-before.json').read_text())
after=snapshot()
(out/'snapshot-after.json').write_text(json.dumps(after,ensure_ascii=False))
changed=sorted(k for k in set(before['files'])|set(after['files']) if before['files'].get(k)!=after['files'].get(k))
delta={'head_unchanged':before['head']==after['head'],'tree_unchanged':before['tree']==after['tree'],'status_unchanged':before['status']==after['status'],'files_before':len(before['files']),'files_after':len(after['files']),'changed_paths':changed}
(out/'snapshot-delta.json').write_text(json.dumps(delta,ensure_ascii=False,indent=2))
assert not changed and all(delta[k] for k in ['head_unchanged','tree_unchanged','status_unchanged'])
for name in ['h','base','selftest-h','full-h']:
    assert not subprocess.check_output(['git','-C',str(out/name),'diff','HEAD','--name-status'])
v=(out/'VERDICT.md').read_text()
assert v.startswith('verdict: blocked\n')
assert all(s in v for s in ['## BẢNG LỚP — lớp MỞ','## BẢNG LỚP ĐÃ ĐÓNG/ĐÃ KIỂM','## BẢNG SĂN','## BẢNG ĐO'])
assert not any(s in v for s in ['ĐANG CẬP NHẬT','Đang đo','Trạng thái tạm'])
assert v.count('### phep-dem-ban-sao-khong-phu-ca-tep')==1 and v.count('### ca-id-chi-do-mot-gia-tri')==1
paths=sorted([p for p in out.iterdir() if p.is_file() and p.suffix in ('.py','.json','.md')] + list((out/'logs').glob('*.log'))+list((out/'shards').glob('*.json')))
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(out))+'\n' for p in paths)
(out/'SHA256SUMS').write_text(manifest)
with zipfile.ZipFile(out/'review-evidence.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in paths+[out/'SHA256SUMS']:z.write(p,str(p.relative_to(out)))
with zipfile.ZipFile(out/'review-evidence.zip') as z:assert z.testzip() is None
print('SOURCE_UNCHANGED',json.dumps(delta,ensure_ascii=False))
print('EVIDENCE_FILES',len(paths),'ZIP_BYTES',(out/'review-evidence.zip').stat().st_size)
print('VERDICT_SHA256',hashlib.sha256((out/'VERDICT.md').read_bytes()).hexdigest())
