import concurrent.futures, json, os, pathlib, subprocess, sys, time
OUT=pathlib.Path(__file__).resolve().parent
ROOT=OUT.parent
c=OUT/'full-h'
subprocess.run(['git','clone','--quiet','--no-hardlinks','--no-checkout',str(ROOT/'kho.git'),str(c)],check=True)
for k,v in [('core.abbrev','7'),('core.autocrlf','false'),('core.eol','lf')]:
    subprocess.run(['git','-C',str(c),'config',k,v],check=True)
subprocess.run(['git','-C',str(c),'checkout','--quiet','--detach','da4e876'],check=True)
subprocess.run(['git','-C',str(c),'remote','set-url','origin','https://github.com/ducthangho/tra-luat.git'],check=True)
(OUT/'shards').mkdir(exist_ok=True)
def one(i):
    command=[sys.executable,'-B',str(OUT/'run_logged.py'),'shard-'+str(i),str(c),sys.executable,'-u','-B','.claude/dev/packet_loop_test_manh.py','--manh',str(i)+'/16','--ra',str(OUT/'shards'/('manh-'+str(i)+'.json'))]
    r=subprocess.run(command)
    return (i,r.returncode)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(one,range(16)))
(OUT/'shards-results.json').write_text(json.dumps(results))
env=dict(os.environ,PACKET_LOOP='day_du',KQ_MANH='success' if all(rc==0 for _,rc in results) else 'failure')
r=subprocess.run([sys.executable,'-B',str(OUT/'run_logged.py'),'shards-aggregate',str(c),sys.executable,'-u','-B','.claude/dev/packet_loop_test_manh.py','--gom',str(OUT/'shards'),'--n','16'],env=env)
sys.exit(r.returncode)
