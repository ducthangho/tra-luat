"""Thước của reviewer: không import parser/hash của sản phẩm hay executor."""
import ast, hashlib, json, pathlib, re, subprocess
ROOT=pathlib.Path(__file__).resolve().parent.parent
OUT=ROOT/'out'
REPO=ROOT/'cay-kho'
SPEC=(REPO/'ops/specs/wp1466.md').read_bytes()
def block(name):
    return SPEC.split(('~~~ '+name+'\n').encode())[1].split(b'\n~~~')[0]
def gitblob(rev,path):
    return subprocess.check_output(['git','-C',str(REPO),'show',rev+':'+path])
def digest(b): return hashlib.sha256(b).hexdigest()
def units(data):
    # Bản canonical: che comment và fenced code bằng parser riêng trước khi lấy tiêu đề.
    lines=data.split(b'\n')
    visible=re.sub(rb'<!--.*?-->',lambda m:re.sub(rb'[^\n]',b' ',m[0]),data,flags=re.S).split(b'\n')
    headers=[]; fence=None
    for i,line in enumerate(visible):
        match=re.match(rb' {0,3}(`{3,}|~{3,})',line)
        if fence:
            if re.fullmatch(rb' {0,3}'+re.escape(fence[:1])+rb'{'+str(len(fence)).encode()+rb',}[ \t]*',line): fence=None
            continue
        if match:
            fence=match[1]; continue
        if line.startswith(b'#'): headers.append(i)
    answer=[]; stack=[]
    for j,start in enumerate(headers):
        stop=headers[j+1] if j+1<len(headers) else len(lines)
        level=len(lines[start])-len(lines[start].lstrip(b'#'))
        while stack and stack[-1][0]>=level: stack.pop()
        stack.append((level,lines[start]))
        end=stop
        while end>start and lines[end-1]==b'':end-=1
        chunks=[]; k=start+1
        while k<stop:
            if lines[k]==b'': k+=1; continue
            a=k
            while k<stop and lines[k]!=b'':k+=1
            chunks.append((a,k))
        answer.append({'heading':lines[start].decode(),'path_hash':digest(b'\n'.join(v for _,v in stack)), 'ranges':[(start,end)]+chunks})
    return lines,answer
def measure():
    proto=gitblob('HEAD','docs/PROTOCOL_DA_PHIEN.md')
    base=gitblob('695916e','docs/PROTOCOL_DA_PHIEN.md')
    # N2: dựng đúng sáu thao tác đã duyệt, không dùng diff làm bản kỳ vọng.
    expected=base
    anchor='    workflow trigger và prompt chỉ là worker/client có thể thay thế, không tự cấp quyền hoặc tự nối chuỗi vai trò.\n'.encode()
    assert expected.count(anchor)==1
    expected=expected.replace(anchor,anchor+block('p1-moi')+b'\n')
    anchor='## 2. Thành phần và quyền'.encode()
    expected=expected.replace(anchor,block('p2-moi')+b'\n\n'+anchor)
    anchor='### 8.3 Lịch sử lớp finding và giới hạn nghiệm thu\n\n'.encode()
    expected=expected.replace(anchor,anchor+block('p3-moi')+b'\n\n')
    for n in [4,5]:
        assert expected.count(block(f'p{n}-cu'))==1
        expected=expected.replace(block(f'p{n}-cu'),block(f'p{n}-moi'))
    anchor=next(l for l in expected.splitlines() if l.startswith(b'| `ADR-0067` | '))
    expected=expected.replace(anchor,anchor+b'\n'+block('p6-moi'))
    print('N2 byte_exact=',expected==proto,'sha256=',digest(proto))
    assert expected==proto
    paths=['ops/lease_publish.py','.claude/dev/packet_loop.py','.claude/dev/launcher.py','.claude/dev/gate_lifecycle.py','.github/workflows/ci.yml','.github/workflows/ops-publish-lease.yml']
    nums=[]
    for path in paths:
        r=subprocess.run(['grep','-cE','ADR-0068|INV_|_inv_'],input=gitblob('HEAD',path),capture_output=True)
        n=int(r.stdout);nums.append(n)
        print('CUONG_CHE',path,n,'grep_rc',r.returncode)
    adr=block('adr')+b'\n'
    status='- **Trạng thái:** Accepted (2026-11-26, chủ kho `ducthangho` duyệt `spec_hash` `'+digest(SPEC)+'` của đặc tả `wp1466` r9 trên Issue #1466: https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7192181084)'
    adr=adr.replace(b'{{TRANG_THAI}}',status.encode())
    for i,n in enumerate(nums,1):adr=adr.replace(('{{N'+str(i)+'}}').encode(),str(n).encode())
    actual=gitblob('HEAD','docs/adr/0068-bat-bien-protocol-va-review-theo-lop.md')
    print('N1 byte_exact=',adr==actual,'bytes=',len(actual),'sha256=',digest(actual))
    assert adr==actual
    declared=[]
    for line in block('khoa').decode().splitlines():
        label,ph,n,bh,title=map(str.strip,line.split('|'))
        declared.append((label,ph,int(n),bh,title))
    tree=ast.parse(gitblob('HEAD','.claude/dev/packet_loop.py'))
    const=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='INV_KHOA_PROTOCOL' for t in n.targets))
    lines,sections=units(proto); found=[]; saved={}
    for label,ph,idx,bh,title in declared:
        section=[s for s in sections if s['heading']==title]
        assert len(section)==1
        sec=section[0];a,b=sec['ranges'][idx]
        data=b'\n'.join(lines[a:b]);row=(label,sec['path_hash'],idx,digest(data))
        saved[label]={'start':a,'stop':b,'text':data.decode(),'index':idx}
        found.append(row)
        print('N5',label,'lines',a+1,b,'path',row[1],'hash',row[3],'match',row==tuple((label,ph,idx,bh)))
    assert tuple(found)==const==tuple(row[:4] for row in declared)
    (OUT/'units.json').write_text(json.dumps(saved,ensure_ascii=False))
    print('N5 7/7 tự băm = khoa = INV_KHOA_PROTOCOL')
if __name__=='__main__':measure()
