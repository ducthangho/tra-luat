import collections,json,pathlib,re,subprocess,sys,unicodedata
OUT=pathlib.Path(__file__).resolve().parent
paths=['.claude/dev/packet_loop.py','.claude/dev/packet_loop_test.py','scripts/tl.py']
allrows={}
for name in ['base','h']:
    rows=[]
    for path in paths:
        p=OUT/name/path
        cmd=[sys.executable,'-m','ruff','check','--select','F','--no-cache','--isolated','--output-format','json',str(p)]
        r=subprocess.run(cmd,capture_output=True,text=True)
        findings=json.loads(r.stdout)
        (OUT/'logs'/('ruff-'+name+'-'+p.name+'.json')).write_text(r.stdout)
        lines=p.read_text().splitlines()
        counts=collections.Counter()
        for d in findings:
            msg=re.sub(r'from line \d+','from line N',d['message'])
            row=(path,d['code'],msg,lines[d['location']['row']-1].strip())
            rows.append(row);counts[d['code']]+=1
        strange=[c for c in p.read_text() if (unicodedata.category(c) in ['Cc','Cf','Zl','Zp'] and c!='\n') or (unicodedata.category(c)=='Zs' and c!=' ')]
        print(name,path,'rc',r.returncode,'F',len(findings),dict(counts),'strange',len(strange))
    allrows[name]=collections.Counter(rows)
added=allrows['h']-allrows['base'];gone=allrows['base']-allrows['h']
print('DELTA added',sum(added.values()),'removed',sum(gone.values()))
for k,v in added.items():print('NEW',k,v)
assert not added and not gone
