import hashlib, json, os, pathlib, subprocess
ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / 'out'
def run(*args):
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()
def snapshot():
    files = {}
    for p in (ROOT/'cay-kho').rglob('*'):
        if p.is_file():
            files[str(p.relative_to(ROOT/'cay-kho'))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return {'head':run('git','-C','cay-kho','rev-parse','HEAD'), 'tree':run('git','-C','cay-kho','rev-parse','HEAD^{tree}'), 'files':files, 'status':run('git','-C','cay-kho','status','--porcelain=v1','--untracked-files=all','--ignored=matching')}
if __name__ == '__main__':
    (OUT/'snapshot-before.json').write_text(json.dumps(snapshot(),ensure_ascii=False))
    for name,rev in [('h','da4e876'),('base','695916e'),('selftest-h','da4e876')]:
        dest=OUT/name
        subprocess.run(['git','clone','--quiet','--no-hardlinks','--no-checkout',str(ROOT/'kho.git'),str(dest)],check=True)
        for k,v in [('core.abbrev','7'),('core.autocrlf','false'),('core.eol','lf')]:
            subprocess.run(['git','-C',str(dest),'config',k,v],check=True)
        subprocess.run(['git','-C',str(dest),'checkout','--quiet','--detach',rev],check=True)
        subprocess.run(['git','-C',str(dest),'remote','set-url','origin','https://github.com/ducthangho/tra-luat.git'],check=True)
        print(name,run('git','-C',str(dest),'rev-parse','HEAD'),flush=True)
    spec=(ROOT/'cay-kho/ops/specs/wp1466.md').read_bytes()
    for name in ['do-pham-vi','so-dang-ky']:
        block=spec.split(('~~~ '+name+'\n').encode())[1].split(b'\n~~~')[0]+b'\n'
        (OUT/(name+'.py')).write_bytes(block)
    for name,rev in [('base','695916e'),('h','da4e876')]:
        for f in ['packet_loop.py','packet_loop_test.py']:
            (OUT/(name+'-'+f)).write_bytes(subprocess.check_output(['git','-C',str(ROOT/'cay-kho'),'show',rev+':.claude/dev/'+f]))
