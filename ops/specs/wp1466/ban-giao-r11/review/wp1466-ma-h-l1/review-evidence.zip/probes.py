"""Phản chứng dữ liệu văn bản vô hại; dùng CLI thật trên cây thử dưới out/."""
import json, os, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parent.parent
OUT=ROOT/'out'
H=ROOT/'cay-kho'
G=(H/'docs/PROTOCOL_DA_PHIEN.md').read_bytes()
U=json.loads((OUT/'units.json').read_text())
TARGET=OUT/'probe-root'
(TARGET/'docs').mkdir(parents=True,exist_ok=True)
records=[]
def test(family,name,data,expected):
    assert data!=G or name=='canonical'
    (TARGET/'docs/PROTOCOL_DA_PHIEN.md').write_bytes(data)
    r=subprocess.run([sys.executable,'-B',str(H/'.claude/dev/packet_loop.py'),'doctrine-scan','--root',str(TARGET)],capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
    record=dict(family=family,name=name,expected=expected,rc=r.returncode,output=r.stdout+r.stderr,match=r.returncode==expected)
    records.append(record)
    print(f'{family}/{name}: rc={r.returncode}, expected={expected}, match={record["match"]}',flush=True)
    (OUT/'probes.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
test('control','canonical',G,0)
pad='Dòng ghi chú kiểm thử của reviewer.'.encode()
for name,u in U.items():
    raw=u['text'].encode()
    # Bản thứ hai giữ nguyên byte, đặt dưới tiêu đề khác; toàn bộ 7 đơn vị, không chọn riêng K04.
    for variant,copy in [('isolated',raw+b'\n\n'),('attached_after',raw+b'\n'+pad+b'\n'),('space_line_after',raw+b'\n \n'+pad+b'\n'),('blank_paragraph_after',raw+b'\n\n'+pad+b'\n')]:
        test('copies',name+'-'+variant,G+'\n\n## Phụ lục kiểm thử\n\n'.encode()+copy,9)
    if u['index']:
        test('copies',name+'-attached_before',G+'\n\n## Phụ lục kiểm thử\n\n'.encode()+pad+b'\n'+raw+b'\n',9)
        test('preamble',name+'-isolated',raw+b'\n\n'+G,9)
        test('preamble',name+'-attached',pad+b'\n'+raw+b'\n\n'+G,9)
    for label,b in [('CR',b'\r'),('TAB',b'\t'),('NBSP','\u00a0'.encode()),('U2028','\u2028'.encode()),('BOM','\ufeff'.encode())]:
        test('raw-byte',name+'-'+label,G.replace(raw,raw+b,1),9)
    if u['index']:
        test('blank-boundary',name,G.replace(raw+b'\n\n',raw+b'\n\n\n\n',1),0)
test('BOM','file-leading',b'\xef\xbb\xbf'+G,9)
test('ancestor','rename-root-heading',G.replace(b'# Protocol',b'# Protocol reviewer',1),9)
test('ancestor','insert-child-before-K03',G.replace(U['K03']['text'].encode(),b'### Phan phu\n\n'+U['K03']['text'].encode(),1),0)
for suffix,expect in [('',9),('A',0),('0',0),('-NO',0),('_',9),('.',9),('\u200b',9),('\u00ad',9)]:
    row=('\n\n## Kiểm ID\n\n| INV-99'+suffix+' | ghi chú |\n').encode()
    test('id-boundary',repr(suffix),G+row,expect)
test('id-normalize','fullwidth',G+'\n\n## Kiểm ID\n\nＩＮＶ－９９ ｜ ghi chú\n'.encode(),9)
test('input-error','invalid-utf8',G+b'\xff',2)
test('input-error','empty',b'',2)
# Tái sử dụng nguyên fixture HTML đã có trong test; không soạn chuỗi tấn công HTML mới.
test('eof','remove-final-newline',G.rstrip(b'\n'),0)
summary={}
for r in records:
    s=summary.setdefault(r['family'],dict(total=0,matched=0,green=0))
    s['total']+=1;s['matched']+=r['match'];s['green']+=r['rc']==0
print('SUMMARY',json.dumps(summary,ensure_ascii=False))
