import json, os, pathlib, sys
OUT=pathlib.Path(__file__).resolve().parent
ROOT=OUT/'h'
sys.path.insert(0,str(ROOT/'.claude/dev'))
os.chdir(ROOT)
import packet_loop_test as t
import packet_loop_test_manh as m
mode=sys.argv[1]
names={n for n,_ in t.CASES if n.startswith('doctrine_inv_')}|{'doctrine_scan_repo_that_sach','doctrine_scan_sach_xanh','moc_dot_bien_phai_khop_DUNG_MOT_CHO'}
custom={
 'rv_id_only_99': ('_INV_ID_TRAN = r"INV-[0-9]{2}(?![0-9A-Za-z-])"','_INV_ID_TRAN = r"INV-99(?![0-9A-Za-z-])"', [n for n in names if n.startswith('doctrine_inv_dong_inv_ngoai')]),
 'rv_preamble_drop_short_blocks': ('zip([-1] + truoc, truoc) if t - s > 1]', 'zip([-1] + truoc, truoc) if t - s > 6]', ['doctrine_inv_nhan_doi_K04_truoc_tieu_de_dau']),
}
if mode=='all-stock':
    d=OUT/'reviewer-id-mutant'
    d.mkdir(exist_ok=True)
    text=t.CANONICAL.read_text()
    old,new,_=custom['rv_id_only_99']
    assert text.count(old)==1
    (d/'packet_loop.py').write_text(text.replace(old,new,1))
    (d/'launcher.py').write_bytes((ROOT/'.claude/dev/launcher.py').read_bytes())
    kq=t.chay_suite(d/'packet_loop.py',d/'cases',names)
    print('ALL-STOCK',sum(v is None for v in kq.values()),'/',len(names),'SKIP',sum(isinstance(v,t.BoQua) for v in kq.values()))
    for n,v in kq.items():
        if v is not None:print(n,str(v))
    sys.exit(int(not(len(kq)==len(names) and all(v is None for v in kq.values()))))
if mode=='extended':
    extra=[]
    custom['rv_id_only_99'][2].clear()
    for n in [0,1,9,10,28,98]:
        name=f'doctrine_inv_reviewer_id_{n:02d}'
        row=f'| INV-{n:02d} | ghi chú |'
        extra.append((name,t._inv_ca(t._inv_o2(row),9,'nằm ngoài tiểu mục')))
        custom['rv_id_only_99'][2].append(name)
    t.CASES+=extra
    names|={n for n,_ in extra}
t.MUTANTS.update(custom)
print('REVIEWER MUTANTS',mode,'baseline',len(names),flush=True)
result=m.chay(t,names,lambda all_names:set(custom)&set(all_names))
print('RESULT',json.dumps(result,ensure_ascii=False),flush=True)
sys.exit(result[0])
