"""Bộ chạy của executor wp1466 (theo cách của ops/specs/wp1466/nguyen-mau-r5/sc/chay5.py, thêm phép so với sổ NỀN).

dùng: python3 -B chay_ca.py <cây H> <cây nền> <tmp> so|ca-moi|ca-cu|adr|db-moi|db-cu
  so      in T (ca có ở H, không có ở nền), đột biến mới, họ doctrine cũ — không chạy ca nào
  ca-moi  N6(d): T + `moc_dot_bien_phai_khop_DUNG_MOT_CHO` + hai ca G9 sẵn có, bằng `chay_suite` thật, từng ca một
  ca-cu   N9: họ ca doctrine cũ (S8) + `moc_…`, bằng `chay_suite` thật
  adr     N9: mọi ca `adr_song_*`
  db-moi  N7: `packet_loop_test_manh.chay`, lượt nền = T + hai ca G9 + `moc_…`, pha đột biến = MỌI đột biến có ở H mà không có ở nền
  db-cu   N9: `packet_loop_test_manh.chay`, lượt nền = họ doctrine cũ, pha đột biến = mọi đột biến của NỀN có ca đích trong họ ấy
"""
import inspect, json, os, pathlib, subprocess, sys, tempfile, time

cay, nen, tmp, che_do = pathlib.Path(sys.argv[1]).resolve(), pathlib.Path(sys.argv[2]).resolve(), pathlib.Path(sys.argv[3]).resolve(), sys.argv[4]
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
tmp = tmp / che_do
tmp.mkdir(parents=True, exist_ok=True)
os.environ["TMPDIR"] = os.environ["TEMP"] = os.environ["TMP"] = str(tmp)
tempfile.tempdir = str(tmp)
NAP = ("import json, os, sys; sys.dont_write_bytecode = True; sys.path.insert(0, os.path.join(sys.argv[1], '.claude', 'dev')); os.chdir(sys.argv[1]);"
       "import packet_loop_test as t;"
       "print(json.dumps(dict(cases=[n for n, _ in t.CASES], mutants={k: [v[0], v[1], list(v[2])] for k, v in t.MUTANTS.items()})))")
r = subprocess.run([sys.executable, "-B", "-W", "ignore", "-c", NAP, str(nen)], capture_output=True, text=True)
if r.returncode:
    sys.exit(f"KHÔNG ĐO ĐƯỢC: nạp sổ nền rc={r.returncode}: {r.stderr.strip()[-400:]}")
so_nen = json.loads(r.stdout.strip().splitlines()[-1])
sys.path.insert(0, str(cay / ".claude" / "dev"))
os.chdir(cay)
import packet_loop_test as t, packet_loop_test_manh as sh  # noqa: E402

ten_h = [n for n, _ in t.CASES]
T = [n for n in ten_h if n not in set(so_nen["cases"])]
db_moi = sorted(set(t.MUTANTS) - set(so_nen["mutants"]))
G9, MOC = ["doctrine_scan_repo_that_sach", "doctrine_scan_sach_xanh"], "moc_dot_bien_phai_khop_DUNG_MOT_CHO"


def lq(ten, fn):
    if ten.startswith(("doctrine_", "ac18_", "ac19_")):
        return True
    try:
        return "doctrine" in inspect.getsource(fn)
    except Exception:
        return False


ho_cu = sorted(n for n, f in t.CASES if lq(n, f) and n not in set(T))
db_cu = sorted(k for k, v in t.MUTANTS.items() if k in so_nen["mutants"] and set(v[2]) & set(ho_cu))
print(f"CASES nền={len(so_nen['cases'])} H={len(ten_h)} (tên khác nhau {len(set(ten_h))}) · T={len(T)} · MUTANTS nền={len(so_nen['mutants'])} H={len(t.MUTANTS)} · "
      f"đột biến mới={len(db_moi)} · họ doctrine cũ={len(ho_cu)} · đột biến cũ có đích trong họ={len(db_cu)}", flush=True)
assert all(n.startswith("doctrine_inv_") for n in T), [n for n in T if not n.startswith("doctrine_inv_")]
t0 = time.time()
rc = 0
if che_do == "so":
    print("T =", json.dumps(T, ensure_ascii=False))
    print("ĐỘT BIẾN MỚI =", json.dumps(db_moi, ensure_ascii=False))
    print("ĐỘT BIẾN CŨ CÓ ĐÍCH TRONG HỌ =", json.dumps(db_cu, ensure_ascii=False))
elif che_do in ("ca-moi", "ca-cu", "adr"):
    chon = {"ca-moi": T + [MOC] + G9, "ca-cu": ho_cu + [MOC], "adr": [n for n in ten_h if n.startswith("adr_song_")]}[che_do]
    kq = {}
    for n in chon:
        kq.update(t.chay_suite(t.CANONICAL, tmp / "ca", chi_chay={n}))
    bo_qua = {k: str(v)[:200] for k, v in kq.items() if isinstance(v, t.BoQua)}
    do = {k: str(v)[:400] for k, v in kq.items() if v is not None and k not in bo_qua}
    dat = sum(v is None for v in kq.values())
    for k, v in list(do.items())[:30]:
        print("  ĐỎ ", k, "→", v)
    for k, v in bo_qua.items():
        print("  BỎ QUA", k, "→", v)
    print(f"[{che_do}] CHỌN {len(chon)} · CHẠY {len(kq)} · ĐẠT {dat}/{len(chon)} · ĐỎ {len(do)} · BỎ QUA {len(bo_qua)} · {round(time.time() - t0)} giây")
    rc = int(not (dat == len(chon) == len(kq)))
elif che_do in ("db-moi", "db-cu"):
    nen_ca, chon = (set(T) | set(G9) | {MOC}, set(db_moi)) if che_do == "db-moi" else (set(ho_cu), set(db_cu))
    print(f"[{che_do}] lượt nền {len(nen_ca)} ca · pha đột biến {len(chon)} đột biến", flush=True)
    kq = sh.chay(t, nen_ca, lambda ten: chon & set(ten))
    print(f"[{che_do}] KẾT QUẢ manh.chay: rc={kq[0]} · ca đã chạy={len(kq[1])} · carrier={kq[2]} · lượt đột biến={kq[3]} · {round(time.time() - t0)} giây")
    rc = kq[0]
else:
    sys.exit(f"chế độ lạ: {che_do}")
sys.exit(rc)
