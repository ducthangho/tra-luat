import datetime, json, os, pathlib, subprocess, sys, time
out=pathlib.Path(__file__).resolve().parent
label,cwd,*cmd=sys.argv[1:]
(out/'logs').mkdir(exist_ok=True)
tmp=out/'tmp'/label
tmp.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(tmp),TMP=str(tmp),TEMP=str(tmp))
start=time.time()
with (out/'logs'/(label+'.log')).open('w') as f:
    f.write('COMMAND '+json.dumps(cmd,ensure_ascii=False)+'\nCWD '+str(pathlib.Path(cwd).resolve())+'\n')
    f.flush()
    r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
    f.write('\nRC '+str(r.returncode)+'\nSECONDS '+str(round(time.time()-start,2))+'\n')
print(json.dumps({'label':label,'rc':r.returncode,'seconds':round(time.time()-start,2)},ensure_ascii=False))
sys.exit(r.returncode)
