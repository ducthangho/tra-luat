import collections,hashlib,json,pathlib,re,subprocess
OUT=pathlib.Path(__file__).resolve().parent
summary={}
for path in sorted((OUT/'logs').glob('*.log')):
    text=path.read_text(errors='replace')
    rc=re.findall(r'^RC (-?\d+)$',text,re.M)
    item={'complete':bool(rc),'rc':int(rc[-1]) if rc else None}
    for pattern,name in [(r'== tl selftest (\d+/\d+) ==','selftest'),(r'^nền: (.+)$','baseline'),(r'^TỔNG: (.+)$','total'),(r'^  \[FAIL\] (.+)$','failed_tests')]:
        found=re.findall(pattern,text,re.M)
        if found:item[name]=found
    try:
        body='\n'.join(text.splitlines()[2:]); data=json.JSONDecoder().raw_decode(body.lstrip())[0]
        if isinstance(data,dict):item['json']={k:v for k,v in data.items() if k in ['ok','strict','flags','claims_flagged','advisory_count','expected','checked','file_count','violations','passed','total','failed']}
    except (ValueError,TypeError):pass
    summary[path.stem]=item
for label in ['doc-claims-h','doc-claims-base']:
    p=OUT/'logs'/(label+'.log')
    if p.exists():
        d=json.JSONDecoder().raw_decode('\n'.join(p.read_text().splitlines()[2:]).lstrip())[0]
        (OUT/(label+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2))
if all(summary.get(n,{}).get('complete') for n in ['selftest','selftest-base']):
    a=set(summary['selftest-base'].get('failed_tests',[]));b=set(summary['selftest'].get('failed_tests',[]))
    summary['selftest-delta']={'new_failures':sorted(b-a),'base_only':sorted(a-b),'same_failures':sorted(a&b)}
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
for name,item in summary.items():print(name,json.dumps(item,ensure_ascii=False))
