from pathlib import Path
import subprocess, re, hashlib, json, difflib, collections, datetime, os
R=Path.cwd();O=R/'out'; C=O/'candidate';H=O/'h'
def git(*a):return subprocess.check_output(['git','-C',str(R/'cay-kho'),*a])
def blocks(b):return dict(re.findall(rb'^~~~ ([\w-]+)\n(.*?)^~~~',b,re.M|re.S))
a=git('show','695916e:ops/specs/wp1466.md');b=(R/'cay-kho/ops/specs/wp1466.md').read_bytes(); A=blocks(a);B=blocks(b)
print('TIME',datetime.datetime.now(datetime.timezone.utc).isoformat())
print('SPEC',hashlib.sha256(b).hexdigest(),'BLOB_EQUAL',b==git('show','feb0b77:ops/specs/wp1466.md'))
for k in B:
 print('BLOCK',k,'EQUAL',A[k]==B[k],'BYTES',len(B[k]))
 (O/(k.decode()+'.txt')).write_bytes(B[k])
rel='docs/adr/0068-bat-bien-protocol-va-review-theo-lop.md'; old=(H/rel).read_bytes();new=old
ops=difflib.SequenceMatcher(None,A[b'adr'].splitlines(keepends=True),B[b'adr'].splitlines(keepends=True),autojunk=False).get_opcodes()
for tag,i,j,k,l in ops:
 if tag=='equal':continue
 x=b''.join(A[b'adr'].splitlines(keepends=True)[i:j]); y=b''.join(B[b'adr'].splitlines(keepends=True)[k:l])
 if not x:
  before=b''.join(A[b'adr'].splitlines(keepends=True)[max(0,i-1):i]);assert new.count(before)==1;new=new.replace(before,before+y,1)
 else:assert new.count(x)==1,(tag,x);new=new.replace(x,y,1)
(C/rel).write_bytes(new)
(O/'adr-r9-r10.diff').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='H/'+rel,tofile='candidate/'+rel)))
print('ADR_DIFF',len(old),len(new),'STATE_UNCHANGED',old.splitlines()[2]==new.splitlines()[2])
debt=B[b'adr'].decode().split('## Nợ\n')[1].split('\n## ')[0]; names=re.findall(r'^- `([^`]+)`:',debt,re.M)
print('DEBTS',len(names),'UNIQUE',len(set(names)),'NEW',sorted(set(names)-set(re.findall(r'^- `([^`]+)`:',A[b'adr'].decode().split('## Nợ\n')[1].split('\n## ')[0],re.M))))
ca=collections.Counter(re.findall(rb'`([^`\n]+)`',A[b'adr']));cb=collections.Counter(re.findall(rb'`([^`\n]+)`',B[b'adr'])); print('NEW_SPANS',dict((k.decode(),v) for k,v in (cb-ca).items()))
for n,prefix,path in [('0053','tran_kich_thuoc_sensitive','docs/adr/0053-tran-kich-thuoc-sensitive-len-sau-tep.md'),('0055','tran_loi_goi_codex','docs/adr/0055-tran-loi-goi-codex-len-muoi.md')]:
 matches=re.findall(('^'+prefix+': ADR-'+n+'@([0-9a-f]{40})$').encode(),b,re.M);assert len(matches)==1
 oid=matches[0].decode();rc=[]
 for rev in [oid,oid+'^1']:
  rc.append(subprocess.run(['git','-C',str(R/'cay-kho'),'cat-file','-e',rev+':'+path],capture_output=True).returncode)
 print('OPT_IN',n,oid,'cat-file',rc,'FIRST_PARENT',oid.encode() in git('rev-list','--first-parent','origin/master').splitlines())
print('SHALLOW',git('rev-parse','--is-shallow-repository').decode().strip())
print('NANG_TRAN_FIELDS',{x:len(re.findall(r'\b'+x+r'\b',b.decode())) for x in ['ai_nang','can_cu','tran_cu','tran_moi']})
print('NUMSTAT_H',git('diff','--numstat','695916e','da4e876','--','.claude/dev/packet_loop.py','.claude/dev/packet_loop_test.py','docs/PROTOCOL_DA_PHIEN.md',rel).decode())
print('NUMSTAT_ADR_R10',len(new.splitlines()),'TOTAL_H_PLUS_ADR',443+len(new.splitlines())-len(old.splitlines()))
# Save complete changed lines and full-text promise sweep; neither is used as an exhaustive semantic filter.
(O/'spec.diff').write_bytes(git('diff','695916e','feb0b77','--','ops/specs/wp1466.md'))
pat=r'bất kỳ|[Đđ][Úú][Nn][Gg] [Mm][Ộộ][Tt]|bản sao|bản hiển thị|450|500|nang_tran|28 tên nợ|27 tên nợ'
rows=[f'{i}: {l}' for i,l in enumerate(b.decode().splitlines(),1) if re.search(pat,l)]
(O/'promise-sweep.txt').write_text('\n'.join(rows)+'\n');print('PROMISE_SWEEP_LINES',len(rows))
