from pathlib import Path
import subprocess, hashlib, json, os, datetime, sys
R=Path.cwd(); O=R/'out'
def snap(root):
 d={}
 for p in root.rglob('*'):
  if p.is_symlink():d[str(p.relative_to(root))]=['link',os.readlink(p)]
  elif p.is_file():
   s=p.stat();d[str(p.relative_to(root))]=[s.st_size,s.st_mtime_ns,hashlib.sha256(p.read_bytes()).hexdigest()]
 return d
print('UTC',datetime.datetime.now(datetime.timezone.utc).isoformat())
print('PYTHON',sys.version.replace('\n',' '))
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
for args in [['git','--version'],['git','-C','cay-kho','rev-parse','HEAD','HEAD^{tree}'],['git','-C','cay-kho','status','--porcelain=v1','--untracked-files=all'],['git','-C','out/candidate','diff','--stat'],['git','-C','out/candidate','diff','--check']]:
 p=subprocess.run(args,capture_output=True,text=True,env=env); print('CMD',args,'RC',p.returncode,'OUT',p.stdout,'ERR',p.stderr)
for n in ['cay-kho','kho.git']:
 a=json.loads((O/(n+'-before.json')).read_text());b=snap(R/n)
 added=sorted(set(b)-set(a));removed=sorted(set(a)-set(b));changed={k:[a[k],b[k]] for k in a.keys()&b.keys() if a[k]!=b[k]}
 result=dict(before=len(a),after=len(b),added=added,removed=removed,changed=changed)
 (O/(n+'-integrity.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print('INTEGRITY',n,len(a),len(b),'ADDED',len(added),'REMOVED',len(removed),'CHANGED',len(changed))
 assert not (added or removed or changed),result
p=R/'cay-kho/ops/specs/wp1466.md';raw=p.read_bytes();print('SPEC_HASH',hashlib.sha256(raw).hexdigest());print('REBUILD_EQUAL',(O/'rebuilt-r10.md').read_bytes()==raw)
for field in ['ai_nang','can_cu','tran_cu','tran_moi']: print('FIELD',field,raw.count(field.encode()))
for n,line in enumerate(raw.decode().splitlines(),1):
 if line.startswith('| N12 |') or line.startswith('Kích thước, đối chiếu') or line.startswith('- `{{TRANG_THAI}}`') or line.startswith('| G8 |'):print('SPEC_LINE',n,line)
records=json.loads((O/'probes.json').read_text())
for name in ['K01/attached-after','K01/space-separator','K02/attached-after','K03/attached-after','K03/blank-separator','K04/blank-separator','id/01','mutant99/01']:
 x=next(x for x in records if x['name']==name);print('PROBE',name,'RC',x['rc'],'OUT',x['stdout'].strip(),'ERR',x['stderr'].strip())
