from pathlib import Path
import subprocess,json
R=Path.cwd(); logs=[]
for n in ['h','candidate']:
 p=R/'out'/n
 calls=[]
 if not p.exists(): calls.append(['git','clone','--shared','--no-checkout',str(R/'cay-kho'),str(p)])
 calls += [['git','-C',str(p),'fetch',str(R/'cay-kho'),'refs/exec/h'],['git','-C',str(p),'config','core.abbrev','7'],['git','-C',str(p),'config','core.hooksPath','/dev/null'],['git','-C',str(p),'checkout','--detach','da4e876890a1ebe99bb87de9e9a3b4f63c9fd5dd']]
 for a in calls:
  q=subprocess.run(a,capture_output=True,text=True); logs.append(dict(cmd=a,rc=q.returncode,stdout=q.stdout,stderr=q.stderr));
  (R/'out/finish-setup.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2))
  assert q.returncode==0,logs[-1]
 print(n,subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD','HEAD^{tree}'],text=True),flush=True)
