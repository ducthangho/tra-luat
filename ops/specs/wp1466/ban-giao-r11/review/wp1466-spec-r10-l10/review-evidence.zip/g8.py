from pathlib import Path
import os,sys,json
O=Path(__file__).resolve().parent; C=O/'candidate';os.environ['TMPDIR']=str(O/'tmp');os.environ['PYTHONDONTWRITEBYTECODE']='1'
sys.path.insert(0,str(C/'.claude/dev'));os.chdir(C)
import packet_loop_test as T,packet_loop_test_manh as M
stocks=[n for n,_ in T.CASES if n.startswith('doctrine_inv_dong_inv_ngoai')]
print('STOCK_G8',len(stocks),flush=True)
res=T.chay_suite(O/'id99/packet_loop.py',O/'g8-stock',set(stocks));print('STOCK_UNDER_ONLY99',len(res),sum(v is None for v in res.values()),'DETAIL',str(res),flush=True)
vals=sorted(set(['00','01','09','10','28','98']+[f'{i:02d}' for i in range(1,29)]));names=[]
for val in vals:
 name='doctrine_inv_rv_g8_id_'+val;names.append(name)
 T.CASES.append((name,T._inv_ca(T._inv_o2('| INV-'+val+' | x | y | chưa đo |'),9,'nằm ngoài tiểu mục')))
a='_INV_ID_TRAN = r"INV-[0-9]{2}(?![0-9A-Za-z-])"';b='_INV_ID_TRAN = r"INV-99(?![0-9A-Za-z-])"'
T.MUTANTS['rv_g8_only99']=(a,b,names)
result=M.chay(T,set(names+stocks),lambda all_names:{'rv_g8_only99'})
print('RESULT',result,flush=True)
(O/'g8-summary.json').write_text(json.dumps(dict(stock={k:None if v is None else str(v) for k,v in res.items()},new_values=vals,result=result),ensure_ascii=False,indent=2))
sys.exit(result[0])
