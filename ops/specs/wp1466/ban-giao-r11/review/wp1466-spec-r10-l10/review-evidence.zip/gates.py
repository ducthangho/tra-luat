from pathlib import Path
import subprocess,json,os,sys,concurrent.futures,datetime
O=Path(__file__).resolve().parent
jobs=[(n,cmd) for n in ['h','candidate'] for cmd in ['claims','doctrine','adr']]
def run(job):
 n,typ=job; root=O/n
 args={'claims':[sys.executable,'-B','scripts/tl.py','doc-claims-check','--strict','--json'],'doctrine':[sys.executable,'-B','.claude/dev/packet_loop.py','doctrine-scan','--root','.'],'adr':[sys.executable,'-B','.claude/dev/packet_loop.py','adr-song','--root','.']}[typ]
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(O/'tmp'))
 q=subprocess.run(args,cwd=root,capture_output=True,text=True,env=env)
 record=dict(cwd=str(root),argv=args,rc=q.returncode,stdout=q.stdout,stderr=q.stderr)
 (O/(n+'-'+typ+'.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2))
 if typ=='claims':
  j=json.loads(q.stdout);print(n,typ,'rc',q.returncode,json.dumps({k:j.get(k) for k in ['ok','files_scanned','flags','by_layer','claims_flagged','advisory_count','layers_skipped']},ensure_ascii=False),flush=True)
 else: print(n,typ,'rc',q.returncode,q.stdout,q.stderr,flush=True)
 return record
(O/'tmp').mkdir(exist_ok=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p: list(p.map(run,jobs))
