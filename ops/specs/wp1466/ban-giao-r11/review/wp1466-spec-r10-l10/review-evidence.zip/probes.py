from pathlib import Path
import subprocess,sys,json,re,hashlib,collections
O=Path(__file__).resolve().parent;C=O/'candidate'; root=O/'probe-root';(root/'docs').mkdir(parents=True,exist_ok=True)
p=root/'docs/PROTOCOL_DA_PHIEN.md';base=(C/'docs/PROTOCOL_DA_PHIEN.md').read_bytes();script=C/'.claude/dev/packet_loop.py'
records=[]
def run(name,raw,expected=None,code=script):
 p.write_bytes(raw);args=[sys.executable,'-B',str(code),'doctrine-scan','--root',str(root)]
 r=subprocess.run(args,capture_output=True,text=True);rec=dict(name=name,argv=args,rc=r.returncode,stdout=r.stdout,stderr=r.stderr,expected=expected);records.append(rec)
 print(name,'rc',r.returncode,'expected',expected,'msg',(r.stdout+r.stderr).strip().replace('\n',' / ')[:260],flush=True)
 if expected is not None:assert r.returncode==expected,rec
 return rec
run('baseline',base,0)
keys=json.loads((O/'keys.json').read_text())
for k,v in keys.items():
 unit=(O/(k+'.raw')).read_bytes()
 # Ordinary documentary examples, no executable or hostile payloads.
 stem=base+b'\n\n## Phu luc thu nghiem\n\n'
 run(k+'/standalone',stem+unit+b'\n\n',9)
 for name,copy in [('attached-after',unit+b'\nGhi chu thu nghiem.\n'),('space-separator',unit+b'\n \nGhi chu thu nghiem.\n')]:
  run(k+'/'+name,stem+copy,9 if k=='K01' else 0)
 run(k+'/blank-separator',stem+unit+b'\n\nGhi chu thu nghiem.\n',9 if v['order'] or k=='K01' else 0)
 run(k+'/fenced-copy',stem+b'```text\n\n'+unit+b'\n\n```\n',0)
 # Additional independent effects: valid root byte hash cannot be rescued by a copied unit.
 run(k+'/change-original',base.replace(unit,unit.replace(b' ',b'  ',1),1),9)
code=script.read_text();a='_INV_ID_TRAN = r"INV-[0-9]{2}(?![0-9A-Za-z-])"';b='_INV_ID_TRAN = r"INV-99(?![0-9A-Za-z-])"';assert code.count(a)==1
mut=O/'id99/packet_loop.py';mut.parent.mkdir(exist_ok=True);mut.write_text(code.replace(a,b))
values=sorted(set(['00','01','09','10','28','98','99']+[f'{i:02d}' for i in range(1,29)]))
for val in values:
 raw=base+('\n\n## Phu luc ID\n\n| INV-'+val+' | ghi chu |\n').encode()
 run('id/'+val,raw,9)
 run('mutant99/'+val,raw,9 if val=='99' else 0,mut)
for label,val,expected in [('debt','INV-12-CONG-VERDICT-THEO-LOP',0),('three-digits','INV-010',0),('suffix-letter','INV-01A',0),('suffix-hyphen','INV-01-',0),('punctuation','INV-01.',9)]:
 run('id-boundary/'+label,base+('\n\n## Phu luc ID\n\n| '+val+' | ghi chu |\n').encode(),expected)
for label,val in [('fullwidth','INV-\uff10\uff11'),('cf','INV-\u200b01'),('soft-hyphen','INV\u00ad-01')]:
 run('id-normalize/'+label,base+('\n\n## Phu luc ID\n\n| '+val+' | ghi chu |\n').encode(),9)
(O/'probes.json').write_text(json.dumps(records,ensure_ascii=False,indent=2));print('TOTAL',len(records),'MATCHED',sum(x['rc']==x['expected'] for x in records),'DOMAIN_VALUES',len(values))
