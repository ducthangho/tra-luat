# wp1466 r10 — ADR-0068: bất biến protocol có ID và ô cổng; bảy đơn vị luật khoá theo địa chỉ và băm byte thô trong doctrine-scan
packet_id: wp1466
revision: 10
tran_loi_goi_codex: ADR-0055@d2e3052d479d140b7e7b91df41ec4914fab7d544
tran_kich_thuoc_sensitive: ADR-0053@8ab100793df9831505f495543a74044b91c2c9ab

Trạng thái: `proposed`, CHƯA đóng băng, chưa có lease. Đặc tả này không cấp việc: phải có Issue và lease còn hiệu lực (protocol §3.2, §4). Revision 5 soạn ngày 21-11-2026 (UTC) trên `origin/master` `5a152c18dfb0890a9031bf05c31ab7cab534a652` bởi một phiên soạn đặc tả Claude Opus 5.5 (cloud, Linux), sau review Codex lượt 4 của r4 (commit `937d135`, verdict `ops/specs/wp1466/review/r4-l4/VERDICT.md`, sha256 `400234b2ce15af8ed09571643f695fea56744bd10a12b03d500e9177e7039175`: `changes_requested`; bảng (i) 3 lớp, cả ba P2, 0 P0, 0 P1, 0 lớp mới; bảng (ii) 4 lớp nợ kế nhiệm) và sau checkpoint lần hai nêu ở mục 0. Revision 6 soạn cùng ngày, cùng người soạn, trên `origin/master` `4e56f005785db1b04e043bb71fc694a674a8dc9f`, sau review Codex lượt 5 của r5 (commit `05d12f1`, verdict `ops/specs/wp1466/review/r5-l5/VERDICT.md`, sha256 `9ce3dce34b61252d70d418881684fdfe471cb7d147f02bffb08ba60ce59af767`: `changes_requested`; bảng (i) 1 lớp P2, 0 P0, 0 P1, 0 lớp mới, 0 lớp tái mở; hội tụ 2/3); r6 chỉ sửa lớp ấy (mục 0). Revision 7 soạn cùng ngày, cùng người soạn, trên `origin/master` `4e56f005785db1b04e043bb71fc694a674a8dc9f` (đo lại 04:56:46Z), sau review Codex lượt 6 của r6 (commit `6c4ffe9`; hồ sơ lưu ở `e73a7ad`; verdict `ops/specs/wp1466/review/r6-l6/VERDICT.md`, sha256 `2a0590460bc42eb0324c11ea69706112fc2dda49108ab29f7a7b04265068d34c`: `changes_requested`; bảng (i) 1 lớp P2, 0 P0, 0 P1, 0 lớp mới, 0 lớp tái mở; hội tụ 0/1); r7 chỉ sửa lớp ấy, theo mục sổ `xet_lai_cach_lam` nêu ở mục 0. Revision 8 soạn cùng ngày, cùng người soạn, trên `origin/master` `4e56f005785db1b04e043bb71fc694a674a8dc9f` (đo lại 05:41:07Z), sau review Codex lượt 7 của r7 (commit `3c89d87`; hồ sơ lưu ở `fd2f17e`; verdict `ops/specs/wp1466/review/r7-l7/VERDICT.md`, sha256 `082db6d7c1cb824336268bff5c274990bea83bb783eefa2986a38df7ac8c8d54`: `changes_requested`; bảng (i) 1 lớp P2, 0 P0, 0 P1, 0 lớp mới, 0 lớp tái mở; hội tụ 0/1) và sau quyết định E2 của chủ kho tách khối tiền kiểm (mục 0); r8 chỉ rút khối ấy và thu hẹp điều kiện bắt đầu về công cụ sẵn có. Người soạn r1 đến r4 là Claude Fable 5.2; từ r5 là Claude Opus 5.5, theo quyết định E2 của chủ kho ghi hộ ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7055711912 (Fable 5.2 hết hạn mức). Quyết định ấy không đổi reviewer và không đổi executor mã (mục 1). Giờ ghi cạnh số là UTC; giờ không ghi ngày là của 21-11-2026. Đo lại trước mỗi bước công bố. Revision 9 soạn ngày 26-11-2026 bởi phiên điều phối Claude Opus 5.5 (cloud, Linux), trên `origin/master` `1fac6ced8e5a8c76fdb2699edac779a4251f6149`, sau lượt 1 của executor (commit cục bộ `96e44721a149b363c83af4fcabe3599232f6512b`) và sau hai quyết định của chủ kho ghi hộ ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7191469520: Q0 (E3) và Q2 (E5). r9 chỉ đổi những gì nêu ở mục 0, đoạn *Revision 9*. Revision 10 soạn ngày 26-11-2026, cùng người soạn, trên `origin/master` `695916ea3bfffdd7b2e8fcb94b0740b3c421fe70`, sau review mã exact-H lượt 1 (H `da4e876`, verdict `blocked`, ghi ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7201334017) và sau hai quyết định của chủ kho ghi hộ ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7201538748; r10 chỉ đổi những gì nêu ở mục 0, đoạn *Revision 10*. Lịch sử lớp finding ở mục 19.

## 0. Phạm vi — đọc trước

**wp1466 hứa đúng ba việc, và không hứa gì ngoài ba việc ấy:**

1. ADR-0068 (luật): review theo lớp là bất biến `INV-12` cho mọi lượt review; mỗi bất biến của protocol có ID và khai cổng.
2. Protocol: hai bất biến mới ở §1, bảng §1.1 có 28 dòng, §8.3 khai là `INV-12`, §12 buộc ghi mục sổ `xet_lai_cach_lam`, một dòng ở §20.
3. Cổng toàn vẹn trong `doctrine-scan`: 7 **đơn vị khoá** của protocol, mỗi đơn vị phải nằm ĐÚNG ĐỊA CHỈ của nó và hiển thị ở đó, có ĐÚNG MỘT bản hiển thị đứng thành đơn vị cùng loại (trọn mục, hay khối) trong cả tệp, và đúng băm trên BYTE THÔ ghi trong mã; và không ID bất biến nào, so trên dạng hiển thị của dòng, được đứng trên một dòng bảng ngoài tiểu mục §1.1.

**Những việc KHÔNG thuộc wp1466.** Đặc tả này không hứa, không đặt tiêu chí nghiệm thu, và không mang hợp đồng thiết kế nào cho chúng. Chúng là nợ kế nhiệm có Issue, có tên nợ trong ADR-0068 và có thẩm quyền:

| việc | packet | nợ trong ADR-0068 |
|---|---|---|
| đối chiếu ngữ nghĩa ô cổng; mọi phép đọc tệp cổng, tệp ca, tệp ADR và việc giữ đích đọc trong gốc; khai báo ca theo cấu trúc; nợ là một mục của `## Nợ` | Issue #1469 | `INV-BANG-DOI-CHIEU-NGU-NGHIA` |
| đếm bản sao nguyên byte của một đơn vị khoá khi bản sao không đứng thành đơn vị cùng loại: dính chữ trên hay dưới, cách bằng dòng chỉ có khoảng trắng, trọn mục kèm đoạn nối, thẻ HTML giữa dòng | Issue #1469 | `INV-KHOA-BAN-SAO-DINH-CHU` |
| verdict máy đọc theo lớp: lược đồ v2, danh tính provider, vị từ chuyển tiếp, K4 của `kiem-merge`, lệnh kiểm verdict đặc tả và kế hoạch | Issue #1470 | `INV-12-CONG-VERDICT-THEO-LOP` |
| công cụ tiền kiểm lease toàn kho: closure của §5 khi policy tồn tại, chuẩn hoá và so tiền tố cho một write set bất kỳ, nguồn dữ liệu chỉ từ ảnh chụp máy chủ, mọi đầu vào của quyết định cấp lease; gồm giới hạn G1 đến G10 ở mục 1 | Issue #1484 | `INV-02-TIEN-KIEM-CAP-LEASE-KHONG-CLOSURE` |

Thẩm quyền của việc tách: chủ kho chọn "Duyệt tách 3 packet" (mã E2), ghi hộ ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7053593553. Thẩm quyền của việc tách khối tiền kiểm: chủ kho chọn "Tách khối ra (Recommended)" (mã E2), ghi hộ ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7058057029; Issue kế nhiệm #1484 (`open` lúc 05:41:58Z, REST GET) khai `depends_on: [1466]`.

**Nhánh nhận của chuỗi — đã quyết** (lớp `tach-packet-bo-dieu-kien-integration`). Chủ kho quyết (mã E5), ghi hộ ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7054756452: ba packet #1466, #1469, #1470 merge THẲNG vào `master`, không qua một `mission/<issue>/integration`. Phạm vi của quyết định chỉ gồm ba packet ấy; nó KHÔNG gồm packet B4 (#1462), vốn đi theo đường land của Mission #1172. Điều kiện cấp lease, cho từng packet của chuỗi: merge commit của PR giao nộp packet liền trước nằm trên `git rev-list --first-parent origin/master`, và `base_sha` của lease là một commit chứa merge commit ấy. Với wp1466, "packet liền trước" là B4: wp1466 chỉ bắt đầu khi thay đổi của B4 đã nằm trên first-parent `master`, bằng đường nào là việc của Mission #1172.

**Checkpoint của §12 đã kích hoạt sau review lượt 3** (hai chuyển tiếp liên tiếp dưới 50%; sáu lớp có mặt ở cả ba lượt). Phiên điều phối đã xét lại cách làm và ghi mục sổ ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7054361419. Revision 4 đi theo đúng hướng ghi ở đó:

1. Bốn nhóm việc có biểu hiện còn lại nằm ở #1469 và #1470: wp1466 bỏ mọi lời hứa về chúng (bảng trên; mục 19 ghi từng lớp).
2. Khoá văn bản đổi sang danh sách cho phép CẤU TRÚC: địa chỉ, duy nhất, rồi băm byte; không nhận dạng viết tương đương nào (mục 8.3).
3. N8 so AST của từng nút sẵn có và xét từng tên được gán (mục 9).
4. Tiền kiểm lease thu về đúng phép đo kho đang có, phần còn lại ghi nợ có tên (mục 1).
5. Nhánh nhận: quyết định E5 ở trên.

**Checkpoint lần hai, sau review lượt 4.** Hội tụ r3→r4 là 3/9, chuyển tiếp thứ hai liên tiếp dưới 50%. Phiên điều phối xét lại lần nữa và ghi mục sổ `xet_lai_cach_lam` thứ hai ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7055285508: đi tiếp, vì số lớp mở ở bảng (i) giảm 13 → 9 → 3, không còn P1, không có lớp mới, và ba P2 còn lại có cách chữa đo được. Mục sổ ấy không gắn mã E nào. Revision 5 đi theo đúng ba cách chữa ghi ở đó. Mỗi cách đổi thiết kế cho cả lớp, không vá riêng biểu hiện reviewer đã chỉ; mục 19 ghi các đường vào cùng cơ chế mà người soạn tự liệt kê thêm:

1. `kiem-chuoi-khong-doc-cau-truc` (F05.f/g): cổng đọc BYTE THÔ một lần; biên của mục và khối chỉ là dòng rỗng 0 byte; đơn vị phải hiển thị tại địa chỉ của nó; ID bất biến so trên dạng hiển thị của dòng (mục 8.3).
2. `tieu-chi-dong-xoa-khong-do-hanh-vi` (F08.c): N8 nhận nút mới theo một NGỮ PHÁP ĐÓNG (danh sách cho phép các dạng cú pháp), cùng một luật cho hai chế độ; khối chèn trong `cmd_doctrine_scan` so với một mẫu AST cố định; sổ đăng ký ca và đột biến đo thêm lúc chạy (mục 9).
3. `tien-kiem-lease-chua-du` (F11.b/c): r5 đặt việc vắng policy change-impact trên base làm điều kiện bắt đầu, và dựng một khối tiền kiểm cho phần chuẩn hoá và so tiền tố của §5 mà `ai-dang-giu` không làm được. Khối ấy đã rút ở r8 (đoạn cuối mục này).

**Revision 6 và 7, sau review lượt 5 và 6.** Lượt 5 cho hội tụ 2/3: U là ba lớp bảng (i) cuối lượt 4; F là phần wp1466 của `kiem-chuoi-khong-doc-cau-truc` và lớp `tieu-chi-dong-xoa-khong-do-hanh-vi`. Lượt 6 cho 0/1. Cả hai lượt không có lớp mới, không có lớp tái mở; lớp duy nhất còn mở ở bảng (i) là `tien-kiem-lease-chua-du`. r6 và r7 chỉ sửa lớp ấy, bằng cách mở rộng khối tiền kiểm: r6 thêm một bất biến về nguồn dữ liệu (F11.d), r7 viết bất biến ấy thành danh sách đầu vào (F11.e, F11.f), theo mục sổ `xet_lai_cach_lam` ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7057370281. Bốn tệp của nguyên mẫu, khoá văn bản, N8, khối `khoa`, các khối protocol và bảng (ii) không đổi ở cả hai revision. Khối và bảng đầu vào của r6, r7 đã rút ở r8; hồ sơ của chúng ở mục 18 và mục 19.

**Revision 8, sau review lượt 7: lần thứ bảy của cùng một lớp, và quyết định E2 tách khối tiền kiểm.** Lượt 7 cho hội tụ 0/1: U là lớp duy nhất của bảng (i) cuối lượt 6; F là 0. F11.e và các đường PyYAML cụ thể của F11.f được xếp đã đóng, nhưng lượt 7 đo được ba biểu hiện mới trong cùng lớp. F11.g: đối số `--sau-dang` loại một người giữ theo `lease_id` tự khai, không đối chiếu với lease vừa đăng. F11.h: dòng `import os, sys` ở đầu khối chạy trước chốt `-I`, nên với `-S -X frozen_modules=off` `os` nạp được từ PYTHONPATH. F11.i: mã quét lease nạp từ B đọc `ls-tree` không `-z`, nên tên tệp lease bị git quote bị bỏ mà không báo. Lớp này có mặt ở cả bảy lượt. Hai tín hiệu của §12 cùng bật: hai chuyển tiếp liên tiếp dưới 50% (r5→r6 và r6→r7, cả hai 0/1), và một lớp có mặt ba lượt trở lên. Phiên điều phối đưa ba phương án cho chủ kho (mã E2, vì một phương án là nâng trần lời gọi Codex, khi đó còn 2/10): tách khối, vá tiếp, hay nâng trần. Chủ kho chọn "Tách khối ra (Recommended)", ghi hộ ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7058057029. Revision 8 làm đúng lựa chọn ấy:

1. Xoá khối `tien-kiem`, bảng *Đầu vào của khối* (V1 đến V11, P1 đến P5), các bước T0 đến T7, bất biến `I-NGUON`, các kịch bản và đột biến của khối, cùng mọi lời khai rằng khối đóng hay dừng khi không đo được.
2. Điều kiện bắt đầu 3a đến 3e (mục 1) chỉ chạy công cụ đã có trên base và đòi kết quả của chúng: so tập cặp ref, vắng policy trên `origin/master`, `ai-dang-giu` cho từng đường dẫn, số ADR, và đo lại sau khi đăng. Giới hạn đã biết của các công cụ ấy được ghi thẳng ở bảng G1 đến G10 của mục 1. Bước số ADR đổi nhãn từ 3f thành 3d, vì bước 3d cũ (khối) đã rút.
3. wp1466 không hứa rằng điều kiện bắt đầu phát hiện mọi lease giao write set. Phần còn thiếu là nợ `INV-02-TIEN-KIEM-CAP-LEASE-KHONG-CLOSURE`: tên đã có sẵn trong ADR-0068, mục *Nợ*, và trong ô `còn nợ` của dòng `INV-02` ở bảng §1.1. Nợ ấy giao cho Issue #1484 (bảng đầu mục này; mục 14).

Theo protocol §8.3, chuyển biểu hiện ra ngoài phạm vi KHÔNG được tính là vá. Lớp `tien-kiem-lease-chua-du` vì vậy không được r8 gọi là đã vá; nó chuyển sang bảng (ii) với thẩm quyền là quyết định E2 trên, và slug giữ nguyên trong lịch sử (mục 19). Những gì r8 không đổi: bốn tệp của nguyên mẫu (`c35ee03`, +434 −4), khoá văn bản, khối `khoa`, các khối protocol và băm byte, N8 (`do-pham-vi`), `so-dang-ky`, khối `adr`, và các dòng bảng (ii) cũ. Kích thước của đặc tả: r7 là 1022 dòng, 184992 byte; r8 là 882 dòng, 158467 byte.

**Revision 9, sau lượt 1 của executor: hai quyết định của chủ kho.** Lượt 1 (Claude Fable 5.2, commit cục bộ `96e4472`, +443 −4) đúng đặc tả r8 từng byte, nhưng đo tại chỗ cho thấy bước CI bắt buộc `doc-claims-check --strict` đỏ trên H (rc 2) trong khi nền xanh (rc 0): ba cờ L12 `TEST_ID_UNKNOWN` ở dòng `INV-01`, `INV-02`, `INV-14` của bảng §1.1, vì `doc-claims-check` đọc mọi chuỗi dạng `r<số>_…` trong backtick là tên ca selftest của `scripts/tl.py`. Phiên điều phối đo lại độc lập và ra cùng kết quả (`claims_flagged` 392 → 395). Hai quyết định, ghi hộ ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7191469520:

1. Q0 (E3), "Ra đặc tả r9 (Recommended)": sửa theo LỚP chứ không theo ba dòng bị cờ. Cả 18 con trỏ `ca:` của bảng §1.1 viết không backtick, và đoạn dẫn của §1.1 thêm một câu nêu luật ấy, để dòng thêm về sau không vấp lại cùng cơ chế. Việc đổi này chạm khối `p2-moi`, băm đơn vị của `K01` (khối `khoa`), và hằng `INV_KHOA_PROTOCOL` của mã. Bản nháp đầu của câu thêm viết tên lệnh selftest trong backtick và vấp lớp L8 `TL_COMMAND_UNKNOWN` của cùng cổng; câu cuối không có chuỗi nào trong backtick khớp L8 hay L12. Đo trên H cộng bảng r9 cộng băm `K01` mới: `doc-claims-check --strict` rc 0 (`claims_flagged` 392, bằng nền, 0 cờ), `doctrine-scan` rc 0. Cổng không phân tích nội dung ô `cổng`, nên bỏ backtick chỉ đổi băm.
2. Q2 (E5), "Giữ bản vá (Recommended)": luật *Phần đầu tệp* ở mục 8.3, do executor tự phát hiện và vá theo lớp ở lượt 1, nay là hợp đồng.

Những gì r9 không đổi: ADR-0068 (khối `adr`), năm khối protocol còn lại, sáu băm `K02` đến `K07`, mọi tiêu chí N1 đến N16, trần, write set. Nguyên mẫu `nguyen-mau-r5/` giữ nguyên làm hồ sơ; mã giao nộp đối chiếu với đặc tả r9, không với nguyên mẫu.

**Revision 10, sau review mã exact-H lượt 1: hai quyết định của chủ kho.** Review mã Codex lượt 1 trên H `da4e876` cho `blocked`: lớp P2 `phep-dem-ban-sao-khong-phu-ca-tep` (23 trên 43 biến thể bản sao nguyên byte không đứng thành đơn vị cho rc 0, trong khi ADR và đặc tả hứa "ở chỗ hiển thị bất kỳ"; đây là câu Q3 executor nêu từ lượt 1) và lớp P3 `ca-id-chi-do-mot-gia-tri` (sáu ca G8 đều dùng `INV-99`; đột biến chỉ nhận 99 sống). Hai quyết định, ghi hộ ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7201538748:

1. Q3 (E3), "Thu hẹp lời hứa, chuyển #1469 (Recommended)": ADR-0068 (khối `adr`, đoạn Q3 và mục *Nợ*) và đặc tả (mục 0, M3, mục 8.3, N4) nói đúng phép (3) đo: bản hiển thị đứng thành đơn vị cùng loại. Phần bản sao không đứng thành đơn vị là nợ có tên `INV-KHOA-BAN-SAO-DINH-CHU`, giao cho Issue #1469 (bảng đầu mục này). Mã của phép (3) không đổi. Theo protocol §8.3, chuyển biểu hiện ra ngoài phạm vi KHÔNG được tính là vá: lớp này sang bảng (ii) với thẩm quyền là quyết định trên.
2. E2, "Nâng trần lên 500 dòng (Recommended)": `nang_tran` ADR-0053 cho wp1466 lên 500 dòng thêm (mục 10, N12), để đóng lớp P3 bằng ca G8 cho ID thật và các biên cùng một đột biến thu hẹp miền số (mục 8.3, bảng G, dòng G8).

Những gì r10 không đổi: sáu khối protocol và bảy băm khoá (protocol không đổi so với r9), khối `do-pham-vi`, khối `so-dang-ky`, write set. Khối `adr` đổi ở đoạn Q3 và thêm một mục *Nợ*; dòng Trạng thái phải dẫn lần duyệt băm r10 (mục 8.1).

## 1. `packet_id` · `packet_issue`

| trường | giá trị |
|---|---|
| packet | `wp1466`, revision 8, generation 1. Tiêu đề H1 và hai dòng khai ngay dưới nó là khai báo định danh theo grammar của `ADR-0063` |
| `packet_issue` | #1466 (`open` lúc 05:41:58Z, REST GET) |
| mission | không (mục 16, D8) |
| base | `origin/master` lúc cấp lease, sau khi làm mới ref theo điều kiện 3a, và phải chứa merge commit của PR giao nộp packet B4 (#1462). Soạn r5 trên `5a152c18dfb0890a9031bf05c31ab7cab534a652`; r7 đo lại trên `4e56f005785db1b04e043bb71fc694a674a8dc9f` (S17); r8 đo lại trên cùng commit (S18) |
| `depends_on` | `[1462]`. 05:41:58Z, REST GET: #1462 còn `open`; 05:41:09Z, lease `wp1462-r8-g2-claude` đang giữ `.claude/dev/packet_loop.py` và `.claude/dev/packet_loop_test.py` (S18) |
| packet sau | #1469 rồi #1470 (mục 0); #1484 nhận nợ tiền kiểm lease (mục 0, mục 14) |
| executor | Claude Code, model yêu cầu Fable 5.2 (quyết định E2 đổi người soạn ở đầu tệp giữ nguyên executor mã), môi trường `cloud`; identity `claude` / `claude_code` / `machine/local`, họ model `claude` |
| reviewer | Codex CLI, model yêu cầu `gpt-6-astra`, `model_reasoning_effort=xhigh`, gọi qua `.claude/dev/launcher.py run` trên clone độc lập đã ghim `core.abbrev 7`; identity `codex` / `codex_cli` / `machine`, họ model `openai`; `assurance_target: cross_approved`. Dùng đúng mẫu verdict của `.claude/skills/cross-review/SKILL.md`. Áp cho cả review đặc tả lẫn review mã. Model và effort thực phục vụ ghi theo `ADR-0065` |
| luật merge | `ADR-0060`, mặc định theo `ADR-0062`. Điều kiện severity của packet này chặt hơn mặc định: 0 finding P0, P1, P2, P3 còn mở trên H; không dùng dòng miễn P3 |
| windows | `ADR-0060` M3 xếp `required` vì diff chạm `.claude/dev/**`. Packet này không chạy Windows CI và không chạy Windows local: nó đi bằng dòng `windows: <H> mien` của chủ kho (mục 17, C3) |
| `full_mutant_audit` | bắt buộc (`ADR-0060` M9, K7): một lượt `ci-dot-bien-du.yml` `success` trên đúng H với mọi job `success` |
| `pham_vi_e` | chạm E5, không chạm E4 (mục 12) |

**Điều kiện bắt đầu**, đủ cả bốn. Mỗi bước không chạy được là KHÔNG ĐO ĐƯỢC và chặn việc cấp lease; đầu ra rỗng của một lệnh hỏng không phải bằng chứng.

1. Chủ kho duyệt `spec_hash` của tệp này (E5).
2. PR giao nộp của #1462 đã merge: merge commit của nó nằm trên `git rev-list --first-parent origin/master`, đo SAU bước 3a (điều kiện cấp lease của mục 0).
3. Kiểm trước khi cấp lease, chạy NGAY TRƯỚC khi cấp, đúng thứ tự, CHỈ bằng công cụ đã có trên base (`git` và `ops/lease_publish.py ai-dang-giu`). Mỗi bước nêu kết quả phải có. Kết quả khác, lệnh hỏng hay đầu ra rỗng ⇒ không cấp lease. Đây là phép đo của người cấp lease bằng công cụ sẵn có, kèm giới hạn ghi ở bảng ngay dưới. Nó không phải một chốt đóng ranh giới của §5, và wp1466 không hứa gì về các giới hạn ấy.
   - **3a — độ mới ref.** Trên một clone không shallow, so TẬP CẶP (tên nhánh, SHA) của `git ls-remote --heads origin` với `git for-each-ref refs/remotes/origin` (bỏ `HEAD`), theo cả hai chiều. Đây là phép so tập của CLAUDE.md (mục *`git for-each-ref` ĐỌC BỘ ĐỆM CỤC BỘ*), mở rộng từ tên sang cặp để bắt thêm nhánh đã đổi đầu. Lệch thì `git fetch origin '+refs/heads/*:refs/remotes/origin/*'` rồi so lại, tới khi hai chiều cùng 0; ghi giờ của lần so cuối. `base_sha` của lease, gọi là B, là `origin/master` sau bước này.
   - **3b — policy change-impact vắng trên master.** `git ls-tree -r -z --name-only origin/master -- .github/coordination` không ra đường dẫn nào chứa chuỗi `change-impact`. Tập ấy chứa hai tệp mà §5 nêu tên, `.github/coordination/change-impact.v1.json` và `.github/coordination/schemas/change-impact.v1.schema.json`. Có ⇒ dừng, re-evaluate theo §5, làm revision đặc tả. B là `origin/master` của 3a, nên phép này đo trên B.
   - **3c — người giữ.** Trên clone ấy, checkout tách rời tại B, chạy `python ops/lease_publish.py ai-dang-giu <đường dẫn> --root .` cho TỪNG đường dẫn của mục 5: dòng cuối `NGƯỜI_GIỮ 0: không có`, rc 0. rc 12 vì một nhánh cục bộ tụt sau hay phân kỳ là kết quả khác: đưa nhánh ấy về khớp `origin` rồi chạy lại từ 3a.
   - **3d — số ADR.** 0 ref `refs/remotes/origin/*` có `docs/adr/0068-*` hay số lớn hơn. Khác 0 thì dừng và làm revision đặc tả.
   - **3e — đo lại ngay sau khi đăng.** Lease của wp1466 vừa đăng (đã có comment và ref) thì làm lại 3a (lease mới nằm trên một nhánh máy chủ mới), làm lại 3b trên `origin/master` mới, rồi chạy 3c cho từng đường dẫn trên checkout tách rời tại `origin/master` mới. Với mỗi đường dẫn, dòng cuối phải là `NGƯỜI_GIỮ 1: <lease_id vừa đăng>`, rc 11. Mọi dòng `CÒN_HẠN` không mang nhãn `ĐÃ_BỊ_THAY_THẾ` phải mang đúng `lease_id` ấy, và ít nhất một dòng trong số đó trỏ ref `refs/remotes/origin/<nhánh vừa đăng>` cùng tệp lease vừa đăng. Kết quả khác ⇒ thu hồi lease vừa đăng theo luật thu hồi hiện hành (bia mộ), không thi công. Bước này chỉ thấy thứ mà ba công cụ ấy thấy lúc chạy lại (G1–G10).

   **Giới hạn của các công cụ ở bước 3.** Các giới hạn này được ghi để người cấp lease biết phép đo của mình không phủ tới đâu; wp1466 không đo, không vá và không hứa gì về chúng. Chúng thuộc nợ `INV-02-TIEN-KIEM-CAP-LEASE-KHONG-CLOSURE` (ADR-0068, mục *Nợ*), giao cho Issue #1484 theo quyết định E2 ở mục 0. Cột "nguồn" nêu nơi giới hạn được đo hay đọc; khối và ca của r5 đến r7 nêu ở đó đã rút ở r8 (mục 18).

   | # | giới hạn | nguồn | bước |
   |---|---|---|---|
   | G1 | `ai-dang-giu` đọc `refs/heads/*` và mọi `refs/remotes/<remote>/*` của clone, không chỉ các ref mà 3a đã so với máy chủ. Một bản ghi chưa công bố ở nhánh cục bộ hay remote phụ dựng được bia mộ hai chiều cho một lease đang giữ tệp trên máy chủ, và 3c ra `NGƯỜI_GIỮ 0` | review lượt 5, F11.d | 3c, 3e |
   | G2 | `ai-dang-giu` chỉ so `write_set`, bằng chuỗi sau khi bỏ `planned:` (hàm `_lease_cham_duong`, đọc trên `4e56f00`). Nó không đọc `effective_write_set`, không chuẩn hoá theo §5 bước 1 đến 4 (gạch ngược, `.` và `..`, NFC, casefold) và không so tiền tố thư mục | review lượt 3 và 4, F11.b/c; kho giả r5: 5 kịch bản lease giao write set (tiền tố hai dạng, khác kiểu chữ, chỉ ở `effective_write_set`, `planned:` cộng gạch ngược) mà `ai-dang-giu` ra `NGƯỜI_GIỮ 0` | 3c, 3e |
   | G3 | không có công cụ tính closure của §5 khi policy tồn tại; 3b chỉ phát hiện policy có mặt trên `origin/master` tại lúc chạy, và không đọc khoảng giữa hai lần chạy | review lượt 3, 6 (F11.e) | 3b, 3e |
   | G4 | `python ops/lease_publish.py` nạp mã từ cây làm việc của clone; cây làm việc bị sửa thì mã quét bị sửa | review lượt 5; kịch bản `lp_cay_lam_viec_bi_sua` (r6) | 3c, 3e |
   | G5 | `ai-dang-giu` không chạy `-I`: `import yaml` và mọi import khác tra `sys.path` (PYTHONPATH, thư mục script, site người dùng, tệp `.pth`); với `-S -X frozen_modules=off`, cả `os` cũng nạp được từ PYTHONPATH | review lượt 6, F11.f; review lượt 7, F11.h | 3c, 3e |
   | G6 | mã quét lease chạy `ls-tree -r` không `-z`, rồi bỏ qua mọi tên không kết thúc bằng `.yaml` hay `.yml`. Một tên lease mà git quote (theo `core.quotePath`) mang dấu nháy ở cuối, nên bị bỏ mà không báo | review lượt 7, F11.i; `_quet_lease_toan_kho`, dòng 749 và 757 trên `4e56f00` | 3c, 3e |
   | G7 | không có phép so-và-đặt nguyên tử cho lease phía máy chủ. Một lease đăng sau lần chạy cuối của 3e thì không bước nào thấy. Cổng I2(Đ) của `record-lease --lease-ref` chỉ chạy trên lease đã đăng | mục 1 r5 đến r7; ADR-0068, mục *Nợ* | 3e |
   | G8 | biến `GIT_*`, cấu hình git hệ thống, toàn cục và của clone, `info/grafts`, replace ref, và chương trình `git` đứng đầu `PATH` đều tới được mọi lời gọi git của bước 3 | đặc tả r7, bảng đầu vào V9 đến V11, P1, P2; kịch bản `v_graft_*`, `g_git_*` | 3a đến 3e |
   | G9 | danh tính lease ở 3e là `lease_id` tự khai trong tệp lease; ref và đường dẫn tệp do người chạy đối chiếu với lease mình vừa đăng, không công cụ nào nối chúng với packet, revision hay `spec_hash` | review lượt 7, F11.g | 3e |
   | G10 | hạn lease đọc theo đồng hồ hệ thống của máy chạy | đặc tả r7, bảng đầu vào P5 | 3c, 3e |

   Một lease cấp sai vì một trong G1 đến G10 là hệ quả của nợ ấy, không phải vi phạm hợp đồng của wp1466. Không tiêu chí nghiệm thu, ca hay đột biến nào của wp1466 đo các giới hạn này. Cách chạy mà S16 đến S18 dùng là clone mới `--reference`, không nhánh cục bộ nào ngoài nhánh mặc định, không remote nào ngoài `origin`, không sửa cây làm việc, và trình thông dịch hệ thống. Đó chỉ là thói quen vận hành: nó không phải phép đo, không được kiểm, và không đổi giới hạn nào ở trên. Trên `4e56f00` lúc 05:41Z, 3a, 3b và 3d cho kết quả phải có, còn 3c ra người giữ `wp1462-r8-g2-claude` cho hai tệp `.py` (S18). Đúng là chưa được cấp lease.
4. Trên base ấy, sáu neo chèn của mục 8.2 mỗi cái xuất hiện đúng 1 lần, và ba dòng mốc của N8 mỗi dòng xuất hiện đúng 1 lần trong tệp của nó: `    proto_words = _doc_nguon_protocol(root)` và `9 bảng ADR §20 lệch với docs/adr/` ở `packet_loop.py`; `protocol if protocol is not None else _PROTO_TRUNG_TINH, encoding=` ở `packet_loop_test.py`. Sai thì dừng, revision.

## 2. `nguon_cap_viec`

Quyết định quản trị của chủ kho `ducthangho` ngày 20-11-2026, ngoài Mission #1172, ghi ở thân Issue #1466. Bằng chứng gốc: audit 23 điểm lệch của phiên điều phối Mission #1172, `ops/specs/wp1172-kiem83/AUDIT_TUAN_THU_PHIEN_DIEU_PHOI_20261120.md` trên nhánh `ops/wp1172-kiem83-thamkhao` tại `a8affd58c0a7db2668f8de8c542edd225ccc2586` (62 dòng). Phần mở rộng cùng ngày (đơn vị bất biến là từng nguyên tắc, có ID `INV-NN`, ô cổng ba giá trị) do phiên điều phối chuyển lời chủ kho cho phiên soạn; chủ kho xác nhận nó khi duyệt băm tệp này. Việc tách ba packet: quyết định E2 nêu ở mục 0.

Trong tệp này, "packet B4" là packet của Mission #1172 ở Issue #1462; "điểm audit B4" là một dòng của audit. Hai thứ khác nhau.

## 3. Số đo nền

Đo trên `origin/master`. "Sáu vị trí" là sáu tệp cổng mà protocol §20 liệt kê, theo thứ tự: `ops/lease_publish.py` · `.claude/dev/packet_loop.py` · `.claude/dev/launcher.py` · `.claude/dev/gate_lifecycle.py` · `.github/workflows/ci.yml` · `.github/workflows/ops-publish-lease.yml`. Mỗi phép đo sáu vị trí là `git show origin/master:<tệp> | grep -cE '<mẫu>'`, đơn vị là dòng. Lượt đo sáu vị trí đầy đủ chạy lúc 19:32:56Z 20-11 trên `48d372e`. 02:58Z: `master` ở `5a152c1` (merge PR #1477 lúc 02:43:46Z; 02:26Z nó còn ở `e02d748`); `git diff --name-only 48d372e origin/master` giới hạn vào sáu tệp cổng, protocol, `docs/adr/`, `packet_loop_test.py`, `packet_loop_test_manh.py`, `ops/ci_duong_nhanh.py` và `.githooks/` cho 0 tệp. Vì vậy các số sáu vị trí và các số đọc từ những tệp ấy giữ nguyên. PR #1477 có đổi `.claude/skills/work-packet/SKILL.md`, một tệp mà `doctrine-scan` quét; S10 đo lại cổng trên `5a152c1`. r6, 04:03:12Z: `master` ở `4e56f00` (merge PR #1482); `git diff --name-only 5a152c1 4e56f00` cho 5 tệp (`.claude/dev/launcher_test.py`, `ops/cai_cong_cu.sh`, một lease, một đặc tả, một verdict), 0 tệp thuộc tập đo ở trên, nên các số S2–S15 giữ nguyên. S16 là phép đo lại của r6. r7, 04:56:46Z: `master` vẫn ở `4e56f00`, nên S2–S15 giữ nguyên; S17 là phép đo lại của r7. r8, 05:41:07Z: `master` vẫn ở `4e56f00`; S18 là phép đo lại của r8. Các ô S1, S4, S16, S17 nhắc khối `tien-kiem` là số đo lịch sử của r5 đến r7; khối đã rút ở r8, và không số đo nào của nó là điều kiện của wp1466.

| # | sự kiện | số đo |
|---|---|---|
| S1 | ref | 03:24:05Z, sau `git fetch origin '+refs/heads/*:refs/remotes/origin/*'`, bằng bước T1 của khối `tien-kiem`: 392 tên nhánh máy chủ, 392 tên cục bộ, cặp (tên, SHA) lệch 0 và 0; kho không shallow; `master` ở `5a152c1`. Trôi đo được ngay trong lượt soạn: 02:26:37Z là 391 nhánh và `master` ở `e02d748`; khối DỪNG vì bộ đệm cũ hai lần, 02:57:15Z (thiếu 5 cặp) và 03:23:57Z (lệch 1 cặp mỗi chiều), fetch lại thì hết |
| S2 | OID dòng khai | 03:05:30Z trên `5a152c1`, ba phép đo của mục *Hiệu lực*: `ADR-0055@d2e3052d…` ⇒ rc 0 · rc 128 · rc 0; `ADR-0053@8ab10079…` ⇒ rc 0 · rc 128 · rc 0 |
| S3 | số ADR | 02:58:33Z trên `5a152c1`: 66 tệp ADR, số cao nhất 0067; 0 trong 392 ref có `docs/adr/0068-*` hay số lớn hơn |
| S4 | lease và tiền kiểm | 03:24:55Z, bằng các hàm quét của `ops/lease_publish.py`: 549 bản ghi lease trên mọi ref; 16 còn hạn; 11 trong số đó có bia mộ hai chiều; 5 còn hiệu lực (`wp433-r9-g4-claude`, `wp1236-a-r10-g1-claude-20261121`, `wp1448-r4-g5-claude`, `wp1462-r8-g2-claude`, `wp1475-r1-g1-claude`); 02:57:49Z là 17 còn hạn và 6 còn hiệu lực, thêm `cai-apt-backoff-r1-g1-claude`. `ai-dang-giu` (03:24Z): tệp ADR 0 · protocol 0 · `packet_loop.py` 1 · `packet_loop_test.py` 1, cùng là `wp1462-r8-g2-claude`, rc 11. Khối `tien-kiem` trên `5a152c1` (03:24:05Z): 392 nhánh, 549 bản ghi, policy 0, liên kết tượng trưng 0, `TIỀN KIỂM: DỪNG` với đúng một lý do là lease ấy |
| S5 | cổng của §8.3 | `bang_lop` 0·7·0·0·0·0; `class_slug` 0×6; `review_verdict` 0×6; `KET_LUAN` 0·2·0·0·0·0 (00:11Z). Đọc mã K4 của `cmd_kiem_merge` (r2): nó chỉ đọc `head`, `trang_thai`, `ma_thoat`, `stdout_sha256` của `run.json` và dòng cuối `KET_LUAN: approve` |
| S6 | biên nhận | 02:58:33Z trên `5a152c1`: 352 tệp `ops/reviews/**/*.receipt.yaml`; 0 tệp có chuỗi `bang_lop` |
| S7 | bộ ca nền | 19:33Z 20-11, tệp test không đổi từ đó: sổ `CASES` có 1582 tên đăng ký (1582 tên khác nhau); 1581 tên áp dụng trên Linux theo `packet_loop_test_manh.ca_dang_ky`, lệch đúng một tên `wp1174_windows_claim_rejected`. Bảng `MUTANTS` 1864 khoá |
| S8 | ai gọi `doctrine-scan` | 02:58:33Z trên `5a152c1`: 4 adapter gọi `doctrine-scan --root .`; `ci.yml` gọi nó 1 lần trên cây thật (bước đường nhanh). Trong `packet_loop_test.py` có 21 chỗ gọi CLI `"doctrine-scan"`, tất cả thuộc **họ ca doctrine cũ**: 132 tên, là mọi ca có tên bắt đầu bằng `doctrine_`, `ac18_`, `ac19_` hoặc có chữ `doctrine` trong nguồn của hàm ca. Bốn tệp khác có 14 dòng nhắc tên lệnh; không dòng nào chạy lệnh trên một cây giả |
| S9 | bộ chọn đối chứng | Đọc 23:57Z 20-11: `_la_ho_doctrine(tên)` là `tên.startswith(("ac18_", "ac19_", "doctrine_"))`; `_doi_chung_khac_ho` trả `DOI_CHUNG_MAY_TRANG_THAI` (ba ca `lease_hop_le_thi_mo_duoc_luot`, `transition_hop_le_rc0`, `cap_lan_4_thoat_3`) khi MỌI ca đích thuộc họ doctrine, trả `DOI_CHUNG_DOCTRINE` khi không ca đích nào thuộc họ ấy. Tên `r1466_*` của r2 rơi vào nhánh thứ hai, nên đối chứng là ba ca doctrine — đúng lỗi review lượt 2 đo được |
| S10 | nguyên mẫu wp1466 r5 (cây git: mục 18) | Cây thử: nền `48d372e`; commit `400dc24` là nguyên mẫu r4 (áp `nguyen-mau-r4/nguyen-mau.patch` bằng `git apply -p1`); commit `c35ee03` là bản vá r5. `git diff --numstat 48d372e c35ee03` (03:13Z): protocol +46 −2; `packet_loop.py` +76 −1; `packet_loop_test.py` +163 −1; ADR 149 dòng; tổng 434 dòng thêm, 4 tệp; patch 532 dòng, sha256 `838bbccba7309c0989fb22b0433b7e33c683677129061bd0a9bef5b203123b55`. Bảng `khoa` tính lại theo định nghĩa byte của r5 bằng một parser độc lập của người soạn (không import `packet_loop`): 7 bộ bốn trùng từng ký tự với bảng của r4. Tệp ADR của cây thử là khối `adr` của tệp này, dòng trạng thái là một dòng giữ chỗ `Proposed (cây thử, chưa duyệt)`, sáu số cưỡng chế đo trên chính cây thử: 0·11·0·0·0·0; so bằng một biểu thức chính quy dựng từ khối `adr`, hai bên khớp từng byte ngoài bảy chỗ trống ấy (03:13Z). 03:13:07Z trên cây thử: `doctrine-scan` rc 0; `adr-song` rc 0 ("67 ADR trên đĩa, 67 dòng"); `git diff --check` sạch. 03:13:26Z, cùng patch áp lên `5a152c1`: áp sạch, `doctrine-scan` rc 0 (quét 12 tệp, gồm `work-packet/SKILL.md` mới đổi), `adr-song` 67/67 rc 0. Hai vòng đột biến chạy trên commit trung gian `ea5baaa`; `git diff ea5baaa c35ee03` chỉ đổi 4 dòng của tệp ADR (câu Q3 về chốt ID và số cưỡng chế), không đổi tệp `.py` nào. Bằng `chay_suite` thật: 190 trên 190 ca đạt (132 ca họ doctrine cũ, 57 ca mới, ca `moc_dot_bien_phai_khop_DUNG_MOT_CHO`), chạy hai lần, 03:03:21Z–03:04:19Z trên `ea5baaa` và 03:21:02Z–03:21:59Z trên `c35ee03`, hai log cùng sha256 `30a427ae30fd78c712027007adf46b7db6d07e4d70f428955ec52db590e17e0a`. 03:04:19Z–03:08:11Z, bằng `packet_loop_test_manh.chay` thật, lượt nền là 57 ca mới cộng 3 ca sẵn có (hai ca của G9 và ca kiểm mốc), pha đột biến là 26 đột biến mới: `nền: 60/60 đạt · BỎ QUA: 0`; 26 trên 26 dòng `ok  <tên> → giết N ca đích · 3 đối chứng khác họ còn sống`; `TỔNG: ĐẠT`; rc 0; log sha256 `227ae2cb3c5465f35e5464f994071924efe4f03f2c857d506511f1e5f6d90a71` |
| S11 | hành vi cũ trên nguyên mẫu r5 | 03:08:11Z–03:11:42Z, bằng `packet_loop_test_manh.chay` thật, lượt nền là 132 ca họ doctrine cũ, pha đột biến là 21 đột biến sẵn có có ca đích trong họ ấy: `nền: 132/132 đạt · BỎ QUA: 0`; 21 trên 21 dòng `ok` kèm "3 đối chứng khác họ còn sống"; `TỔNG: ĐẠT`; rc 0; log sha256 `15a3b35131a30ccb16a3b5d84db04bed1ef6b82df39a06b60534220bd07f5048`. Bằng `chay_suite` thật: 40 trên 40 ca `adr_song_*` đạt, 03:11:42Z–03:11:54Z trên `ea5baaa` và 03:21:59Z–03:22:11Z trên `c35ee03`, hai log cùng sha256 `a88954ddb5514ecad227984ed45b4ab2f0c44fff1b1b3b8b53fa4b090aea37fb`. 03:26:24Z, sổ đăng ký (khối `so-dang-ky`, mục 9, chạy trên `c35ee03`): `CASES` 1582 → 1639, áp dụng trên Linux 1581 → 1638, T có 57 tên đều mang tiền tố `doctrine_inv_`, dãy tên nền là dãy con giữ thứ tự; `MUTANTS` 1864 → 1890, 0 bộ ba cũ đổi; `MUTANTS_NHAM_TEST` nền nằm trong H |
| S12 | đường chạy cổng | 03:05:36Z, REST GET: ruleset `20856202` `active`, sáu check bắt buộc, trong đó `gate-packet-loop (ubuntu-latest)`. `PHU_THUOC_PACKET_LOOP` của `ops/ci_duong_nhanh.py` có `docs/PROTOCOL_DA_PHIEN.md`, `docs/adr/` và tiền tố `.claude/dev/packet_loop` (tệp ấy không nằm trong 4 tệp đã đổi) |
| S13 | hook `pre-push` | 20-11: `run_full_gate`, khối có `tl selftest`, chỉ chạy khi một ref được đẩy là `refs/heads/master`; hook tự ghi là không phải cưỡng chế phía máy chủ |
| S14 | Ruff `F` | 03:13Z, `ruff 0.16.9`, `--select F --no-cache --isolated` (kho không có tệp cấu hình ruff): nền 16 lỗi (`packet_loop.py` 3 F841; `packet_loop_test.py` 8 F401, 3 F811, 2 F541), cây thử 16 lỗi. So theo bộ (mã, thông điệp bỏ phần "from line N", dòng nguồn): mới 0, mất 0. Ba F811 chỉ đổi số dòng trong thông điệp vì có dòng chèn phía trước |
| S15 | phản chứng của review lượt 4 trên r5 | 03:02:18Z–03:03:11Z, trên `ea5baaa` (tệp `.py` trùng `c35ee03`), chạy lại đủ 48 phép của `review/r4-l4/evidence-probes_r4.py` trên cây thử r5, cùng định nghĩa biến thể; byte của từng đơn vị lấy từ parser độc lập của người soạn thay cho `locks.json` của reviewer: 48 trên 48 đúng kỳ vọng, gồm 7 phép CR LF và 2 phép dấu cách cuối từng ra rc 0 ở r4. Cộng 119 phép mới của người soạn: 15 biến thể byte cho mỗi đơn vị (CR lẻ giữa khối, NBSP, tab, CR cuối dòng cuối, U+2028 thay LF, form feed, NUL, U+200B giữa khối, dòng chỉ dấu cách, tab hay CR ngay sau đơn vị, rào mã và comment HTML ngay sau, comment giữa dòng, thêm dòng rỗng sau), che tại chỗ bốn đơn vị khối, bản sao trong rào mã hay comment, BOM, CR LF toàn tệp, năm dạng ID ẩn: 167 trên 167 đúng kỳ vọng; log sha256 `91c91ae3cb4f53486e793b0d6e26d32c4839588e0d7f1054aca4205fe1f4c07f` |
| S16 | đo lại của r6 (`4e56f00`, clone sạch `--reference` từ máy chủ) | 04:06:27Z: so tập tên `git ls-remote --heads origin` với `git for-each-ref refs/remotes/origin` (bỏ `HEAD`), 392 và 392, thiếu 0, thừa 0; kho không shallow. 04:06:59Z: 66 tệp ADR trên `master`; 0 trong 392 ref có `docs/adr/0068-*` hay số lớn hơn. `ai-dang-giu` (04:06Z–04:07Z): `packet_loop.py` 1 · `packet_loop_test.py` 1, cùng là `wp1462-r8-g2-claude`, rc 11; protocol 0 · tệp ADR 0, rc 0. 04:07:39Z, bằng các hàm quét của `ops/lease_publish.py` trên clone ấy: 550 bản ghi lease; 17 còn hạn; 12 trong số đó có bia mộ hai chiều; 5 còn hiệu lực (`wp1236-a-r10-g1-claude-20261121`, `wp1448-r4-g5-claude`, `wp1462-r8-g2-claude`, `wp1475-r1-g1-claude`, `wp433-r9-g5-claude`). Khối `tien-kiem` r6 (04:09:55Z–04:10:01Z): 392 nhánh máy chủ = 392 ref kho tạm, 550 bản ghi, 5 còn hiệu lực, liên kết tượng trưng 0, policy 0, `TIỀN KIỂM: DỪNG` với đúng một lý do là `wp1462-r8-g2-claude`, rc 1. Kho chính `/home/user/tra-luat` không dùng cho phép đo này: nhánh `master` cục bộ của nó tụt sau 29 commit, nên `ai-dang-giu` ở đó ra `CHAN [12]` |
| S17 | đo lại của r7 (`4e56f00`, clone sạch `--reference /home/user/tra-luat` từ máy chủ, tạo 04:46:28Z–04:46:34Z) | 04:56:46Z, sau `fetch --prune`: so tập tên `git ls-remote --heads origin` với `git for-each-ref refs/remotes/origin` (bỏ `HEAD`), 392 và 392, thiếu 0, thừa 0; kho không shallow; `master` ở `4e56f005785db1b04e043bb71fc694a674a8dc9f`. 04:56:47Z: 66 tệp ADR trên `master`; 0 trong 392 ref có `docs/adr/0068-*` hay số lớn hơn. `ai-dang-giu` (04:56:48Z–04:57:17Z): `packet_loop.py` 1 · `packet_loop_test.py` 1, cùng là `wp1462-r8-g2-claude`, rc 11; protocol 0 · tệp ADR 0, rc 0. 04:57:23Z, bằng các hàm quét của `ops/lease_publish.py` trên clone ấy: 551 bản ghi lease; 17 còn hạn; 12 trong số đó có bia mộ hai chiều; 5 còn hiệu lực (`wp1236-a-r10-g1-claude-20261121`, `wp1448-r6-g6-claude`, `wp1462-r8-g2-claude`, `wp1475-r1-g1-claude`, `wp433-r9-g5-claude`). Năm phút trước, 04:52:03Z, là 550 bản ghi, 16 còn hạn, 11 bia mộ, và `wp1448-r4-g5-claude` thay cho `wp1448-r6-g6-claude`. Khối `tien-kiem` r7 bằng `/usr/bin/python3 -I` (04:57:23Z–04:57:29Z): 392 nhánh máy chủ = 392 ref kho tạm, 551 bản ghi, 5 còn hiệu lực, liên kết tượng trưng 0, policy 0+0, 136 module, `TIỀN KIỂM: DỪNG` với đúng một lý do là `wp1462-r8-g2-claude`, rc 1. Cùng khối bằng `/usr/local/bin/python -I` (04:57:29Z): DỪNG `KHÔNG ĐO ĐƯỢC` ở T4, vì PyYAML của trình thông dịch ấy nằm ở `/usr/lib/python3/dist-packages`. Đường dẫn ấy do tệp `apt-dist-packages.pth` thêm vào và không thuộc `site.getsitepackages()` của trình thông dịch đó. Kho chính `/home/user/tra-luat` chỉ làm nguồn object cho `--reference`; không ref nào của nó bị đổi |
| S18 | đo lại của r8 (`4e56f00`, clone sạch `--reference /home/user/tra-luat` từ máy chủ, tạo 05:40:59Z–05:41:04Z; log `r8/do/do_that_r8.log`) | Theo đúng điều kiện bắt đầu của r8. 3a, 05:41:07Z, sau `fetch --prune`: tập tên 394 và 394, thiếu 0, thừa 0; tập cặp (tên, SHA) thiếu 0, thừa 0; kho không shallow; `master` ở `4e56f005785db1b04e043bb71fc694a674a8dc9f`. 3b, 05:41:08Z: 0 đường dẫn chứa `change-impact` dưới `.github/coordination` trên `master`. 3d, 05:41:08Z: 66 tệp ADR trên `master`; 0 trong 394 ref có `docs/adr/0068-*` hay số lớn hơn. 3c (05:41:09Z–05:41:44Z, `/usr/bin/python3`, checkout tách rời tại `master`): `packet_loop.py` và `packet_loop_test.py` đều `NGƯỜI_GIỮ 1: wp1462-r8-g2-claude`, rc 11, lease ở `refs/remotes/origin/ops/wp1462-r1:ops/leases/wp1462-r8-g2-claude.yaml`; protocol và tệp ADR `NGƯỜI_GIỮ 0: không có`, rc 0. Đối chứng, không phải điều kiện (05:41:51Z, các hàm quét của `ops/lease_publish.py` trên clone ấy): 551 bản ghi lease; 17 còn hạn; 12 trong số đó có bia mộ hai chiều; 5 còn hiệu lực (`wp1236-a-r10-g1-claude-20261121`, `wp1448-r6-g6-claude`, `wp1462-r8-g2-claude`, `wp1475-r1-g1-claude`, `wp433-r9-g5-claude`). Lease B4 `wp1462-r8-g2-claude` vẫn chặn wp1466. Kho chính chỉ làm nguồn object cho `--reference`; không ref nào của nó bị đổi |

**Đọc lại từng ô dạng cổng** (lớp `cong-khong-do-bat-bien`). Từ r3, ô nào cũng mang ít nhất một `còn nợ`; bảng này nêu nợ ấy là gì. K0, K1, K4 đến K7, `_kiem_lop_review`, `cmd_doctrine_scan`, bước EOL của `ci.yml` và hook `pre-push` được đọc ở lượt r2; các cổng còn lại được đọc ở lượt r1 và được hai lượt review đọc lại độc lập.

| INV | mẫu: sáu vị trí | cổng ĐỌC gì | `còn nợ` |
|---|---|---|---|
| `INV-01` | `ai-dang-giu\|ai_dang_giu\|RC_DANG_GIU`: 11·5·0·0·0·0 | `record-lease --lease-ref` từ chối khi một lease khác còn giữ | chỉ chạy khi phiên dùng state máy: `CONG-TREN-DUONG-STATE-KHONG-BAT-BUOC` |
| `INV-02` | như trên | cùng cổng, phần giao write set theo tiền tố | vế branch và worktree riêng của §1 (2): `INV-02-NHANH-WORKTREE-RIENG`; tiền kiểm trước khi cấp: `INV-02-TIEN-KIEM-CAP-LEASE-KHONG-CLOSURE` (Issue #1484); và nợ đường state |
| `INV-04` | `refs/pull/`: 0·1·1·0·0·0 | K0: base là tổ tiên của H và của `origin/master`; head hiện hành của PR bằng H | uỷ quyền land; deploy: `INV-04-UY-QUYEN-LAND-VA-DEPLOY` |
| `INV-05` | `eol\|EOL\|gitattributes`: 0·0·0·0·24·0 | bước `eol-policy survey` chạy `eol_policy.py --all --json` trên index của ứng viên | chưa có khoảng hở cụ thể nào được đo: `INV-DO-PHU-CA-CHUA-REVIEW-RIENG` |
| `INV-06` | `RC_PROVIDER`: 0·9·0·0·0·0 | `init` từ chối khi executor và reviewer cùng provider | ID phiên, đổi vai, K4 không so reviewer với executor: `INV-06-PHIEN-VA-VAI` |
| `INV-07` | `reviewed_sha\|reviewing_head_sha`: 4·49·0·0·0·0 | K0 (head PR) và K4 (`head` của `run.json`) | `INV-DO-PHU-CA-CHUA-REVIEW-RIENG` |
| `INV-08` | `spec_hash\|spec_sha256`: 0·28·0·0·0·0 | K1 so băm đặc tả tại H với băm lease khai | `INV-DO-PHU-CA-CHUA-REVIEW-RIENG` (việc mở revision mới không được đo riêng) |
| `INV-11` | `model_family\|ho_model`: 15·33·0·0·0·0 | chốt của `ops/bien_nhan_v2.py` từ chối `cross_approved` cùng họ model trên biên nhận | `INV-11-K4-KHONG-DOC-HO-MODEL` |
| `INV-13` | `effective_review_class\|_kiem_lop_review\|RC_LOP`: 15·0·0·0·0·0 | `_kiem_lop_review` tính lớp từ write set và từ chối lớp thấp hơn | `INV-13-LEASE-SCHEMA-CU` |
| `INV-14` | `chup-workspace\|chup_workspace\|ghi_workspace`: 0·0·21·0·0·0 | `run --chup-workspace` so ảnh đầu và cuối của workspace | `INV-14-CHUP-WORKSPACE-TUY-CHON` |
| `INV-15` | `MOC_10_2_2\|moc_10_2_2`: 0·3·0·0·0·0 | D2 đòi bốn nhãn mốc đều thuộc tập đạt | `INV-15-D2-DOC-NHAN-KHONG-DOC-NGUON` |
| `INV-16` | `codex_review_calls\|RC_TRAN`: 0·34·0·0·0·0 | `record-codex-call` chặn khi chạm trần lời gọi đã ghi trong state | `INV-16-BO-DEM-NGOAI-TRUC-LOI-GOI` |
| `INV-19` | `NGUOI_CO_THAM_QUYEN\|RC_TU_CAP`: 13·15·0·0·0·1 | cổng đăng lease so TÊN ở `granted_by` với danh sách cho phép: chỉ vế cấp lease của §1 (4) | `INV-19-TEN-KHAI-KHONG-PHAI-DANH-TINH`; vế chuyển state và merge: `INV-22-AUTHORITY-CHUYEN-STATE` |
| `INV-20` | `doctrine`: 1·27·5·0·5·1 | `doctrine-scan` bắt cụm cấm và chuỗi chép nguyên văn từ 10 từ liền | diễn đạt lại khác chữ: `INV-20-CHI-DO-CHEP-NGUYEN-VAN` |
| `INV-21` | `mien_p3`: 0·3·0·0·0·0 | K3 đọc finding của connector; K5 đòi dòng miễn P3 phủ đúng tập | finding của review offline: `INV-12-CONG-VERDICT-THEO-LOP` |

Mười hai dòng kỷ luật và một dòng chưa đo, mẫu và số (20-11): `INV-03` `\bLIVE\b` 0×6 · `INV-09` `changed_paths` 0×6 · `INV-10` `tested_sha` 0×6 · `INV-12` `bang_lop` 0·7·0·0·0·0 · `INV-17` `ADR-0067|uy_quyen_quyet_dinh` 0×6 · `INV-18` `Drive MCP|Sheets MCP` 0×6 · `INV-22` `integration` 0·1·0·0·0·0 · `INV-23` `label|assignee|board` 1·2·8·6·1·0 (đã đọc 3 dòng ở hai tệp đầu, cả 3 là chú thích; 15 dòng ở ba tệp sau chưa đọc từng dòng) · `INV-24` `diff --check` 0·0·0·0·1·0 và S13 · `INV-25` `push_them|so_lan_push|M5` 0·5·3·0·0·0 (5 dòng của `packet_loop.py` đã đọc, không dòng nào đếm push) · `INV-26` 0 cổng theo việc đọc K0 đến K7 · `INV-27` `writer_slot|hai writer|max_writers|executor_writers` 0·0·1·0·0·0 (dòng duy nhất là một chú thích) · `INV-28` `numstat` 0×6.

## 4. `review_class`

`sensitive`. Diff chạm `docs/PROTOCOL_DA_PHIEN.md` và một tệp cổng của `gate-packet-loop`; ADR đổi luật về thế nào là một lượt review hợp lệ.

## 5. `write_set`

PR giao nộp, đúng bốn tệp:

1. `docs/adr/0068-bat-bien-protocol-va-review-theo-lop.md` (tệp mới)
2. `docs/PROTOCOL_DA_PHIEN.md`
3. `.claude/dev/packet_loop.py`
4. `.claude/dev/packet_loop_test.py`

Trên nhánh sổ sách, không thuộc PR giao nộp: `ops/specs/wp1466.md`, hồ sơ dưới `ops/specs/wp1466/` và tệp lease của packet. Cần tệp thứ năm thì dừng và làm revision đặc tả.

## 6. `ngoai_pham_vi`

- Mọi việc của #1469 và #1470 (mục 0). Đặc tả này không đặt tiêu chí nghiệm thu nào cho hai packet ấy.
- Trong `packet_loop.py`, phần sẵn có chỉ đổi ở đúng hai chỗ: một khối chèn trong `cmd_doctrine_scan` và dòng epilog. `_che_khong_render`, `_doc_nguon_protocol`, `_la_ho_doctrine`, `_doi_chung_khac_ho` được DÙNG, không sửa. Phép đo ở N8.
- Trong `packet_loop_test.py`, phần sẵn có chỉ đổi ở đúng một dòng: giá trị mặc định của `_repo_gia`.
- `ops/ci_duong_nhanh.py`, `.github/workflows/ci.yml`, `CLAUDE.md`, `CONTEXT.md`, `.claude/skills/**`, `.agents/skills/**`: không sửa.
- Cổng mới cho mọi bất biến đang 0 cổng hay còn nợ: ngoài #1469 và #1470, chưa packet nào được giao (mục 14).
- Không đổi `VERSION`, không deploy, không đụng `scripts/tl.py`.

## 7. `muc_tieu`

| # | mục tiêu | tệp |
|---|---|---|
| M1 | ADR-0068 ghi ba quyết định Q1 đến Q3, bảng chuyển tiếp, mục *Cưỡng chế* đo trên sáu vị trí, mục *Nợ* có 28 tên | `docs/adr/0068-bat-bien-protocol-va-review-theo-lop.md` |
| M2 | Protocol: hai bất biến mới ở §1; bảng §1.1 có 28 dòng `INV-01` đến `INV-28`; §8.3 khai là bất biến `INV-12`; §12 buộc ghi mục sổ `xet_lai_cach_lam`; §20 có dòng `ADR-0068` | `docs/PROTOCOL_DA_PHIEN.md` |
| M3 | `doctrine-scan` đỏ (rc 9) khi một trong 7 đơn vị khoá không ở đúng địa chỉ, có dòng bị che tại địa chỉ, không có đúng một bản hiển thị đứng thành đơn vị cùng loại, hay lệch băm trên byte thô; khi một ID bất biến, so trên dạng hiển thị của dòng, đứng trên một dòng bảng ngoài tiểu mục §1.1; và khi không đo được; nó vẫn trả rc 6 cho việc chép doctrine | `.claude/dev/packet_loop.py` |
| M4 | Mỗi chốt của M3 có ca hai chiều và đột biến mà vòng đột biến thật xếp là giết; fixture mặc định của họ ca doctrine mang các đơn vị khoá, và không ca hay đột biến sẵn có nào đổi kết quả | `.claude/dev/packet_loop_test.py` |

## 8. Hợp đồng thay đổi

### 8.1 M1 — tệp ADR

Tệp ADR bằng đúng từng byte khối `adr` dưới đây, trừ hai loại chỗ trống:

- `{{TRANG_THAI}}` thay bằng đúng một dòng dạng ``- **Trạng thái:** Accepted (<YYYY-MM-DD>, chủ kho `ducthangho` duyệt `spec_hash` `<64 hex>` của đặc tả `wp1466` r<N> trên Issue #1466: <URL>)``. Ngày là ngày UTC của comment duyệt băm; `<64 hex>` là sha256 của chính tệp đặc tả được duyệt; `<N>` là số ở dòng `revision:` của tệp ấy; `<URL>` là URL comment duyệt băm.
- `{{N1}}` đến `{{N6}}`: số dòng khớp, đo trên commit ứng viên H bằng đúng lệnh in ở mục *Cưỡng chế* của ADR. Mã đổi sau khi điền thì đo lại.

~~~ adr
# ADR-0068 — Bất biến protocol có ID và ô cổng; review theo lớp là bất biến cho mọi lượt review

{{TRANG_THAI}}

## Bối cảnh

Audit ngày 20-11-2026 trên phiên điều phối Mission #1172 ghi 23 điểm lệch protocol. Gốc chung theo audit: phiên đọc
protocol lần đầu lúc 17:17Z và không nạp adapter nào, trong khi các nghĩa vụ review chỉ sống bằng kỷ luật đọc. Đo cùng
ngày trên `origin/master` `48d372e14f190dae83a75ccbca8ee9a0b25635c5`:

- §8.3 tự ghi các nghĩa vụ bảng lớp là *kỷ luật review*. `bang_lop` có 7 dòng trong `.claude/dev/packet_loop.py`, không
  dòng nào thuộc điều kiện K4 của `kiem-merge`, đường mặc định theo `ADR-0062`; K4 chỉ đọc dòng `KET_LUAN`. `class_slug`
  có 0 dòng trên cả sáu vị trí cổng của §20; 0 trong 352 biên nhận `ops/reviews/**/*.receipt.yaml` có khoá `bang_lop`.
- Review đặc tả và review kế hoạch không đi qua `kiem-merge`; không vị trí cổng nào tiêu thụ verdict của chúng.
- Bảng §20 định tuyến theo ADR, không theo nguyên tắc: một nguyên tắc của §1 không có chỗ nào khai cổng máy đọc nó.

Ngày 20-11-2026 chủ kho quyết: những nguyên tắc quan trọng nhất của protocol phải thành bất biến có ID, mỗi bất biến
khai cổng của nó, bắt đầu từ §8.3.

## Quyết định

**Q1 — Review theo lớp là bất biến `INV-12`, áp cho mọi lượt review: mã, đặc tả và kế hoạch.** Luật chi tiết ở protocol
§8, §8.3 và §12; ADR này đổi phạm vi và mức ràng buộc của chúng, không chép chúng:

1. mỗi finding mang đúng một `class_slug` ổn định qua các lượt;
2. reviewer khái quát mỗi biểu hiện thành lớp và quét mọi biểu hiện cùng lớp trên candidate trước khi báo;
3. lượt nào cũng có bảng lớp, kể cả lượt approve;
4. từ lượt hai, verdict đối chiếu TỪNG finding của lượt liền trước bằng đúng bốn nhãn của §8, rồi mới kết luận theo lớp;
5. bản vá đi theo lớp; vá riêng từng biểu hiện chỉ khi verdict ghi lý do cơ chế;
6. tín hiệu hội tụ |F|/|U| của §12 tính theo lớp; revision hay cắt phạm vi không reset lịch sử lớp;
7. một lớp xuất hiện ở ba lượt review khác nhau là checkpoint do phiên đang giữ việc tự quyết: phiên dừng vá, xét lại
   cách làm và ghi một mục sổ `uy_quyen_quyet_dinh.v1` với `loai: xet_lai_cach_lam` theo `ADR-0067`. Đây không phải điểm
   hỏi chủ kho; phiên chỉ hỏi khi rơi vào E1 hay E3 của `ADR-0067`.

**Q2 — Mỗi bất biến của protocol có một ID và khai cổng của nó.** Protocol §1.1 giữ bảng bất biến: mỗi dòng có ID ổn định
`INV-NN`, một câu phát biểu, mục nguồn và ô cổng mang đúng một trong ba giá trị: cổng máy kèm ca phản chứng; nhãn *kỷ
luật, 0 cổng* kèm một nợ có tên; hoặc *chưa đo*. Bảng ấy là chỗ ở duy nhất của danh sách; ADR này không chép nó. Một bất
biến chỉ được ghi *có cổng* khi cổng ấy đọc đúng điều bất biến nói. Chưa cổng nào được chứng minh là đọc trọn bất biến
của nó, nên ô dạng cổng LUÔN mang ít nhất một `còn nợ: <TÊN-NỢ>`; bỏ một `còn nợ` là sửa bảng. Mọi nợ được trỏ là một mục
của mục *Nợ* dưới đây.

**Q3 — Cổng canh luật.** `packet_loop.py doctrine-scan` canh bảy ĐƠN VỊ KHOÁ của protocol: trọn tiểu mục §1.1 (cả bảng),
khối danh sách bất biến của §1, trọn tiểu mục §8.3, đoạn *đối chiếu lượt trước* của §8, và ba đoạn về hội tụ theo lớp
của §12. Mỗi đơn vị có một ĐỊA CHỈ: đường tiêu đề đầy đủ của mục chứa nó và thứ tự của nó trong mục ấy. Cổng đọc BYTE
THÔ của tệp; biên của mục và của khối chỉ là dòng rỗng, tức dòng không có byte nào. Cổng đỏ khi mục ấy không có đúng một
lần, khi đơn vị ở địa chỉ ấy lệch băm byte ghi trong mã hay có dòng nằm trong vùng không render, và khi còn một bản hiển
thị khác mang cùng những byte ấy đứng thành đơn vị cùng loại (trọn mục, hay khối). Bản sao không đứng thành đơn vị cùng
loại không bị đếm (nợ `INV-KHOA-BAN-SAO-DINH-CHU`). Cổng không chọn câu đại diện và không nhận dạng viết tương đương: đổi, thêm hay bớt một
byte trong khoảng dòng của một đơn vị là đỏ. Nó cũng đỏ khi một ID bất biến, so trên dạng hiển thị của dòng, đứng trên
một dòng bảng ngoài tiểu mục §1.1. Sửa một đơn vị khoá vì thế luôn đi qua một packet có review sửa mã cổng. Không đọc
được nguồn, hay nguồn có vùng mà cổng không phân tích được, là không đo được, và làm cổng đỏ.

## Hiệu lực và chuyển tiếp

ADR này có hiệu lực từ commit land của nó trên first-parent master và không hồi tố: lượt review bắt đầu trước mốc ấy không
bị xét lại. Cơ chế cần cổng mã chỉ có hiệu lực từ commit land của packet đổi cổng; trước đó nó là kỷ luật.

| cơ chế | cổng | hiệu lực |
|---|---|---|
| Q1, luật review theo lớp cho mọi lượt review | chưa có, kỷ luật | từ land ADR này |
| Q2 và Q3, bảng bất biến và các đơn vị khoá | `packet_loop.py doctrine-scan` | từ land ADR này (cùng packet) |
| đối chiếu ngữ nghĩa ô cổng: tệp cổng, ca và nợ được trỏ còn tồn tại | chưa có | từ land packet đổi cổng (Issue #1469) |
| verdict máy đọc theo lớp cho review mã, đặc tả và kế hoạch | chưa có | từ land packet đổi cổng (Issue #1470); packet ấy định hình dạng bản ghi và vị từ chuyển tiếp |

Bộ kiểm tạm `kiem_verdict_lop.py` của phiên điều phối Mission #1172 không phải cổng của kho. Từ land ADR này nó phải
dùng đúng bốn nhãn của §8, đúng chữ.

## Cưỡng chế

Đo trên commit ứng viên của packet thi hành, một dòng cho từng vị trí cổng mà §20 của protocol liệt kê, bằng
`git show <H>:<tệp> | grep -cE 'ADR-0068|INV_|_inv_'`:

- `ops/lease_publish.py`: {{N1}} dòng.
- `.claude/dev/packet_loop.py`: {{N2}} dòng.
- `.claude/dev/launcher.py`: {{N3}} dòng.
- `.claude/dev/gate_lifecycle.py`: {{N4}} dòng.
- `.github/workflows/ci.yml`: {{N5}} dòng.
- `.github/workflows/ops-publish-lease.yml`: {{N6}} dòng.

Cổng nằm trong `doctrine-scan`. Bộ ca của nó ở `.claude/dev/packet_loop_test.py`, tức trong check bắt buộc
`gate-packet-loop`, và có ca chạy trên cây thật. Ngoài cổng ấy, lúc land ADR này là kỷ luật executor và reviewer.

## Nợ

- `CONG-TREN-DUONG-STATE-KHONG-BAT-BUOC`: `record-lease`, `init`, `record-codex-call` chỉ chạy khi phiên dùng state máy;
  `kiem-merge`, đường mặc định theo `ADR-0062`, không đọc state.
- `INV-02-NHANH-WORKTREE-RIENG`: I2(Đ) đọc giao write set; không cổng nào đòi mỗi lần chạy có branch và worktree riêng.
- `INV-02-TIEN-KIEM-CAP-LEASE-KHONG-CLOSURE`: trước khi cấp lease chỉ có `ai-dang-giu`, so chuỗi đường dẫn bằng nhau; I2(Đ)
  chỉ chạy trên lease ĐÃ đăng; kho chưa có phép tính closure nào của §5.
- `INV-04-UY-QUYEN-LAND-VA-DEPLOY`: K0 chỉ đọc quan hệ tổ tiên của base và head hiện hành của PR; không đọc uỷ quyền land,
  không kiểm deploy.
- `INV-06-PHIEN-VA-VAI`: `init` chỉ so nhãn provider của executor và reviewer; không đọc ID phiên, không chặn một phiên
  đổi vai; K4 không so danh tính reviewer với executor.
- `INV-09-DIFF-NGOAI-WRITE-SET`: không vị trí cổng nào so diff của ứng viên với effective write set.
- `INV-10-HANDOFF-KHONG-CO-CONG`: không vị trí cổng nào đọc handoff hay `tested_sha`.
- `INV-11-K4-KHONG-DOC-HO-MODEL`: chốt tách họ model đọc biên nhận trong `ops/reviews/`; K4 không đọc họ model hay mức
  assurance của lượt review.
- `INV-12-CONG-VERDICT-THEO-LOP`: chưa cổng nào đọc bảng lớp hay bảng đối chiếu của verdict; K3 và K5 chỉ đọc finding
  của connector và danh sách P3 do người gọi đưa vào. Giao cho Issue #1470.
- `INV-13-LEASE-SCHEMA-CU`: `_kiem_lop_review` chỉ cảnh báo với lease `schema_version` nhỏ hơn 2.
- `INV-14-CHUP-WORKSPACE-TUY-CHON`: cờ `--chup-workspace` là tuỳ chọn; ảnh chụp đầu cuối không thấy thao tác ghi rồi
  hoàn nguyên.
- `INV-15-D2-DOC-NHAN-KHONG-DOC-NGUON`: D2 đọc bốn nhãn của `moc_10_2_2`; không xác minh nguồn provenance của từng mốc.
- `INV-16-BO-DEM-NGOAI-TRUC-LOI-GOI`: `record-codex-call` chỉ đếm lời gọi được ghi vào state; không gì đọc dòng khai
  trần của đặc tả, và không ca nào đo việc đổi phiên hay thư mục state.
- `INV-17-DANH-SACH-DONG-0-CONG`: không cổng nào đọc mã E hay sổ `uy_quyen_quyet_dinh.v1` (`ADR-0067` tự ghi 0 cổng).
- `INV-18-DUONG-GHI-REGISTRY-0-CONG`: luật ở `CLAUDE.md`, ngoài sáu vị trí cổng; không cổng nào canh.
- `INV-19-TEN-KHAI-KHONG-PHAI-DANH-TINH`: cổng so TÊN ghi ở `granted_by` với danh sách cho phép; phiên agent chạy bằng
  credential của chủ kho nên tên khai không chứng minh ai quyết (`ADR-0067`, mục *Giới hạn*).
- `INV-20-CHI-DO-CHEP-NGUYEN-VAN`: `doctrine-scan` bắt cụm cấm và chuỗi chép nguyên văn từ 10 từ liền; diễn đạt lại khác
  chữ thì không thấy (protocol §8.3 giữ nợ `phep-do-doctrine-khong-du-rang`).
- `INV-22-AUTHORITY-CHUYEN-STATE`: `kiem-merge` chỉ nhận dòng miễn từ comment của chủ kho; ngoài chỗ ấy không cổng nào
  buộc một bước chuyển state dựa trên durable fact, và reconciler của §3.3 chưa có.
- `INV-23-NGUON-SU-THAT`: không cổng nào từ chối một quyết định chỉ có trong chat, label, assignee hay board.
- `INV-24-CONG-TAI-CHO-TRUOC-PUSH`: hook `pre-push` chỉ chạy selftest cho lần đẩy vào `refs/heads/master`, ở clone đã bật
  `core.hooksPath`; lần đẩy ứng viên lên nhánh packet không qua cổng tại chỗ nào, và CI chạy sau khi đã đẩy.
- `INV-25-PUSH-THEM`: K0 đến K7 không đếm số lần push và không phân biệt bản vá CI với bản vá finding.
- `INV-26-NHANH-SO-SACH`: không cổng nào phân loại nhánh sổ sách với nhánh có tệp thuộc write set code.
- `INV-27-HAI-WRITER`: không cổng nào đếm số Executor writer đang chạy.
- `INV-28-TRAN-KICH-THUOC`: `ADR-0044` và `ADR-0053` tự ghi 0 cổng; không gì đọc `git diff --numstat` hay khối `nang_tran`.
- `INV-BANG-DOI-CHIEU-NGU-NGHIA`: băm bảng không cho biết tệp cổng, ca hay nợ mà một ô trỏ tới còn tồn tại; đổi tên một
  ca ở tệp khác không làm cổng đỏ. Giao cho Issue #1469.
- `INV-KHOA-BAN-SAO-DINH-CHU`: phép đếm bản sao của `doctrine-scan` chỉ thấy bản sao đứng thành trọn mục hay trọn khối; bản sao nguyên
  byte dính chữ trên hay dưới, cách bằng dòng chỉ có khoảng trắng, trọn mục kèm đoạn nối, hay thẻ HTML giữa dòng, không
  bị đếm. Giao cho Issue #1469.
- `INV-DO-PHU-CA-CHUA-REVIEW-RIENG`: với ô chỉ mang nợ này, chưa có khoảng hở cụ thể nào được đo; nhưng ca phản chứng được
  trỏ mới được chứng minh là CÓ MẶT, chưa được review riêng là đo đủ mọi vế của bất biến.
- `COT-CONG-20-CHUA-CO-CONG`: ô cổng của bảng §20 (theo ADR) chưa được máy kiểm; nhóm B của §20 không có cột cổng.

## Giới hạn

- Băm chứng minh một đơn vị khoá không đổi kể từ lần sửa có review gần nhất; nó không chứng minh một ca đo đúng bất biến.
- Cổng không chặn một câu ở NGOÀI các đơn vị khoá nói ngược một câu ở trong; phần còn lại của §7, §8 và §12 không bị khoá.
- Địa chỉ dùng thứ tự khối: thêm hay bớt một đoạn ĐỨNG TRƯỚC một đơn vị khoá trong cùng mục cũng làm cổng đỏ, và
  phải sửa địa chỉ trong mã cổng ở cùng PR.
- Số dòng rỗng không thuộc đơn vị nào: thêm hay bớt một dòng rỗng giữa hai khối, hay ở cuối một mục, không đổi đơn vị
  nào và không đổi thứ tự khối, nên cổng xanh. Một dòng chỉ có dấu cách, tab hay CR không phải dòng rỗng.
- Cột *nguồn* và phần *chốt* của ô cổng là chữ; máy không đối chiếu chúng với mục hay hàm được nêu.
- `INV-03` ở *chưa đo*: ruleset `20856202` của kho buộc nhánh mặc định đi qua PR và các check bắt buộc (đo 20-11-2026),
  nhưng không có ca phản chứng trong kho, và phiên agent chạy bằng credential của chủ kho.

## Phương án bị loại

- Một lệnh riêng cho các đơn vị khoá, không nối vào `doctrine-scan`: `doctrine-scan --root .` là lệnh mà bốn adapter và bước
  đường nhanh của `ci.yml` gọi; đo trên cây thử, xoá trọn §8.3 thì nó vẫn trả `sạch`.
- Tìm đơn vị theo băm ở bất kỳ đâu trong tệp: dời một đơn vị khỏi mục của nó, hay nhân đôi nó, vẫn qua.
- Chuẩn hoá khoảng trắng trước khi băm: một khối thụt bằng tab thành khối mã mà băm không đổi.
- Đọc tệp qua lớp văn bản rồi cắt khoảng trắng cuối mục: lớp ấy đổi CR LF thành LF và bỏ dấu cách cuối dòng, nên bảy
  biến thể CR LF và hai biến thể dấu cách cuối qua được cổng (review đặc tả lượt 4).
- Chọn một số câu làm neo: hai lượt review đặc tả liên tiếp đều tìm ra câu luật bị sót; khoá trọn đơn vị thì không còn
  phép chọn nào để sót.
- Liệt kê ID trong mã thay cho băm cả bảng: sửa hay để trống một ô mà giữ ID thì không đỏ.
- Một packet cho cả luật, băm bảng, đối chiếu ngữ nghĩa ô cổng và cổng verdict: vượt trần kích thước của `ADR-0053`.
~~~

### 8.2 M2 — sáu khối sửa `docs/PROTOCOL_DA_PHIEN.md`

Mỗi neo chèn dưới đây xuất hiện đúng 1 lần trên nền (đo 01:08Z khi áp các khối; đo lại 03:05:30Z trên `5a152c1`: sáu neo, mỗi neo 1 lần). Ngoài sáu khối, không dòng nào của protocol đổi: `git diff --numstat` của tệp là +46 −2 (S10). Revision 5 không đổi khối nào của mục này.

**P1** — §1, chèn ngay SAU dòng `    workflow trigger và prompt chỉ là worker/client có thể thay thế, không tự cấp quyền hoặc tự nối chuỗi vai trò.` (dòng cuối của bất biến 10), không dòng trống ở giữa:

~~~ p1-moi
11. Mọi lượt review — mã, đặc tả và kế hoạch — theo §8.3: mỗi finding một `class_slug`, mỗi lượt một bảng lớp kể cả
    lượt approve, từ lượt hai đối chiếu từng finding của lượt trước bằng bốn nhãn của §8 (`ADR-0068`).
12. Mỗi bất biến của protocol có ID ổn định ở bảng §1.1 và khai cổng máy đọc nó; bất biến chưa có cổng mang nhãn kỷ
    luật kèm một nợ có tên (`ADR-0068`).
~~~

**P2** — chèn ngay TRƯỚC dòng `## 2. Thành phần và quyền`: khối dưới đây, rồi một dòng trống.

~~~ p2-moi
### 1.1 Bảng bất biến protocol

Mỗi dòng là một bất biến có ID ổn định. Dòng lấy nguồn từ §1 chép NGUYÊN VĂN mục ấy; dòng khác mang một tên gọi ngắn, và cột `nguồn` mới là nơi có đủ từng vế. Ô `cổng` mang đúng một trong ba dạng: `cổng: <tệp> <chốt> · ca: <tệp ca>::<tên ca> · còn nợ: <TÊN-NỢ>` (có cổng máy và ca phản chứng; lặp lại được ` · ca: …` và ` · còn nợ: …`; ô dạng này LUÔN mang ít nhất một `còn nợ`, vì chưa cổng nào được chứng minh là đọc trọn bất biến của nó) · `kỷ luật, 0 cổng · nợ: <TÊN-NỢ>` (chỉ sống bằng kỷ luật đọc) · `chưa đo`. Con trỏ ca `<tệp ca>::<tên ca>` viết KHÔNG có backtick: `doc-claims-check` (lớp L12, bước bắt buộc của CI) đọc mọi chuỗi dạng `r<số>_…` hay `wp<số>_…` trong backtick là tên ca selftest của `scripts/tl.py`, nên tên ca của tệp khác bị báo là không tồn tại. Mọi nợ được trỏ là một mục của mục *Nợ* trong `ADR-0068`. Tiểu mục này bị khoá theo băm byte ghi trong mã cổng: `python .claude/dev/packet_loop.py doctrine-scan --root .` đỏ khi nó lệch băm ấy, khi nó không còn ở đúng chỗ này, hay khi có bản thứ hai; nên thêm, bỏ hay sửa một dòng luôn đi qua một packet có review sửa băm (`ADR-0068`).

| INV | bất biến | nguồn | cổng |
|---|---|---|---|
| `INV-01` | Mỗi work packet có đúng một executor ghi và một lease generation còn hiệu lực. | §1 (1) | cổng: `.claude/dev/packet_loop.py` `record-lease --lease-ref` I2(Đ) · ca: .claude/dev/packet_loop_test.py::r812_nguoi_giu_khac · còn nợ: `CONG-TREN-DUONG-STATE-KHONG-BAT-BUOC` |
| `INV-02` | Mỗi lần chạy có branch/worktree riêng; không có hai lease với effective write set giao nhau trên toàn repo. | §1 (2) | cổng: `.claude/dev/packet_loop.py` `record-lease --lease-ref` I2(Đ) · ca: .claude/dev/packet_loop_test.py::r812_nguoi_giu_prefix_giao_nhau · còn nợ: `INV-02-NHANH-WORKTREE-RIENG` · còn nợ: `INV-02-TIEN-KIEM-CAP-LEASE-KHONG-CLOSURE` · còn nợ: `CONG-TREN-DUONG-STATE-KHONG-BAT-BUOC` |
| `INV-03` | Worker không ghi canonical, không bump version, không deploy và không có credential LIVE. | §1 (3) | chưa đo |
| `INV-04` | Canonical chỉ đổi qua operation `land apply` được người có thẩm quyền gọi cho đúng mission/head SHA; mọi skill, comment hoặc workflow chỉ là client. Deploy là cổng riêng. | §1 (5) | cổng: `.claude/dev/packet_loop.py` `kiem-merge` K0 · ca: .claude/dev/packet_loop_test.py::cong_c_k0_pr_head · còn nợ: `INV-04-UY-QUYEN-LAND-VA-DEPLOY` |
| `INV-05` | Mọi text tracked dùng LF, trừ `*.cmd`/`*.bat` dùng CRLF; binary/golden byte fixture không normalize. | §1 (6) | cổng: `.github/workflows/ci.yml` bước `eol-policy survey` · ca: .githooks/eol_policy_test.py::case_khong_chi_so_voi_head · còn nợ: `INV-DO-PHU-CA-CHUA-REVIEW-RIENG` |
| `INV-06` | Một phiên chỉ giữ một vai trò trên một đơn vị công việc: execute một Packet, review một PR hoặc land một exact head. Substep nằm trong cùng Packet Spec không bị tách vụn; việc ngoài spec sang successor Packet. | §1 (8) | cổng: `.claude/dev/packet_loop.py` `init` · ca: .claude/dev/packet_loop_test.py::init_cung_provider_thoat_4 · còn nợ: `INV-06-PHIEN-VA-VAI` |
| `INV-07` | Review, CI, authorization và land evidence đều gắn exact SHA. Head đổi làm bằng chứng và ủy quyền cũ hết hiệu lực. | §1 (9) | cổng: `.claude/dev/packet_loop.py` `kiem-merge` K0 và K4 · ca: .claude/dev/packet_loop_test.py::cong_c_k0_pr_head · ca: .claude/dev/packet_loop_test.py::cong_c_k4_head · còn nợ: `INV-DO-PHU-CA-CHUA-REVIEW-RIENG` |
| `INV-08` | Packet Spec đóng băng bằng `spec_hash`; đổi hợp đồng thì revision mới | §3.2 | cổng: `.claude/dev/packet_loop.py` `kiem-merge` K1 · ca: .claude/dev/packet_loop_test.py::cong_c_k1_hash · còn nợ: `INV-DO-PHU-CA-CHUA-REVIEW-RIENG` |
| `INV-09` | Diff ngoài effective write set bị từ chối | §5 | kỷ luật, 0 cổng · nợ: `INV-09-DIFF-NGOAI-WRITE-SET` |
| `INV-10` | Handoff mang bằng chứng dương và `tested_sha` bằng head đưa ra review | §7 | kỷ luật, 0 cổng · nợ: `INV-10-HANDOFF-KHONG-CO-CONG` |
| `INV-11` | Assurance tính theo họ model thực sự phục vụ; class `sensitive` cần `cross_approved` hoặc `human_audited` | §8 | cổng: `ops/bien_nhan_v2.py` chốt tách họ model · ca: ops/bien_nhan_v2_test.py::c49_cross_approved_cung_ho_model_phai_bi_tu_choi · còn nợ: `INV-11-K4-KHONG-DOC-HO-MODEL` |
| `INV-12` | Mọi lượt review (mã, đặc tả, kế hoạch) xuất verdict theo lớp: mỗi finding một `class_slug`, bảng lớp, đối chiếu lượt trước bằng bốn nhãn | §7, §8, §8.3, §12 | kỷ luật, 0 cổng · nợ: `INV-12-CONG-VERDICT-THEO-LOP` |
| `INV-13` | Review Class tính fail-closed; executor không hạ lớp | §8 | cổng: `ops/lease_publish.py` `_kiem_lop_review` · ca: ops/lease_publish_test.py::t74_A1_A2_executor_khong_duoc_ha_lop_va_ve_dung_phai_QUA · còn nợ: `INV-13-LEASE-SCHEMA-CU` |
| `INV-14` | Reviewer chỉ đọc: không ghi vào nhánh packet hay checkout được giao | §8, §8.2 | cổng: `.claude/dev/launcher.py` `run --chup-workspace` · ca: .claude/dev/launcher_test.py::r1252_ghi_trong_git · còn nợ: `INV-14-CHUP-WORKSPACE-TUY-CHON` |
| `INV-15` | `landed` đòi đủ bốn mốc provenance của §10.2.2 | §10.2.2 | cổng: `.claude/dev/packet_loop.py` `kiem-dong-wp` D2 · ca: .claude/dev/packet_loop_test.py::cong_c_d2_not_measured · còn nợ: `INV-15-D2-DOC-NHAN-KHONG-DOC-NGUON` |
| `INV-16` | Trần lời gọi Codex, vòng review và attempt là stop condition; đổi prompt hay phiên không reset bộ đếm | §12 | cổng: `.claude/dev/packet_loop.py` `record-codex-call` · ca: .claude/dev/packet_loop_test.py::pl_m3_codex · còn nợ: `INV-16-BO-DEM-NGOAI-TRUC-LOI-GOI` |
| `INV-17` | Agent chỉ hỏi chủ kho theo danh sách đóng E1–E5 | §12 | kỷ luật, 0 cổng · nợ: `INV-17-DANH-SACH-DONG-0-CONG` |
| `INV-18` | Registry chỉ ghi qua GAS webapp; không thêm đường ghi thứ ba | `CLAUDE.md` | kỷ luật, 0 cổng · nợ: `INV-18-DUONG-GHI-REGISTRY-0-CONG` |
| `INV-19` | Dispatcher tuần tự là bên duy nhất chuyển state/cấp lease/merge vào mission integration branch. | §1 (4) | cổng: `ops/lease_publish.py` chốt `granted_by` · ca: ops/lease_publish_test.py::t02b_ten_KHONG_CO_THAM_QUYEN_bi_CHAN · ca: .claude/dev/packet_loop_test.py::tu_cap_lease_bang_ten_provider_bi_chan · còn nợ: `INV-19-TEN-KHAI-KHONG-PHAI-DANH-TINH` · còn nợ: `INV-22-AUTHORITY-CHUYEN-STATE` |
| `INV-20` | Adapter và `CLAUDE.md` chỉ trỏ protocol, không chép doctrine | §13 | cổng: `.claude/dev/packet_loop.py` `doctrine-scan` · ca: .claude/dev/packet_loop_test.py::doctrine_scan_chep_tron_5_1_bi_chan · còn nợ: `INV-20-CHI-DO-CHEP-NGUYEN-VAN` |
| `INV-21` | Finding P0, P1, P2 còn mở chặn merge; P3 phải đóng có bằng chứng hoặc được miễn neo SHA | §8 | cổng: `.claude/dev/packet_loop.py` `kiem-merge` K3 và K5 · ca: .claude/dev/packet_loop_test.py::cong_c_k3_p1 · ca: .claude/dev/packet_loop_test.py::cong_c_k5_p3_khong_mien · còn nợ: `INV-12-CONG-VERDICT-THEO-LOP` |
| `INV-22` | GitHub durable facts và deterministic reconciler single-writer là authority cho transition; model, adapter, workflow trigger và prompt chỉ là worker/client có thể thay thế, không tự cấp quyền hoặc tự nối chuỗi vai trò. | §1 (10) | kỷ luật, 0 cổng · nợ: `INV-22-AUTHORITY-CHUYEN-STATE` |
| `INV-23` | Chat history, label, assignee và board không phải nguồn sự thật. | §1 (7) | kỷ luật, 0 cổng · nợ: `INV-23-NGUON-SU-THAT` |
| `INV-24` | Bất biến (a) — cổng tại chỗ trước push chính | §12 (a) | kỷ luật, 0 cổng · nợ: `INV-24-CONG-TAI-CHO-TRUOC-PUSH` |
| `INV-25` | Bất biến (b) — push thêm vì CI đỏ | §12 (b) | kỷ luật, 0 cổng · nợ: `INV-25-PUSH-THEM` |
| `INV-26` | Bất biến (c) — nhánh sổ sách | §12 (c) | kỷ luật, 0 cổng · nợ: `INV-26-NHANH-SO-SACH` |
| `INV-27` | Trong rollout Thin Orchestration, tối đa hai Executor writer chạy đồng thời và chỉ khi effective write set không giao. | §8 | kỷ luật, 0 cổng · nợ: `INV-27-HAI-WRITER` |
| `INV-28` | Packet vượt trần kích thước dừng trước review; nâng trần cần khối `nang_tran` kèm số đo | §20 (`ADR-0044`, `ADR-0053`) | kỷ luật, 0 cổng · nợ: `INV-28-TRAN-KICH-THUOC` |
~~~

**P3** — §8.3, chèn ngay SAU dòng tiêu đề `### 8.3 Lịch sử lớp finding và giới hạn nghiệm thu` và dòng trống liền sau nó: khối dưới đây, rồi một dòng trống.

~~~ p3-moi
Mục này là bất biến `INV-12` và áp cho mọi lượt review: mã, đặc tả và kế hoạch (`ADR-0068`).
~~~

**P4** — §8.3, thay hai dòng `p4-cu` bằng ba dòng `p4-moi`:

~~~ p4-cu
không tự tạo approval, không miễn exact-SHA audit/gate. Các nghĩa vụ bảng lớp/đọc nghĩa
ở đây là kỷ luật review; scanner xanh không chứng minh chúng đã được máy cưỡng chế.
~~~

~~~ p4-moi
không tự tạo approval, không miễn exact-SHA audit/gate. Các nghĩa vụ bảng lớp/đọc nghĩa
ở đây là bất biến `INV-12`; cổng máy đọc chúng ghi ở ô cổng của dòng ấy trong bảng §1.1, và
chừng nào ô ấy còn nhãn kỷ luật thì scanner xanh không chứng minh chúng đã được máy cưỡng chế.
~~~

**P5** — §12, thay một dòng `p5-cu` bằng hai dòng `p5-moi`:

~~~ p5-cu
tiếp hay handoff. Phiên chỉ hỏi chủ kho khi rơi vào E1 hay E3 của `ADR-0067`.
~~~

~~~ p5-moi
tiếp hay handoff. Phiên chỉ hỏi chủ kho khi rơi vào E1 hay E3 của `ADR-0067`. Mỗi lần xét lại cách làm ghi một mục sổ
`xet_lai_cach_lam` theo `ADR-0067`; luật này áp cả cho review đặc tả và review kế hoạch (`ADR-0068`).
~~~

**P6** — §20, bảng nhóm A, chèn một dòng ngay SAU dòng bắt đầu bằng ``| `ADR-0067` | ``:

~~~ p6-moi
| `ADR-0068` | Bất biến protocol có ID và ô cổng ở bảng §1.1; review theo lớp (§8.3) là bất biến cho mọi lượt review: mã, đặc tả, kế hoạch | Accepted — đối chiếu ngữ nghĩa ô cổng và cổng verdict theo lớp có hiệu lực khi packet đổi cổng land (bảng chuyển tiếp trong ADR) | `packet_loop.py` `doctrine-scan` (bảy đơn vị khoá của §1, §1.1, §8, §8.3, §12: đúng địa chỉ, duy nhất, đúng băm byte); đối chiếu ngữ nghĩa ô cổng và verdict theo lớp: **0 cổng** lúc land, nợ `INV-BANG-DOI-CHIEU-NGU-NGHIA` và `INV-12-CONG-VERDICT-THEO-LOP` |
~~~

Bảng §1.1 có 28 dòng: 15 ô dạng cổng, cả 15 mang `còn nợ`; 12 ô kỷ luật; 1 ô chưa đo; 18 chỗ trỏ ca; 25 tên nợ khác nhau, cả 25 là mục của `## Nợ` trong khối `adr` (đếm bằng script lúc ráp tệp này). Mười dòng lấy nguồn từ §1 (1) đến (10) chép nguyên văn mục ấy: script ráp lấy chữ thẳng từ blob protocol, và so lại bằng nhau từng mục.

### 8.3 M3 — cổng toàn vẹn trong `doctrine-scan`

`cmd_doctrine_scan` gọi một hàm mới, `_inv_kiem_protocol(root)`, ngay SAU dòng `proto_words = _doc_nguon_protocol(root)`: nguồn đã qua chốt fail-close sẵn có (thiếu, không phải UTF-8, quá ngắn ⇒ rc 2 như cũ), và phép kiểm mới chạy TRƯỚC khi quét adapter. Hàm trả danh sách lỗi. Khác rỗng thì mỗi lỗi một dòng stderr bắt đầu bằng `doctrine-scan: `, rồi `_die(RC_ADR, …)`: rc 9. rc 6 giữ nguyên nghĩa (chép doctrine). Khối chèn có đúng AST của hằng `CHEN` trong khối `do-pham-vi` (mục 9), trừ giá trị các hằng chuỗi: lời nhắn được đổi, còn cấu trúc và tên biến thì không.

**Hai bản của cùng một tệp, cùng chỉ số dòng.** Cổng đọc tệp MỘT lần, bằng `read_bytes`. *Bản thô* là các dòng byte tách tại byte `0x0A`, không bớt byte nào: CR, dấu cách hay tab cuối dòng, NBSP, U+2028 hay ký tự định dạng vô hình đều ở lại trong dòng của chúng. *Bản che* là kết quả `_che_khong_render` (gọi, không sửa) trên phép giải mã UTF-8 chặt của chính các byte ấy, tách tại ký tự xuống dòng; hàm ấy giữ độ dài và số dòng, nên dòng thứ i của hai bản là cùng một dòng, và số dòng của hai bản khác nhau thì không đo được. Trên đường từ tệp tới băm không có `read_text`, `splitlines`, `strip` hay `rstrip` nào.

- **Dòng rỗng**: dòng thô không có byte nào. Dòng chỉ có dấu cách, tab hay CR là dòng CÓ nội dung.
- **Dòng hiển thị**: dòng mà bản che bằng đúng bản thô, tức không byte nào của nó nằm trong rào mã hay comment HTML.
- **Mục**: một dòng tiêu đề (dòng của bản che mở bằng `#`) cùng mọi dòng sau nó cho tới dòng tiêu đề kế tiếp, bỏ các dòng rỗng ở cuối.
- **Đường tiêu đề** của một mục: các dòng tiêu đề cấp cao hơn đang mở, theo thứ tự, rồi tới dòng tiêu đề của chính mục, lấy ở bản thô, nối bằng byte `0x0A`. "Cấp" là số dấu `#` đứng đầu dòng.
- **Khối** của một mục: mỗi dãy dòng không rỗng liền nhau trong thân mục (không kể dòng tiêu đề). Khối đánh số từ 1 theo thứ tự.
- **Phần đầu tệp** (thêm ở r9): các dòng đứng trước dòng tiêu đề đầu tiên. Chúng không thuộc mục nào, nhưng khối của chúng (dãy dòng không rỗng liền nhau, như trên) được phép (3) đếm. Đường tiêu đề của phần này là chuỗi rỗng, nên không địa chỉ nào trỏ tới nó và phép (1), (2) không đổi. Thiếu luật này thì bản sao nguyên byte của một đơn vị dạng khối đặt trên đầu tệp không bị đếm (đo trên nguyên mẫu: rc 0), trái với hệ quả "nhân đôi nó thành một đơn vị cùng loại ở chỗ hiển thị bất kỳ thì hỏng phép (3)". Ca: `doctrine_inv_nhan_doi_K04_truoc_tieu_de_dau`, `doctrine_inv_nhan_doi_K02_sat_tieu_de_dau`, `doctrine_inv_chu_la_truoc_tieu_de_dau_van_xanh`; đột biến: `inv_bo_dem_truoc_tieu_de_dau`, `inv_truoc_tieu_de_chi_khoi_dau`, `inv_truoc_tieu_de_bo_bien_tieu_de`. Ba ca và ba đột biến ấy không cộng vào tập bắt buộc (57 ca, 26 đột biến), nhưng nằm trong T của N6, và N7 đòi MỌI đột biến có ở H mà không có trên nền đều giết ca đích; nên chúng được đo mà các số của N6, N7 không đổi.

**Địa chỉ của một đơn vị khoá**: sha256 của đường tiêu đề của mục chứa nó, cộng một số thứ tự. Thứ tự 0 là TRỌN mục; thứ tự n ≥ 1 là khối thứ n của mục. Băm của đơn vị là sha256 của các dòng thô của nó nối bằng byte `0x0A`: mọi byte trong khoảng dòng ấy, không bớt byte nào.

**Ba phép kiểm cho MỖI đơn vị, theo thứ tự:** (1) đường tiêu đề ấy có ĐÚNG MỘT mục trong protocol; (2) đơn vị ở đúng thứ tự ấy tồn tại, đúng băm, và mọi dòng của nó là dòng hiển thị; (3) trong cả protocol, số đơn vị cùng loại (trọn mục, hoặc khối) mang băm ấy mà mọi dòng là dòng hiển thị bằng ĐÚNG MỘT. Hệ quả theo cấu trúc, không theo ca: xoá, đổi hay thêm một byte bất kỳ TRONG khoảng dòng của đơn vị (kể cả CR trước LF; dấu cách, tab, CR hay NBSP cuối dòng cuối mục; U+2028 thay một LF; form feed giữa khối), ngắt dòng lại, thụt bằng tab hay bằng dấu cách, tách một bảng bằng dòng rỗng đều đổi băm; dời đơn vị sang mục khác hay sang thứ tự khác thì hỏng phép (1) hoặc (2); che nó TẠI CHỖ bằng một comment HTML mở ở khối trước và đóng ở khối sau thì hỏng phép (2) dù băm giữ nguyên; nhân đôi nó thành một đơn vị cùng loại (trọn mục, hay khối) ở chỗ hiển thị bất kỳ thì hỏng phép (3). Giới hạn, khai thẳng từ r10: bản sao nguyên byte KHÔNG đứng thành đơn vị cùng loại (dính chữ trên hay dưới trong cùng khối, cách bằng một dòng chỉ có khoảng trắng, trọn mục kèm một đoạn nối, thẻ HTML giữa dòng) không bị đếm, nên cổng xanh với nó; đó là nợ `INV-KHOA-BAN-SAO-DINH-CHU`, giao cho Issue #1469 theo quyết định chủ kho. Không ca nào của wp1466 được đòi đỏ ở các dạng ấy. Phép (2) và cách đếm chỉ-hiển-thị của phép (3) phải đi cùng nhau, vì băm nay trên byte thô nên phép che không còn tự làm lệch băm như ở r4: thiếu vế hiển thị của phép (2) thì che đơn vị tại chỗ rồi đặt một bản hiển thị ở cuối tệp vẫn xanh (ca `doctrine_inv_che_K04_ban_hien_noi_khac`, đột biến `inv_bo_hien_o_dia_chi`).

**Dạng tương đương duy nhất mà cổng nhận, khai thẳng: SỐ dòng rỗng.** Một hay nhiều dòng rỗng giữa hai khối là cùng một biên; dòng rỗng ở cuối mục, và ở đầu thân mục khi đơn vị là khối, không thuộc đơn vị nào. Thêm hay bớt một dòng rỗng ở các chỗ ấy không đổi đơn vị nào và không đổi thứ tự khối, nên cổng xanh (ca `doctrine_inv_them_dong_rong_giua_khoi_van_xanh`). Biến một dòng rỗng thành dòng có byte (dấu cách, tab, CR) thì không còn tương đương: hai khối nhập làm một, hay đơn vị dài thêm một dòng, và cổng đỏ (`doctrine_inv_dong_cr_giua_hai_khoi`, `doctrine_inv_dong_khoang_trang_sau_khoi`).

**Hằng mới trong mã**: `INV_KHOA_PROTOCOL`, 7 bộ bốn (nhãn, băm đường tiêu đề, thứ tự, băm đơn vị) lấy từ bốn cột đầu của khối `khoa`, đúng thứ tự, `K01` đứng đầu. Mã chỉ giữ BĂM, không chép chữ của luật. Cột thứ năm chỉ để người đọc định vị; reviewer tự băm lại từ blob protocol theo định nghĩa trên. Bảng không đổi so với r4, trừ băm đơn vị của `K01` đổi ở r9 vì bảng §1.1 bỏ backtick quanh con trỏ ca (mục 0, đoạn *Revision 9*): trên protocol nền cộng sáu khối của mục 8.2, định nghĩa byte của r5 cho đúng bảy bộ bốn ấy (S10, đo bằng một parser độc lập của người soạn), vì bảy đơn vị không có CR, không có dòng chỉ khoảng trắng, không có dòng bị che, và dòng cuối của `K01`, `K03` không có khoảng trắng cuối.

~~~ khoa
K01 | b1bf0e6593f0ee411de10da15913f372e31eae598f0667f5a0b614ceb84b8274 | 0 | 987f952747e26847a5a8e39dd82bf09da72d508dd3e03cef3bfdd42db4e381c5 | ### 1.1 Bảng bất biến protocol
K02 | 378875000caedbfb13ee65bb8c5eae1786e3905b7deaf58b14350200595ccfa7 | 3 | e67103c29f0a0fea824a4089291008044aad3ed9e8bc93b8fbaa5fa0398dad0a | ## 1. Mục tiêu và bất biến
K03 | 919d5bc058fbba64ee8f10647c2b201de7f7aec4b78db5b24e8b694ce1d01d83 | 0 | 22716893ace46188ae892ee1f58ac2acad8bdd731dbaaeeafed9bc9f2d5b71df | ### 8.3 Lịch sử lớp finding và giới hạn nghiệm thu
K04 | 1ffd90f8e0a0a65de259727b151c9629b38fa20bf1e6fc00266eb81addeb7206 | 12 | 6faf0af7b34cd8e8a5b4033a3efbd6c5b8a003d68e624e5e9290b4b289a1ee73 | ## 8. Review phân tầng
K05 | a269e3af7b2d36a8183d16c912c5ddbcfae33e923d3b2d45cbd888b59b362b70 | 8 | 31820977356049aac3c810dbf26933fd93ee491e9f3bfda0ad875a81289776b9 | ## 12. Stop conditions và budget
K06 | a269e3af7b2d36a8183d16c912c5ddbcfae33e923d3b2d45cbd888b59b362b70 | 9 | 8e35ce2dc3bb5cac3dbd9855d35bc80a558b47bce8cafaaeff3de9a9ba0a9f51 | ## 12. Stop conditions và budget
K07 | a269e3af7b2d36a8183d16c912c5ddbcfae33e923d3b2d45cbd888b59b362b70 | 10 | 3188510c14bb84bb6cc4a881e2bd190e01bc863f55a869b12adcfb884f9671ef | ## 12. Stop conditions và budget
~~~

**Chốt ID bất biến.** Một "ID bất biến trần" là chuỗi khớp `INV-[0-9]{2}(?![0-9A-Za-z-])`. Phép so làm trên DẠNG HIỂN THỊ của dòng: bản che của dòng, chuẩn hoá NFKC, rồi bỏ mọi ký tự thuộc lớp Unicode `Cf`. Ngoài khoảng dòng của mục `K01`, không dòng nào mà dạng hiển thị vừa chứa ký tự `|` vừa chứa một ID bất biến trần. Luật không phụ thuộc cách viết hàng: có hay không dấu `|` đầu dòng, dấu cách, backtick; chữ số hay gạch đứng toàn khoảng; dấu cách độ rộng 0 hay gạch mềm chen vào giữa ID. Tên nợ như `INV-12-CONG-VERDICT-THEO-LOP` không phải ID trần, nên dòng `ADR-0068` của §20 hợp lệ. Giới hạn, khai thẳng: chữ cùng hình thuộc hệ chữ khác (chữ I Kirin thay chữ I Latin) không bị NFKC gộp, nên chốt không bắt dạng ấy; chuỗi ấy cũng không phải ID theo định nghĩa trên.

**Không đo được**, mỗi trường hợp là một lỗi mang chuỗi `KHÔNG ĐO ĐƯỢC`, rc 9: (a) đích resolve của `<root>/docs/PROTOCOL_DA_PHIEN.md` không nằm dưới `<root>` đã resolve; (b) không đọc được tệp ở lần đọc này, hay byte của nó không giải mã được bằng UTF-8 chặt; (c) `_che_khong_render` báo rào hay comment hỏng; (d) sau khi che, còn một dòng mở bằng `<` sau tối đa ba dấu cách (cổng không phân tích khối HTML; nền có 1 dòng như vậy, là một comment mà phép che đã xoá); (e) bản che và bản thô có số dòng khác nhau. Điều kiện (e) không dựng được bằng một tệp, vì hàm che sẵn có giữ số dòng; nó là chốt phòng khi hàm ấy đổi, nên không có ca riêng.

**Vùng khoá** (giữ nguyên từ r3; lớp `neo-thieu-nghia-vu` đã được review lượt 3 xếp ĐÃ VÁ THẬT). Cổng không chọn câu: nó khoá trọn những đơn vị mang luật của `INV-12` và của bảng.

| đơn vị | địa chỉ | chứa |
|---|---|---|
| `K01` | trọn mục `### 1.1 Bảng bất biến protocol` dưới `## 1.` | tiêu đề, đoạn dẫn, cả bảng 28 dòng |
| `K02` | khối 3 của `## 1. Mục tiêu và bất biến` | 12 bất biến đánh số, gồm (11) và (12) |
| `K03` | trọn mục `### 8.3 …` dưới `## 8.` | MỌI đoạn của §8.3 và bảng hồ sơ kế thừa #523 |
| `K04` | khối 12 của `## 8. Review phân tầng` | mục *ĐỐI CHIẾU LƯỢT TRƯỚC*: từng finding, bốn nhãn đúng chữ |
| `K05` | khối 8 của `## 12. Stop conditions và budget` | *Tín hiệu không hội tụ theo lớp*: U, F, tỷ lệ, dừng sau hai chuyển tiếp dưới 50% |
| `K06` | khối 9 của cùng mục | lớp mới, lớp tái mở; lớp lặp ba lượt; revision không reset |
| `K07` | khối 10 của cùng mục | đoạn *Checkpoint*: phiên tự quyết, mục sổ, chỉ hỏi khi E1 hay E3 |

**Giá của thiết kế, chấp nhận có chủ ý và ghi ở mục *Giới hạn* của ADR:** sửa biên tập một byte trong vùng khoá là đỏ; thêm hay bớt một đoạn đứng TRƯỚC `K04` trong phần đầu §8, hay trước `K05` trong phần đầu §12, làm lệch thứ tự và cũng đỏ; cả hai phải sửa hằng trong cùng PR. Ngoài bảy đơn vị, cổng không khoá gì: phần còn lại của §7, §8, §12 có thể đổi, và một câu ở ngoài nói ngược một câu ở trong không làm đỏ. Một bản sao của một đơn vị nằm trọn TRONG vùng không render (rào mã, comment HTML) không tính là bản thứ hai, vì phép (3) chỉ đếm đơn vị hiển thị (ca `doctrine_inv_ban_sao_trong_rao_ma_van_xanh`; từ r5 bản sao ấy đứng thành một khối riêng trong rào, để phép đếm phải thật sự bỏ nó qua, không lọt nhờ dính liền dòng rào). Vì khối tính trên bản thô, chèn một rào mã hay một comment HTML thành khối riêng ĐỨNG TRƯỚC một đơn vị khối trong cùng mục nay cũng làm lệch thứ tự và đỏ; ở r4 hai dạng ấy bị che thành dòng trắng nên không làm lệch.

**Chín chốt.** "KĐĐ" là trạng thái không đo được. Cột cuối là kết quả của VÒNG ĐỘT BIẾN THẬT trên nguyên mẫu (S10): số ca đích bị giết; mỗi dòng đều kèm "3 đối chứng khác họ còn sống". Đột biến và ca mới của r5 ghi lý do ở mục 19.

| chốt | luật | ca đỏ (rc 9 + lý do riêng) | ca xanh | ca KĐĐ | đột biến → số ca đích bị giết |
|---|---|---|---|---|---|
| G1 | nguồn nằm dưới gốc | — | `doctrine_inv_lien_ket_noi_bo_van_xanh` | `doctrine_inv_lien_ket_ra_ngoai` | `inv_bo_kiem_duoi_goc` → 1 |
| G2 | chỉ đọc vùng render: dòng tiêu đề và dòng hiển thị lấy từ bản che | — | `doctrine_inv_ban_sao_trong_rao_ma_van_xanh` | `doctrine_inv_rao_khong_dong` | `inv_bo_che_khong_render` → 2 |
| G3 | không phân tích khối HTML | — | — | `doctrine_inv_dong_html` | `inv_bo_chan_html` → 1 |
| G4 | đường tiêu đề có đúng một mục | `doctrine_inv_hai_tieu_muc_1_1` · `doctrine_inv_doi_cho_K01_sang_phu_luc` | — | — | `inv_bo_kiem_mot_muc` → 1 |
| G5 | đúng địa chỉ, và hiển thị tại đó | `doctrine_inv_doi_cho_K04` · `doctrine_inv_che_K04_ban_hien_noi_khac` | — | — | `inv_bo_dia_chi` → 1 · `inv_bo_hien_o_dia_chi` → 1 |
| G6 | đúng băm trên byte thô; chỉ dòng rỗng là biên | 7 ca `doctrine_inv_xoa_K01` … `_K07` · 7 ca `doctrine_inv_crlf_K01` … `_K07` · 7 ca `doctrine_inv_cach_cuoi_K01` … `_K07` · `doctrine_inv_xoa_cau_cat_scope` · `doctrine_inv_xoa_cau_bang_noi_slug` · `doctrine_inv_xoa_cau_hai_chuyen_tiep` · `doctrine_inv_doi_mot_ky_tu` · `doctrine_inv_ngat_dong_lai` · `doctrine_inv_khoi_thut_tab` · `doctrine_inv_khoi_trong_rao_ma` · `doctrine_inv_bang_tach_dong_trong` · `doctrine_inv_bang_them_khoang_trang` · `doctrine_inv_u2028_thay_xuong_dong` · `doctrine_inv_ff_giua_khoi` · `doctrine_inv_tab_cuoi_muc` · `doctrine_inv_nbsp_cuoi_muc` · `doctrine_inv_cr_cuoi_muc` · `doctrine_inv_dong_khoang_trang_sau_khoi` · `doctrine_inv_dong_cr_giua_hai_khoi` | `doctrine_inv_sua_ngoai_don_vi_van_xanh` · `doctrine_inv_them_dong_rong_giua_khoi_van_xanh` | — | `inv_bo_khoa_K01` … `inv_bo_khoa_K07` → 8 · 4 · 6 · 4 · 9 · 4 · 3 · `inv_doc_qua_text` → 9 · `inv_tach_dong_splitlines` → 8 · `inv_cat_cuoi_muc` → 5 · `inv_dong_trang_la_khoang_trang` → 2 · `inv_khoi_rong_tinh_la_khoi` → 1 |
| G7 | đúng một bản hiển thị | `doctrine_inv_nhan_doi_K04` | (bốn ca xanh ở trên) | — | `inv_bo_kiem_duy_nhat` → 1 · `inv_duy_nhat_lech_so` → 5 · `inv_dem_ban_ca_vung_che` → 1 |
| G8 | ID bất biến, so trên dạng hiển thị, không đứng trên dòng bảng ngoài §1.1 | `doctrine_inv_dong_inv_ngoai_dang_chuan` · `doctrine_inv_dong_inv_ngoai_khong_backtick` · `doctrine_inv_dong_inv_ngoai_khong_gach_dau` · `doctrine_inv_dong_inv_ngoai_ky_tu_vo_hinh` · `doctrine_inv_dong_inv_ngoai_gach_mem` · `doctrine_inv_dong_inv_ngoai_so_toan_khoang` | — | — | `inv_bo_kiem_id_ngoai` → 6 · `inv_id_chi_dang_chuan` → 2 · `inv_id_khong_chuan_hoa` → 3 · từ r10: thêm ca G8 cho ID thật (`INV-01`…`INV-28`) và các biên `00`, `01`, `09`, `10`, `28`, `98`, cùng một đột biến thu hẹp miền số của `_INV_ID_TRAN` về đúng `99` phải bị giết bởi các ca mới ấy (lớp P3 `ca-id-chi-do-mot-gia-tri`) |
| G9 | nối vào `doctrine-scan`: rc 9 riêng, rc 6 giữ nghĩa; fixture mặc định mang đơn vị khoá đúng địa chỉ | `doctrine_inv_fixture_trung_tinh_thuan` · `doctrine_inv_chep_doctrine_van_rc_6` (đòi rc 6 và lý do `chép doctrine`) | ca sẵn có `doctrine_scan_repo_that_sach`, `doctrine_scan_sach_xanh` | — | `inv_doctrine_scan_bo_goi` → 52 · `t1466_fixture_ve_trung_tinh` (đặt trong tệp test) → 2 |

**Tập bắt buộc**, đơn vị là tên: 57 ca `doctrine_inv_*` (49 ca đỏ rc 9, 1 ca đòi rc 6, 3 ca KĐĐ, 4 ca xanh) và 26 đột biến (25 trong `packet_loop.py`, 1 trong tệp test). 31 ca và 18 đột biến là của r4; r5 thêm 26 ca và 8 đột biến. Cả 57 ca bị ít nhất một đột biến giết (S10). Executor ĐƯỢC thêm ca và đột biến; không được bớt hay đổi tên một tên của tập bắt buộc. Mọi ca thêm phải mang tiền tố `doctrine_inv_`, và mọi ca đích của một đột biến mới phải thuộc họ doctrine theo `_la_ho_doctrine`. Không sửa `_la_ho_doctrine` hay `_doi_chung_khac_ho`.

Chỗ sửa trong `packet_loop.py`, đúng ba: (1) một cụm nút mới mức module đứng NGAY TRƯỚC `cmd_doctrine_scan`: hằng `INV_KHOA_PROTOCOL`, `_INV_ID_TRAN` và các hàm `_inv_*`; (2) khối chèn trong `cmd_doctrine_scan` như mô tả ở đầu mục; (3) đổi một hằng chuỗi của epilog: `9 bảng ADR §20 lệch với docs/adr/` thành `9 bảng ADR §20 hoặc bất biến protocol lệch`.

### 8.4 M4 — fixture mặc định và họ ca `doctrine_inv_*`

- **Fixture mặc định.** `_repo_gia(…, protocol=None)` ghi `_proto_co_khoa()` thay cho `_PROTO_TRUNG_TINH`. Hàm mới ấy trả nguồn trung tính cũ, rồi dựng lại ĐÚNG ĐỊA CHỈ của bảy đơn vị: các dòng tiêu đề của đường tiêu đề, khối đệm cho mọi thứ tự đứng trước, và byte của đơn vị THẬT ở đúng thứ tự của nó. Nó dựng từ hằng và từ `_inv_muc` của module chuẩn (`CANONICAL`), trên byte thô của protocol thật, không từ bản đột biến đang được thử. Đổi giá trị mặc định ấy là biểu thức sẵn có DUY NHẤT của tệp test bị sửa.
- **Fixture của họ ca mới.** Bản sao protocol THẬT trong thư mục tạm của ca, đọc và ghi bằng BYTE (`read_bytes`, `write_bytes`), không qua lớp văn bản, để CR, NBSP hay U+2028 mà ca chèn vào tới tệp đích nguyên vẹn; mỗi ca đổi đúng MỘT yếu tố rồi chạy CLI `doctrine-scan --root <tạm>`. Ca nào đổi mà văn bản không đổi thì tự đỏ.
- **Ký tự lạ viết bằng chuỗi thoát ASCII.** Trong mã nguồn tệp test, ký tự lạ của fixture (CR, form feed, U+2028, NBSP, U+200B, U+00AD, chữ số toàn khoảng) viết bằng chuỗi thoát, không viết ký tự thật. Đo: số ký tự thuộc lớp Cc trừ LF, Cf, Zl, Zp, và Zs khác dấu cách, của mỗi tệp `.py` tại H bằng ở nền. Nguyên mẫu (03:14:12Z): `packet_loop.py` 0 và 0; `packet_loop_test.py` cùng 7 ký tự sẵn có ở nền, không thêm ký tự nào. Bẫy đã đo trong lượt soạn này: lần ghi đầu của hai ca mới đi qua lớp JSON của công cụ, và chuỗi thoát U+2028, NBSP bị giải mã thành ký tự thật trong mã nguồn; phép đo trên bắt được, và hai dòng ấy được ghi lại.
- **Nút mới theo ngữ pháp N8.** `_PROTO_CO_KHOA = []` không chú thích kiểu; `_INV_ID_TRAN` là hằng chuỗi, `re.search` dùng nó; mọi phép gán mới mang giá trị hằng, bộ, danh sách hay từ điển của hằng, hay lambda mà mọi giá trị mặc định là hằng; đăng ký vào sổ chỉ bằng `CASES += …`, `MUTANTS.update(…)` và `MUTANTS_NHAM_TEST |= …`.
- **Đòi mã lẫn lý do, bằng hàm sẵn có `_doi_ly_do`.** Lý do riêng: `đơn vị khoá K<nhãn> ` cho ca của một đơn vị; `nằm ngoài tiểu mục`; `trỏ ra ngoài --root`; `không được đóng` (rào hỏng); `khối HTML`. Ca KĐĐ đòi lý do của CHÍNH chốt nó đo, không đòi chuỗi chung `KHÔNG ĐO ĐƯỢC`. Ca xanh đòi rc 0.
- **Mốc đột biến không tự khớp** (lớp `moc-dot-bien-tu-khop-trong-khai-bao`). Mốc của một đột biến đặt trong tệp test không được xuất hiện nguyên dạng trong chính khai báo của nó: khai báo dựng mốc bằng phép nối hai hằng chuỗi. Ca sẵn có `moc_dot_bien_phai_khop_DUNG_MOT_CHO` thuộc tập ca nghiệm thu (N6, N7): nó nằm trong lượt nền của vòng đột biến, và đạt trên nguyên mẫu (S10).
- **Phân hạng đột biến**: dùng nguyên cơ chế của tệp (`chay_suite`, `_phan_loai_giet`, `_doi_chung_khac_ho`, vòng đột biến của `main`).
- **Hai ca liên kết tượng trưng** (G1) do phiên điều phối hoặc executor soạn, không do reviewer. Trên Ubuntu mọi ca của tập bắt buộc phải chạy thật; bỏ qua một ca ở đó là đỏ. Nền không tạo được liên kết thì ca dùng `BoQua` sẵn có, vốn chỉ nhận khi nguyên nhân là một `OSError` đo được.

## 9. `nghiem_thu`

Mỗi tiêu chí ghi phép đo làm nó ĐỎ. "H" là commit ứng viên; "nền" là base của lease. Điều kiện bắt đầu 3a–3e của mục 1 là điều kiện CẤP LEASE, không phải tiêu chí nghiệm thu của H; chúng chỉ chạy được lúc cấp lease, và giới hạn G1 đến G10 của chúng là nợ của Issue #1484, không phải tiêu chí của wp1466.

| # | mục tiêu | tiêu chí | phép đo làm nó ĐỎ | màu trên nền |
|---|---|---|---|---|
| N1 | M1 | `git show H:docs/adr/0068-bat-bien-protocol-va-review-theo-lop.md` bằng từng byte khối `adr` của blob đặc tả theo `spec_hash`, sau khi thay `{{TRANG_THAI}}` bằng một dòng khớp dạng ở 8.1 và `{{N1}}`…`{{N6}}` bằng số đo trên H | đổi một ký tự bất kỳ của tệp ADR, hoặc một `{{N…}}` khác số đo của lệnh in trong ADR ⇒ phép so khác 0 | tệp chưa có |
| N2 | M2 | Trên blob protocol tại H: mỗi khối `p1-moi` đến `p6-moi` có đúng 1 lần, đúng vị trí nêu ở 8.2; khối hai dòng `p4-cu` 0 lần; số DÒNG bằng đúng dòng `p5-cu` là 0; `git diff --numstat nền H -- docs/PROTOCOL_DA_PHIEN.md` là 46 thêm, 2 xoá | thiếu, lặp hay sai một byte của một khối ⇒ số lần khác 1; sửa thêm dòng ngoài sáu khối ⇒ numstat lệch | `p*-moi` 0 lần; `p4-cu`, `p5-cu` 1 lần |
| N3 | M2 | `adr-song --root .` rc 0, in `A ADR trên đĩa, A dòng` với A = số trên nền + 1 | bỏ khối `p6-moi` ⇒ rc 9 | rc 0 |
| N4 | M3 | `doctrine-scan --root .` trên H: rc 0 và dòng `doctrine-scan: sạch` | xoá một câu bất kỳ của một đơn vị khoá, dời nó, che nó tại chỗ, nhân đôi nó thành một đơn vị cùng loại ở chỗ hiển thị, hay đổi, thêm, bớt một byte trong khoảng dòng của nó ⇒ rc 9 (49 ca đỏ rc 9 của S10) | rc 0, nhưng chưa có phép kiểm mới |
| N5 | M3 | `INV_KHOA_PROTOCOL` tại H bằng đúng 7 bộ bốn của khối `khoa`; reviewer TỰ băm lại, bằng một script của riêng mình theo định nghĩa ở 8.3, địa chỉ và băm của bảy đơn vị của blob protocol tại H, và ra đúng các giá trị ấy | một giá trị trong mã khác giá trị tự tính ⇒ lệch | hằng chưa có |
| N6 | M3, M4 | Gọi T là tập tên có trong sổ `CASES` tại H mà không có trên nền. (a) 57 tên của tập bắt buộc ⊆ T; (b) mọi tên của T mang tiền tố `doctrine_inv_`; (c) handoff liệt kê T, và kích thước của T bằng hiệu số tên đăng ký (nền 1582) LẪN hiệu số tên áp dụng trên Linux (nền 1581); (d) cả T và ca sẵn có `moc_dot_bien_phai_khop_DUNG_MOT_CHO` đạt, 0 ca của T bị bỏ qua trên Ubuntu; (e) `packet_loop_test` N/N với hai số BẰNG NHAU (CI: 16 mảnh và job gom đạt); (f) khối `so-dang-ky` dưới đây in `SỔ ĐĂNG KÝ: ĐẠT` trên cặp (nền, H): dãy tên `CASES` của nền là dãy con giữ thứ tự của dãy ở H | thiếu một tên bắt buộc dù tổng đủ; một tên mới ngoài tiền tố; T khai lệch sổ; một ca đỏ hay bị bỏ qua; một ca cũ bị bỏ hay đổi chỗ khỏi sổ. T có 57 hay nhiều hơn đều đạt nếu đủ (a) đến (f) | 0 tên `doctrine_inv_*` |
| N7 | M4 | 26 tên của tập đột biến bắt buộc có mặt. Với MỌI đột biến có tại H mà không có trên nền, vòng đột biến thật in dòng `ok  <tên> → giết …`, và lượt chạy in `TỔNG: ĐẠT`. Đo bằng `packet_loop_test_manh.chay` với lượt nền là T cộng hai ca sẵn có của G9 và ca `moc_dot_bien_phai_khop_DUNG_MOT_CHO`, và pha đột biến là các đột biến mới; log nguyên văn đính vào handoff. Khối `so-dang-ky` in `SỔ ĐĂNG KÝ: ĐẠT`: mọi khoá `MUTANTS` của nền có ở H với ĐÚNG bộ ba cũ, và `MUTANTS_NHAM_TEST` của nền nằm trong của H | một đột biến còn sống; một ca đích chỉ chết vì CLI sập; một đối chứng chết; một khoá `MUTANTS` cũ bị ghi đè (đo trên nguyên mẫu: thêm `MUTANTS.update({"r1187_drop_doc_guard": ("a", "b", [])})` thì N8 vẫn ĐẠT vì câu lệnh đúng ngữ pháp, còn `so-dang-ky` ra KHÔNG ĐẠT, rc 1) | 0 đột biến mới |
| N8 | M3, M4 | **Phạm vi sửa, đo bằng AST và bằng một ngữ pháp đóng cho nút mới.** Chạy khối `do-pham-vi` dưới đây hai lần: chế độ `ma` trên `packet_loop.py`, chế độ `test` trên `packet_loop_test.py`, mỗi lần với blob tại nền và blob tại H; cả hai in `PHẠM VI [...]: ĐẠT` | đo trên nguyên mẫu r5 (03:03Z–03:12Z), ba nguồn biến thể. Chế độ `ma`: 13 biến thể của r4 (12 đỏ, 1 đạt), 6 biến thể độc lập của review lượt 4 (6 đỏ: mặc định, chú thích kiểu, decorator, thân lớp có `global`, `except … as`, decorator trên hàm cũ), 23 đường vào do người soạn r5 tự liệt kê (20 đỏ, 3 đạt). Chế độ `test`: 7 của r4 (6 đỏ, 1 đạt), 2 của review lượt 4 (2 đỏ), 14 của r5 (11 đỏ, 3 đạt). 65 trên 65 đúng kỳ vọng; danh sách ở mục 18 | — |
| N9 | M3, M4 | Hành vi sẵn có: 132 ca họ doctrine cũ (S8) và 40 ca `adr_song_*` đạt; `moc_dot_bien_phai_khop_DUNG_MOT_CHO` đạt; `packet_loop_test_manh.chay` với lượt nền là 132 ca ấy và pha đột biến là MỌI đột biến sẵn có có ca đích trong họ (21 trên nền) in `TỔNG: ĐẠT` | một ca cũ đỏ; một đột biến cũ còn sống hay giết đối chứng | đạt (S11) |
| N10 | M3, M4 | Ruff `F`: delta so với nền bằng 0 trên hai tệp `.py`, so theo bộ (mã, thông điệp bỏ số dòng, dòng nguồn) | thêm một tên không định nghĩa, một import thừa ⇒ delta khác 0 | nền 16 lỗi, đo 03:13Z (S14); không tệp nào rc 0, nên tiêu chí là delta chứ không phải rc |
| N11 | cả bốn | `python scripts/tl.py --selftest` N/N hai số bằng nhau và `git diff --check` sạch, trên đúng H trước lần đẩy (protocol §12, bất biến (a)) | — (cổng canh bất biến, xanh sẵn trên nền; răng đến từ bộ đột biến của chính nó) | đạt theo CI master |
| N12 | cả bốn | `git diff --numstat nền H`: đúng 4 tệp của mục 5, tổng dòng thêm ≤ 500 (`nang_tran` ADR-0053, quyết định E2 ở issuecomment-7201538748); đo trước MỖI lần đẩy và MỖI lần xin review, ghi cùng hai SHA | tệp thứ năm, hoặc tổng lớn hơn 500 ⇒ dừng TRƯỚC review (mục 10). Nguyên mẫu r5: 434, còn 16 dòng | — |
| N13 | cả bốn | CI PR trên H: sáu check bắt buộc của ruleset `success`, đọc theo NHÃN JOB; `gate-packet-loop` thật sự chạy (output `packet_loop` khác `bo_qua`) | một check đỏ, vắng hoặc `skipped` | — |
| N14 | cả bốn | K7: một lượt `ci-dot-bien-du.yml` `success` trên đúng H, mọi job `success` | lượt đỏ, thiếu job, hoặc khác H | — |
| N15 | cả bốn | `kiem-merge` chạy bằng mã của `master` trên H in `ĐỦ ĐIỀU KIỆN MERGE trên <H>`, với comment của chủ kho mang dòng `windows: <H> mien` | bất kỳ dòng `THIẾU` nào | — |
| N16 | M3, M4 | Sau land: lượt push trên `master` có `gate-packet-loop` Ubuntu `success`; lượt `packet-loop-dot-bien.yml` đầu tiên sau land chạy các đột biến mới và không dòng `ĐỎ` nào mang tên chúng | — | chưa đo được: chỉ đo được sau land; phiên land đo, đọc log theo nhãn job, ghi vào hồ sơ land |

Khối `do-pham-vi` (109 dòng không trống). Nó KHÔNG thuộc PR giao nộp; executor và reviewer chép nó ra một tệp tạm rồi chạy `python <tệp> ma|test <blob nền> <blob H>`. Luật nó đo, tất cả trên cây AST, không so chuỗi tên, và là CÙNG MỘT LUẬT cho hai chế độ; hai chế độ chỉ khác ở tham số (nút được sửa, chỗ đặt nút mới, họ tên, tên sổ đăng ký):

- (0) H biên dịch được (`compile`).
- (1) Dãy nút mức module của nền phải xuất hiện NGUYÊN THỨ TỰ trong H; mỗi nút ấy phải có `ast.dump` bằng hệt bản ở nền VÀ cùng byte nguồn, trừ nút được phép sửa.
- (2) Nút được phép sửa được so bằng AST: `cmd_doctrine_scan` chỉ được thêm, ngay sau phép gán `proto_words`, một dãy câu lệnh có AST bằng hằng `CHEN` của khối (mọi hằng chuỗi để trống trước khi so); `build_parser` chỉ được đổi đúng MỘT hằng chuỗi, là hằng mang dòng epilog; `_repo_gia` chỉ được đổi đúng MỘT biểu thức, từ tên `_PROTO_TRUNG_TINH` sang lời gọi `_proto_co_khoa()`.
- (3) Nút mới chỉ được đứng ở vị trí được phép: ngay trước `cmd_doctrine_scan` (chế độ `ma`); ngay trước `_repo_gia` hoặc ngay trước nút cuối tệp (chế độ `test`).
- (4) Mỗi nút mới thuộc đúng một dạng của NGỮ PHÁP ĐÓNG dưới đây; nút ngoài ngữ pháp thì đỏ.
  - **F**: `def` thường (không `async`), không decorator, mọi giá trị mặc định là hằng, và không câu `global` nào ở bất kỳ đâu trong nó. Nó gán đúng một tên ở phạm vi module: tên hàm.
  - **A**: phép gán có đúng một đích, và đích là một tên; giá trị là hằng, là bộ, danh sách, tập hay từ điển của các giá trị như thế, hay là lambda mà mọi giá trị mặc định là hằng. Nó gán đúng một tên: tên đích.
  - **R**, chỉ cho tên sổ đăng ký của chế độ (chế độ `test`: `CASES`, `MUTANTS`, `MUTANTS_NHAM_TEST`; chế độ `ma`: không có): `<sổ> += …` hay `<sổ> |= …`, hoặc một lời gọi `<sổ>.append(…)`, `<sổ>.extend(…)`, `<sổ>.update(…)` đứng làm câu lệnh; giá trị không chứa biểu thức gán `:=`. Nó không gán tên mới nào.
  - Tên mà F hay A gán phải thuộc họ của chế độ (`INV_`, `_INV_`, `_inv_` ở chế độ `ma`; mọi tên ở chế độ `test`) và KHÔNG được trùng định danh nào của cây cú pháp nền: mọi trường chuỗi của mọi nút, trừ giá trị hằng, tức tên biến, tên hàm, tên tham số, tên import, tên thuộc tính, và tên dựng sẵn mà mã nền gọi.
- (5) Đúng một dòng bị xoá, và mọi dòng thêm nằm trong một nút được phép sửa hoặc trong khoảng giữa hai nút cũ có chứa nút mới.

Vì sao ngữ pháp này trả lời được câu hỏi của N8, tức *phần mới có gán, ở phạm vi module, một tên mà mã nền dùng không*. Theo luật ràng buộc tên của Python (Language Reference §4.2.1), ngoài các câu lệnh mà luật (4) không nhận (gán nhiều đích hay gán bộ, gán có chú thích kiểu, gán tăng ngoài sổ, `for`, `with … as`, `except … as`, `match`, `import`, `del`, `class`, `type`, `if`, `try`, `while` bọc một định nghĩa), một tên ở phạm vi module chỉ còn bị gán bằng hai đường: biểu thức gán `:=` trong một biểu thức chạy ở phạm vi module (giá trị mặc định, decorator, comprehension, giá trị của câu lệnh sổ), hoặc câu `global` trong một phạm vi lồng. Dạng F cấm decorator, buộc mặc định là hằng và cấm `global`; dạng A chỉ nhận hằng và lambda có mặc định là hằng; dạng R cấm `:=`. Chú thích kiểu không chạy lúc định nghĩa vì cả hai tệp mở bằng `from __future__ import annotations`, một nút nền mà luật (1) giữ nguyên; biểu thức gán trong chú thích làm H không biên dịch được, và luật (0) đỏ. N8 không dùng `symtable` làm thước: từ Python 3.12, `symtable` gộp comprehension vào phạm vi bao nó, nên biến chạy của một comprehension ở module hiện ra như một tên gán ở module (đo ở máy soạn, Python 3.13.18).

Giới hạn của N8, khai thẳng: nó đo CÚ PHÁP. Nó không chứng minh phần mới giữ nguyên hành vi cũ LÚC CHẠY khi một thân hàm mới hay giá trị của một câu lệnh sổ gọi hàm có tác dụng phụ (`setattr` lên module, `globals()[…]`, `exec`, đổi thuộc tính của một module đã import). Hai phép đo hành vi đứng sau nó: khối `so-dang-ky` (N6 (f), N7) bắt việc ghi đè bản ghi sổ cũ, và N6 (e) cùng N9 chạy lại ca và đột biến cũ.

~~~ do-pham-vi
import ast, copy, difflib, sys, warnings
warnings.simplefilter("ignore")
che_do, nen, sau = sys.argv[1], open(sys.argv[2], encoding="utf-8").read(), open(sys.argv[3], encoding="utf-8").read()
A, B, loi = ast.parse(nen).body, ast.parse(sau).body, []
try:
    compile(sau, "<H>", "exec")
except SyntaxError as ex:
    loi.append(f"H không biên dịch được: {ex.msg} dòng {ex.lineno}")
ten_def = lambda n: n.name if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) else None  # noqa: E731
co = lambda t, kieu: any(isinstance(x, kieu) for x in ast.walk(t))  # noqa: E731
hang = lambda v: isinstance(v, ast.Constant)  # noqa: E731
TEN_NEN = set()  # mọi định danh của cây cú pháp nền: mọi trường chuỗi của mọi nút, trừ giá trị hằng
for x in ast.walk(ast.parse(nen)):
    for _, v in ([] if isinstance(x, ast.Constant) else ast.iter_fields(x)):
        TEN_NEN.update(p for s in (v if isinstance(v, list) else [v]) if isinstance(s, str) for p in s.split("."))
CHEN = ast.parse('loi_inv = _inv_kiem_protocol(root)\nif loi_inv:\n    for x in loi_inv:\n        print(f"doctrine-scan: {x}", file=sys.stderr)\n'
                 '    _die(RC_ADR, f"{len(loi_inv)} chỗ đơn vị khoá của protocol lệch mã cổng (ADR-0068)")').body
def boc(nut):
    """ast.dump của một dãy câu lệnh, mọi hằng chuỗi để trống: lời nhắn được đổi, cấu trúc thì không."""
    m = copy.deepcopy(ast.Module(body=list(nut), type_ignores=[]))
    for x in ast.walk(m):
        if isinstance(x, ast.Constant) and isinstance(x.value, str):
            x.value = ""
    return ast.dump(m)
def tinh(v):
    """Giá trị được phép của phép gán mới: hằng; bộ, danh sách, tập, từ điển của chúng; lambda mà mọi mặc định là hằng."""
    if isinstance(v, (ast.Tuple, ast.List, ast.Set)):
        return all(map(tinh, v.elts))
    if isinstance(v, ast.Dict):
        return all(k is not None and tinh(k) for k in v.keys) and all(map(tinh, v.values))
    if isinstance(v, ast.Lambda):
        return all(map(hang, v.args.defaults + [d for d in v.args.kw_defaults if d]))
    return hang(v)
def dang(n):
    """Tập tên mà một nút mới gán ở phạm vi module, nếu nút thuộc NGỮ PHÁP CHO PHÉP; None nếu không thuộc."""
    if (isinstance(n, ast.FunctionDef) and not n.decorator_list and not co(n, ast.Global)
            and all(map(hang, n.args.defaults + [d for d in n.args.kw_defaults if d]))):
        return {n.name}
    if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and tinh(n.value):
        return {n.targets[0].id}
    if (isinstance(n, ast.AugAssign) and isinstance(n.target, ast.Name) and n.target.id in LUAT["so"]
            and isinstance(n.op, (ast.Add, ast.BitOr)) and not co(n.value, ast.NamedExpr)):
        return set()
    f = n.value.func if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) else None
    if (isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and f.value.id in LUAT["so"]
            and f.attr in ("append", "extend", "update") and not co(n.value, ast.NamedExpr)):
        return set()
    return None
def chen_sau_proto(a, b):
    k = next(i for i, s in enumerate(a.body) if isinstance(s, ast.Assign) and ast.dump(s.targets[0]) == ast.dump(ast.Name("proto_words", ast.Store())))
    d, e = [ast.dump(s) for s in a.body], [ast.dump(s) for s in b.body]
    n = len(e) - len(d)
    vo = lambda x: ast.dump(type(x)(**{**{f: getattr(x, f) for f in x._fields}, "body": []}))  # noqa: E731
    return vo(a) == vo(b) and n == len(CHEN) and e[:k + 1] == d[:k + 1] and e[k + 1 + n:] == d[k + 1:] and boc(b.body[k + 1:k + 1 + n]) == boc(CHEN)
def mot_hang_chuoi(a, b):
    a, b = copy.deepcopy(a), copy.deepcopy(b)
    ca, cb = ([x for x in ast.walk(t) if isinstance(x, ast.Constant)] for t in (a, b))
    khac = [(x, y) for x, y in zip(ca, cb) if x.value != y.value]
    if len(ca) != len(cb) or len(khac) != 1 or "9 bảng ADR §20 lệch với docs/adr/" not in str(khac[0][0].value):
        return False
    khac[0][0].value = khac[0][1].value = ""
    return ast.dump(a) == ast.dump(b)
def mot_bieu_thuc(a, b):
    b, dem = copy.deepcopy(b), []
    class Doi(ast.NodeTransformer):
        def visit_Call(self, n):
            if isinstance(n.func, ast.Name) and n.func.id == "_proto_co_khoa" and not n.args and not n.keywords:
                dem.append(1)
                return ast.Name(id="_PROTO_TRUNG_TINH", ctx=ast.Load())
            return self.generic_visit(n)
    return ast.dump(Doi().visit(b)) == ast.dump(a) and len(dem) == 1
LUAT = {"ma": dict(sua={"cmd_doctrine_scan": chen_sau_proto, "build_parser": mot_hang_chuoi}, truoc=("cmd_doctrine_scan",), ho=("INV_", "_INV_", "_inv_"), so=()),
        "test": dict(sua={"_repo_gia": mot_bieu_thuc}, truoc=("_repo_gia", None), ho=("",), so=("CASES", "MUTANTS", "MUTANTS_NHAM_TEST"))}[che_do]
i, moi, vung, vi_tri = 0, [], [], {ten_def(n): k for k, n in enumerate(A) if ten_def(n)}
cho = {vi_tri[t] if t else len(A) - 1 for t in LUAT["truoc"]}
for j, b in enumerate(B):
    a = A[i] if i < len(A) else None
    if a is not None and ast.dump(a) == ast.dump(b):
        if ast.get_source_segment(nen, a) != ast.get_source_segment(sau, b):
            loi.append(f"nút cũ đổi byte dù AST giống: dòng {b.lineno}")
        i += 1
    elif a is not None and ten_def(a) in LUAT["sua"] and ten_def(b) == ten_def(a):
        if not LUAT["sua"][ten_def(a)](a, b):
            loi.append(f"{ten_def(a)}: AST đổi ngoài đúng chỗ được phép")
        vung.append((b.lineno, b.end_lineno))
        i += 1
    else:
        moi.append((i, b))
        vung.append((B[j - 1].end_lineno + 1 if j else 1, B[j + 1].lineno - 1 if j + 1 < len(B) else len(sau.split("\n"))))
if i != len(A):
    loi.append(f"nút cũ thứ {i + 1} (dòng {A[i].lineno} của nền) mất hoặc AST đã đổi")
for slot, n in moi:
    g = dang(n)
    if slot not in cho:
        loi.append(f"nút mới ở vị trí không được phép: dòng {n.lineno}")
    elif g is None:
        loi.append(f"nút mới ngoài ngữ pháp cho phép ({type(n).__name__}): dòng {n.lineno}")
    elif any(t in TEN_NEN or not t.startswith(LUAT["ho"]) for t in g):
        loi.append(f"nút mới khai tên đã có trong mã nền hoặc ngoài họ cho phép: {sorted(g)} dòng {n.lineno}")
dn, ds = nen.split("\n"), sau.split("\n")
ops = [o for o in difflib.SequenceMatcher(None, dn, ds, autojunk=False).get_opcodes() if o[0] != "equal"]
xoa = [d for t, i1, i2, j1, j2 in ops for d in dn[i1:i2]]
lac = [d for t, i1, i2, j1, j2 in ops for d in range(j1 + 1, j2 + 1) if not any(a <= d <= b for a, b in vung)]
if lac:
    loi.append(f"dòng thêm nằm ngoài nút mới và ngoài chỗ sửa được phép: dòng {lac[:5]}")
if len(xoa) != 1:
    loi.append(f"dòng xoá: cần đúng 1, thấy {len(xoa)} (kể cả dòng chú thích và dòng trống)")
print(f"PHẠM VI [{che_do}]: ĐẠT" if not loi else f"PHẠM VI [{che_do}]: KHÔNG ĐẠT\n  " + "\n  ".join(loi[:6]))
sys.exit(1 if loi else 0)
~~~

Khối `so-dang-ky` (21 dòng không trống). Nó KHÔNG thuộc PR giao nộp; chạy `python <tệp> <cây nền> <cây H>`, hai cây là hai checkout git đầy đủ, vì bộ test gọi `git ls-files` lúc nạp. Nó nạp `packet_loop_test` của mỗi cây trong một tiến trình con riêng rồi so: dãy tên `CASES` của nền là dãy con giữ thứ tự của dãy ở H; kích thước T bằng cả hai hiệu số; mọi tên của T mang tiền tố; mọi khoá `MUTANTS` của nền có ở H với đúng bộ ba cũ; `MUTANTS_NHAM_TEST` của nền nằm trong của H. Nạp hỏng là KHÔNG ĐO ĐƯỢC, rc khác 0.

~~~ so-dang-ky
import json, os, subprocess, sys
NAP = ("import json, os, sys; sys.dont_write_bytecode = True; sys.path.insert(0, os.path.join(sys.argv[1], '.claude', 'dev')); os.chdir(sys.argv[1]);"
       "import packet_loop_test as t, packet_loop_test_manh as m;"
       "print(json.dumps(dict(cases=[n for n, _ in t.CASES], linux=list(m.ca_dang_ky(t)),"
       " mutants={k: [v[0], v[1], list(v[2])] for k, v in t.MUTANTS.items()}, nham=sorted(t.MUTANTS_NHAM_TEST))))")
def nap(cay):
    r = subprocess.run([sys.executable, "-B", "-W", "ignore", "-c", NAP, os.path.abspath(cay)], capture_output=True, text=True)
    if r.returncode:
        sys.exit(f"SỔ ĐĂNG KÝ: KHÔNG ĐO ĐƯỢC — nạp {cay} rc={r.returncode}: {r.stderr.strip()[-300:]}")
    return json.loads(r.stdout.strip().splitlines()[-1])
a, b = nap(sys.argv[1]), nap(sys.argv[2])
it = iter(b["cases"])
con = all(n in it for n in a["cases"])  # dãy tên nền là dãy con GIỮ THỨ TỰ của dãy ở H
doi = sorted(k for k, v in a["mutants"].items() if b["mutants"].get(k) != v)
T = sorted(set(b["cases"]) - set(a["cases"]))
dk = dict(day_con_giu_thu_tu=con, T_bang_hai_hieu=len(T) == len(b["cases"]) - len(a["cases"]) == len(b["linux"]) - len(a["linux"]),
          T_dung_tien_to=all(n.startswith("doctrine_inv_") for n in T), mutants_cu_giu_nguyen=not doi, nham_nen_trong_h=set(a["nham"]) <= set(b["nham"]))
print(json.dumps(dict(cases=[len(a["cases"]), len(b["cases"])], linux=[len(a["linux"]), len(b["linux"])], T=len(T),
                      mutants=[len(a["mutants"]), len(b["mutants"])], mutants_cu_doi=doi[:5], **dk), ensure_ascii=False))
print("SỔ ĐĂNG KÝ:", "ĐẠT" if all(dk.values()) else "KHÔNG ĐẠT")
sys.exit(0 if all(dk.values()) else 1)
~~~

Reviewer mã CHẠY các ca và đột biến có sẵn rồi đột biến bản vá. Reviewer được cấp một mirror git đầy đủ trong sandbox, ghim `core.abbrev 7`, và đối chiếu cổng trong sandbox với cây gốc trên cùng commit trước khi review (protocol §8). Verdict của mọi lượt review của packet này, kể cả review đặc tả, theo §8.3.

## 10. `tran_*` và kích thước

Hai dòng khai đứng ở đầu tệp; OID của chúng qua ba phép đo ở S2. Trần lời gọi Codex do dòng khai `ADR-0055` chọn theo bảng ở mục *Hiệu lực* của ADR ấy; đặc tả không khai ngân sách nào dưới trần.

Kích thước, đối chiếu `ADR-0053` (≤ 6 tệp, ≤ 450 dòng thêm; từ r10 trần dòng thêm của wp1466 là 500 theo `nang_tran` E2 ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7201538748, phần nới để đóng lớp P3 `ca-id-chi-do-mot-gia-tri`). Cả bốn số là `git diff --numstat` trên cây nguyên mẫu (S10); mã giao nộp có thể khác:

| phần | dòng thêm |
|---|---|
| ADR | 149 |
| protocol | 46 |
| `packet_loop.py` | 76 |
| `packet_loop_test.py` | 163 |
| tổng | 434, trên 4 tệp (r4: 395); còn 16 dòng tới trần |

Con số nguyên mẫu không cấp trước ngoại lệ nào. Trần áp cho ứng viên giao nộp: trước mỗi lần đẩy H và trước mỗi lần xin review, executor đo `git diff --numstat` (N12). Vượt thì executor không đẩy, không xin review, không cắt ca hay đột biến để vừa trần; nó nộp numstat từng tệp và hai SHA cho phiên điều phối. Không cổng máy nào canh trần này (`numstat` 0×6).

## 11. `luat_dung`

Điểm dừng do protocol hay ADR đang hiệu lực đặt (dẫn tên, không chép, không hạ ngưỡng):

- Protocol §12: tín hiệu không hội tụ theo lớp; một lớp xuất hiện ở ba lượt review khác nhau. Đây là checkpoint của phiên: phiên tự xét lại cách làm và ghi mục sổ `xet_lai_cach_lam`.
- Protocol §12: trần attempt, cùng failure fingerprint, trần lời gọi Codex và trần vòng review; Review Rescue Checkpoint của `ADR-0037`.
- `ADR-0044` và `ADR-0053`: vượt trần kích thước thì dừng trước review.
- `ADR-0060` M5: số lần push thêm.
- `ADR-0056`: lease không tiến triển.
- Protocol §3.2: việc ngoài write set; finding cho thấy đặc tả thiếu thì verdict `blocked` và revision mới.
- Protocol §12, phân loại chi CI: phép đo được cấp bởi đặc tả này, khi chủ kho duyệt băm nó, là đúng một lượt `ci-dot-bien-du.yml` trên H.

Mã E của `ADR-0067` mà packet này có thể chạm, kèm thứ phải mang theo khi hỏi:

- E5 — duyệt `spec_hash`, audit exact-H, bấm merge: mang diff, lý do, và câu "không ai được thêm quyền; cổng mới chỉ siết".
- E2 — dòng `windows: <H> mien`; chạm trần lời gọi hay trần vòng; vượt trần kích thước (kèm numstat đo được); cần thêm lượt `ci-dot-bien-du.yml`; không chạy được `full_mutant_audit`: mang mức đã dùng, còn thiếu bao nhiêu, để làm gì.
- E1 hay E3 — chỉ khi checkpoint của §12 không còn phương án nào có phép đo chống đỡ, hoặc bằng chứng mâu thuẫn với quyết định ngày 20-11-2026 của chủ kho.

## 12. `pham_vi_e`

**Chạm E5.** ADR đổi luật về thế nào là một lượt review hợp lệ; packet thêm một điều kiện đỏ vào `doctrine-scan`, và đặt các băm mà sửa chúng là đổi luật. Không rõ thì khai là chạm. Hệ quả: chủ kho duyệt băm tệp này, tự audit exact-H trước lần đẩy đầu của H, và tự bấm merge; không tự đóng băng, không cấp lease theo uỷ quyền thường trực, không tự merge.

**Không chạm E4.** Không deploy, không `--apply`, không đụng Drive, registry, NLM hay secrets, không xoá ref, không đổi ruleset. Lượt soạn này chỉ ĐỌC ruleset, Issue và comment bằng REST GET.

## 13. `hinh_dang_ke_thua`

`khong_ap_dung` theo nghĩa của `soan-spec`: đây không phải packet khắc phục của một packet tiền nhiệm. Lịch sử lớp của chính đặc tả này ở mục 19 và không reset khi đổi revision. Ba hình dạng đã lặp qua các lượt review của chính đặc tả này được xử bằng đổi thiết kế, không bằng vá thêm: *chọn đại diện rồi sót* (câu neo; ô cổng không nợ; vế của §1), *thước đo gián tiếp* (số hunk; chuỗi đầu ra của ma trận; chuỗi tên ghép), và *nhận dạng tương đương* (tìm theo băm ở bất kỳ đâu; chuẩn hoá khoảng trắng; một dạng viết hàng; ở r4 còn lớp văn bản gộp CR LF và `rstrip`). Lượt 4 cho thấy thêm hình dạng *vá đúng chỗ được chỉ rồi bỏ sót đường thứ ba* (CLAUDE.md): r4 đóng gán nhiều đích nhưng bỏ sót giá trị mặc định và decorator. Revision 5 vì thế không vá theo danh sách biểu hiện mà tự liệt kê mọi đường vào cùng cơ chế trước khi đóng, và cho mỗi đường một ca hay một biến thể đỏ riêng: với byte, cả bốn chỗ chuẩn hoá ngầm (lớp văn bản, `rstrip`, dòng trắng làm biên, `splitlines`) cộng hai đường do chính việc đổi sang byte thô mở ra (che tại chỗ, đếm bản sao bị che); với N8, mọi dạng câu lệnh và biểu thức ràng buộc tên ở module, chỗ chèn được phép, tên dựng sẵn, và ghi đè sổ. Với tiền kiểm, r5 đến r7 cũng tự liệt kê đường vào (sáu bước của §5, rồi nguồn dữ liệu, rồi danh sách đầu vào), nhưng mỗi lượt review vẫn tìm ra đường thứ ba ở một biên mới. Hình dạng ấy lặp bảy lượt; r8 không vá tiếp mà rút phạm vi theo quyết định E2 (mục 0, mục 19).

## 14. Packet kế nhiệm

Ba packet đã có thẩm quyền (các quyết định E2 và E5 ở mục 0): **#1469**, **#1470** và **#1484**. Mỗi packet có đặc tả, review và duyệt băm RIÊNG. Đặc tả này không đặt hợp đồng, tiêu chí hay thiết kế nào cho chúng; nó chỉ ghi tên nợ mà chúng nhận.

| packet | nợ trong ADR-0068 mà nó nhận |
|---|---|
| #1469 | `INV-BANG-DOI-CHIEU-NGU-NGHIA` |
| #1470 | `INV-12-CONG-VERDICT-THEO-LOP`; và, tuỳ đặc tả của nó, `INV-06-PHIEN-VA-VAI`, `INV-11-K4-KHONG-DOC-HO-MODEL` |
| #1484 | `INV-02-TIEN-KIEM-CAP-LEASE-KHONG-CLOSURE`, gồm giới hạn G1 đến G10 ở mục 1 và các biểu hiện F11.b đến F11.i của lớp `tien-kiem-lease-chua-du` (mục 19). Issue ấy hiện ghi tên nợ khác (`INV-02-TIEN-KIEM-LEASE-TOAN-KHO`) và hẹn chốt tên ở r8; tên chốt là tên đã có trong ADR-0068 |

CHƯA được giao, chỉ là đề xuất của người soạn: một packet cho mỗi nợ `INV-09-DIFF-NGOAI-WRITE-SET`, `INV-10-HANDOFF-KHONG-CO-CONG`, `INV-17-DANH-SACH-DONG-0-CONG`, `INV-13-LEASE-SCHEMA-CU`, `INV-14-CHUP-WORKSPACE-TUY-CHON`, `COT-CONG-20-CHUA-CO-CONG`; một packet cho `INV-28-TRAN-KICH-THUOC` cùng `INV-16-BO-DEM-NGOAI-TRUC-LOI-GOI`; một packet đo cho `INV-03`. Mười bốn nợ còn lại của ADR-0068 chưa có đề xuất.

## 15. Ma trận phủ

**15.1 Nguồn → dòng `INV`** (lớp `thieu-truy-vet-yeu-cau`). Với §1, phép phủ là theo CHỮ: mỗi mục (1) đến (10) có đúng một dòng chép nguyên văn nó, nên không vế nào rơi được. Với nguồn khác, dòng chỉ mang một tên gọi ngắn; lời khai của đặc tả này cho các nguồn ấy là "có dòng trỏ tới", KHÔNG phải "đã phủ từng vế".

| nguồn | dòng | kiểu |
|---|---|---|
| §1 (1) · (2) · (3) · (4) · (5) | `INV-01` · `INV-02` · `INV-03` · `INV-19` · `INV-04` | nguyên văn |
| §1 (6) · (7) · (8) · (9) · (10) | `INV-05` · `INV-23` · `INV-06` · `INV-07` · `INV-22` | nguyên văn |
| §1 (11) · (12), thêm bởi packet này | `INV-12` · tiểu mục §1.1 | khoá bằng `K02`, `K01` |
| §8, câu về hai Executor writer | `INV-27` | nguyên văn một câu |
| §12 (a) · (b) · (c) | `INV-24` · `INV-25` · `INV-26` | tiêu đề in đậm của chính protocol |
| §3.2 · §5 · §7 | `INV-08` · `INV-09` · `INV-10` | tên gọi ngắn |
| §8: assurance · Review Class · reviewer chỉ đọc · severity | `INV-11` · `INV-13` · `INV-14` · `INV-21` | tên gọi ngắn |
| §7, §8, §8.3, §12 (review theo lớp) | `INV-12` | tên gọi ngắn; chữ của luật khoá bằng `K03` đến `K07` |
| §10.2.2 · §12 trần và bộ đếm · §12 danh sách E · §13 | `INV-15` · `INV-16` · `INV-17` · `INV-20` | tên gọi ngắn |
| §20 (`ADR-0044`, `ADR-0053`) · `CLAUDE.md` | `INV-28` · `INV-18` | tên gọi ngắn |

**15.2 23 điểm audit → nơi ở.** "Nợ" là một tên ở mục *Nợ* của ADR-0068, trừ bốn tên ghi rõ là chỉ ghi ở đặc tả này.

| điểm audit | nơi ở |
|---|---|
| A1 kích thước | `INV-28` · nợ `INV-28-TRAN-KICH-THUOC` |
| A2 handoff trước review | `INV-10` · nợ `INV-10-HANDOFF-KHONG-CO-CONG` |
| A3 đọc protocol và adapter trước | nợ `DOC-NGUON-TRUOC-KHONG-CO-CONG`, chỉ ghi ở đặc tả này: không có hiện vật nào trong kho để một cổng đọc việc một phiên đã đọc gì |
| B1 trần lời gọi Codex | `INV-16` · nợ `INV-16-BO-DEM-NGOAI-TRUC-LOI-GOI` |
| B2 mã E và sổ uỷ quyền | `INV-17` · nợ `INV-17-DANH-SACH-DONG-0-CONG` |
| B3 đề xuất duyệt băm cho bản chưa review | `INV-12` · nợ `INV-12-CONG-VERDICT-THEO-LOP` · #1470 |
| B4 ghi quyết định chủ kho bằng diễn giải | `INV-17` và `INV-23` · hai nợ của chúng |
| B5 comment ghi hộ thiếu nhãn | nợ `GHI-HO-KHONG-CO-CONG`, chỉ ghi ở đặc tả này; thuộc phạm vi `ADR-0067` |
| B6 verdict chưa lên kho; `stdout_sha256` không nối tệp verdict | phần băm: #1470. Phần giao bền: `INV-10` và `INV-23`; K4 đọc hai tệp cục bộ (S5) ⇒ nợ `INV-10-HANDOFF-KHONG-CO-CONG` |
| B7 trường hợp đồng verdict | #1470 · nợ `INV-12-CONG-VERDICT-THEO-LOP` |
| B8 `core.abbrev 7` ở clone reviewer; đối chiếu cổng mirror | nợ `CLONE-REVIEWER-KHONG-CO-CONG`, chỉ ghi ở đặc tả này: cổng của kho không nhìn được cấu hình của một clone khác |
| B9 danh tính sandbox reviewer | `INV-11` · nợ `INV-11-K4-KHONG-DOC-HO-MODEL` · #1470 |
| B10 sửa lease packet khác; lease lệch đặc tả và lượt chạy | `INV-01`, `INV-09` · nợ `INV-09-DIFF-NGOAI-WRITE-SET` |
| B11 prompt giao việc không lưu, không băm | `INV-10` · nợ `INV-10-HANDOFF-KHONG-CO-CONG` |
| B12 miễn Windows phải là dòng của chủ kho | đã có cổng: K6 của `kiem-merge`, ca `cong_c_k6_mien` |
| B13 nâng lên ba writer | `INV-27` · nợ `INV-27-HAI-WRITER` |
| B14 nhãn đối chiếu tự đặt | luật: đơn vị khoá `K04` của packet này; phần cổng: nợ `INV-12-CONG-VERDICT-THEO-LOP` · #1470 |
| B15 không dùng state máy | nợ `CONG-TREN-DUONG-STATE-KHONG-BAT-BUOC` |
| C1 Packet Issue thiếu schema §3.2 | `INV-08` (phần đặc tả) · phần Issue: `INV-23` |
| C2 lease thiếu trường heartbeat | nợ `LEASE-HEARTBEAT-KHONG-CO-CONG`, chỉ ghi ở đặc tả này; thuộc phạm vi `ADR-0056` |
| C3 giao lượt soạn trước khi Mission revision được cài | `INV-22` · nợ `INV-22-AUTHORITY-CHUYEN-STATE` |
| C4 không đọc `launcher.py` trước `doctor` | cùng nợ với A3 |
| C5 dùng `rc` của `tail` | `INV-10` (bằng chứng dương) · nợ `INV-10-HANDOFF-KHONG-CO-CONG` |

## 16. Quyết định thiết kế người soạn tự đưa

| # | quyết định | phép đo chống đỡ |
|---|---|---|
| D1 | wp1466 chỉ hứa ba việc của mục 0 | quyết định E2 và mục sổ checkpoint |
| D2 | khoá trọn đơn vị, không chọn câu (giữ từ r3) | review lượt 3 xếp `neo-thieu-nghia-vu` ĐÃ VÁ THẬT |
| D3 | đơn vị định danh bằng ĐỊA CHỈ (đường tiêu đề, thứ tự), phải duy nhất, rồi mới so băm | review lượt 3: tìm theo băm ở bất kỳ đâu thì dời và nhân đôi vẫn qua; S10: `doi_cho_K04`, `doi_cho_K01_sang_phu_luc`, `nhan_doi_K04`, `hai_tieu_muc_1_1` đều rc 9, mỗi ca có đột biến riêng giết |
| D4 | băm trên BYTE THÔ đọc một lần bằng `read_bytes`; biên chỉ là dòng rỗng 0 byte; bản che chỉ dùng để nhận dòng tiêu đề và dòng hiển thị | review lượt 3: chuẩn hoá khoảng trắng làm khối thụt bằng tab giữ nguyên băm; review lượt 4: `read_text` gộp CR LF, `rstrip` bỏ dấu cách cuối dòng nội dung (9 phép rc 0); S15: cả 9 nay rc 9; S10: bốn đột biến chuẩn hoá ngầm đều bị giết |
| D5 | chốt ID theo CHUỖI ID trên mọi dòng có `|`, so trên dạng hiển thị (NFKC, bỏ `Cf`) | review lượt 3: hàng không dấu cách hay không backtick lọt; r5, người soạn đo: bốn dạng ID ẩn (U+200B, gạch mềm, chữ số và gạch đứng toàn khoảng) ra rc 0 ở r4; S10 và S15: nay rc 9, `inv_id_khong_chuan_hoa` giết 3 |
| D6 | cổng nằm trong `doctrine-scan`; mã thoát riêng rc 9 (giữ từ r2) | review lượt 2 và 3 không bác |
| D7 | ô dạng cổng luôn mang `còn nợ`; mười dòng của §1 chép nguyên văn (giữ từ r3) | review lượt 3 xếp hai lớp ấy ĐÃ VÁ THẬT |
| D8 | không dựng Mission cho wp1466; nhánh nhận là `master` | quyết định E5 ở mục 0 |
| D9 | N8 so AST của từng nút sẵn có, nhận nút mới theo một NGỮ PHÁP ĐÓNG cùng một luật cho hai chế độ, so khối chèn với mẫu `CHEN`, và chỉ cho nút mới ở vị trí được phép | review lượt 3: phép gán nhiều đích lọt khi so chuỗi tên ghép; review lượt 4: mặc định, decorator và thân lớp có `global` lọt vì `gan` dừng ở nút định nghĩa; mục 18: 65 biến thể đúng kỳ vọng |
| D10 | tên ca mang tiền tố `doctrine_inv_`; đo bằng vòng đột biến thật (giữ từ r3) | S10 |
| D11 | mốc đột biến trong tệp test dựng bằng phép nối; ca kiểm mốc nằm trong lượt nền | review lượt 3: mốc tự khớp 2 chỗ; S10: lượt nền 60 trên 60 có ca ấy |
| D12 | điều kiện cấp lease chỉ chạy công cụ đã có trên base (so tập cặp ref, `git ls-tree` cho policy, `ai-dang-giu` cho từng đường dẫn, đo lại sau khi đăng) và khai giới hạn G1 đến G10; wp1466 không dựng công cụ tiền kiểm riêng | quyết định E2 ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7058057029. Lịch sử: r5 đến r7 dựng một khối tiền kiểm và mở rộng nó qua ba revision, mỗi lượt review 5 đến 7 vẫn tìm ra biểu hiện mới ở một biên khác (F11.d nguồn ref; F11.e, F11.f policy và đường nạp; F11.g, F11.h, F11.i đối số, tiến trình cha, giao thức tên). Phần còn thiếu là nợ có tên, có Issue kế nhiệm #1484 |
| D13 | khối HTML là KĐĐ, không phân tích (giữ từ r2) | nền có 1 dòng mở bằng `<`, là comment đã bị che |
| D14 | đơn vị phải hiển thị tại địa chỉ; phép đếm bản sao chỉ đếm đơn vị hiển thị | băm trên byte thô thì phép che không còn làm lệch băm; S10: `che_K04_ban_hien_noi_khac` rc 9, `inv_bo_hien_o_dia_chi` giết 1, `inv_dem_ban_ca_vung_che` giết 1 |
| D15 | sổ đăng ký ca và đột biến đo thêm lúc chạy (khối `so-dang-ky`) | ngữ pháp của N8 cho `MUTANTS.update`, nên ghi đè một khoá cũ qua được N8; mục 18: biến thể ấy N8 ĐẠT, `so-dang-ky` KHÔNG ĐẠT |
| D16 | người soạn từ r5 là Claude Opus 5.5; reviewer và executor không đổi | quyết định E2 ghi hộ ở đầu tệp |
| D17 | nợ của #1484 dùng tên đã có `INV-02-TIEN-KIEM-CAP-LEASE-KHONG-CLOSURE`, không đặt tên mới; mối nối tới #1484 nằm ở mục 0, mục 1 và mục 14 của đặc tả, không nằm trong văn bản ADR | tên ấy đã nằm trong khối `adr` (mục *Nợ*) và trong ô `còn nợ` của dòng `INV-02`, thuộc đơn vị khoá `K01`. Đổi tên hay thêm "Giao cho Issue #1484" vào ADR sẽ đổi khối `adr`, tệp ADR của nguyên mẫu, và với tên mới thì cả băm của `K01`, tức chạm phần review đã xếp ĐÃ VÁ THẬT. Văn bản nợ hiện có ("trước khi cấp lease chỉ có `ai-dang-giu`, so chuỗi đường dẫn bằng nhau; I2(Đ) chỉ chạy trên lease ĐÃ đăng; kho chưa có phép tính closure nào của §5") đã đúng với điều kiện bắt đầu của r8 |

## 17. Câu cần chủ kho quyết

| # | mã E | câu hỏi | khuyến nghị |
|---|---|---|---|
| C1 | E5 | Duyệt `spec_hash` của tệp này, gồm nguyên văn ADR-0068, 28 dòng bất biến, 28 tên nợ và 7 đơn vị khoá cùng địa chỉ của chúng | duyệt, sau khi review đặc tả Codex hết finding P0 đến P3 |
| C3 | E2 | Dòng `windows: <H> mien` cho packet này. Mã mới có một phép tính đường dẫn theo nền (`resolve` và so gốc) và hai ca dùng liên kết tượng trưng; hành vi trên Windows chưa đo | miễn theo ràng buộc đã chốt của packet; rủi ro còn lại là G1 trên Windows |
| C4 | E5 | `INV-03` để `chưa đo`, và `INV-18` lấy nguồn `CLAUDE.md` chứ không phải protocol | giữ cả hai như bảng |

Đã quyết, không còn là câu hỏi: tách ba packet (E2) và nhánh nhận của chuỗi (E5), hai URL ở mục 0; đổi người soạn từ r5 (E2), URL ở đầu tệp; tách khối tiền kiểm sang #1484 (E2), URL ở mục 0. Revision 5 đến 8 không có câu hỏi mới. Hai quyết định thiết kế của r5 còn lại trong đặc tả (ngữ pháp đóng của N8, cách nhận dạng hiển thị của chốt ID) không gắn được mã E nào: chúng không thiếu tài nguyên, không đảo quyết định nào của chủ kho, không đổi thẩm quyền ngoài phạm vi E5 đã khai ở mục 12. Người soạn tự quyết và ghi lý do ở mục 16 (D9, D5). Quyết định thứ ba của r5, khối tiền kiểm, đã rút theo E2 (D12).

## 18. `chua_do_duoc`

- Cây git của nguyên mẫu r5: `/tmp/claude-0/-home-user-tra-luat/1428173d-f5d8-5c81-a6c4-b24675398aaa/scratchpad/r5b/cay`, nhánh `proto`. Commit `48d372e` là nền (chính commit của `master`, không dựng lại); `400dc24` là nguyên mẫu r4, áp `ops/specs/wp1466/nguyen-mau-r4/nguyen-mau.patch` bằng `git apply -p1`; `c35ee0399f529d1f45c7fdc3eedbec2872e9843a` là bản vá r5. `git diff 48d372e c35ee03` là patch r5, đúng 4 tệp của mục 5. Script và log đo nằm ở thư mục cha của cây ấy: `sc/` (`khoa_tu_tinh.py`, `probes_r5.py`, `chay5.py`, `do_pham_vi.py`, `thu_pv5.py`, `so_dang_ky.py`, `tien_kiem.py`, `fx_tien_kiem.py`, `adr_r5_sua.py`) và `do/` (`f_ca.log`, `g_ca.log`, `f_moi.log`, `f_cu.log`, `f_adr.log`, `g_adr.log`, `f_pv_ma.log`, `f_pv_test.log`, `probes5.log`, `fx_tien_kiem.log`, `so_dang_ky_r5.log`, `so_dang_ky_ghi_de.log`, `khoa_r5.json`, `nguyen-mau-r5.patch`); tệp `SHA256SUMS` ở thư mục cha ghi băm của 23 tệp ấy (kiểm lại 03:31:10Z: 23 trên 23 khớp). Tất cả nằm ngoài kho; reviewer chỉ tái lập được S10, S11, S15 và các con số N8 dưới đây nếu phiên điều phối xuất chúng vào hồ sơ.
- Hiện vật của r6 nằm ở `/tmp/claude-0/-home-user-tra-luat/1428173d-f5d8-5c81-a6c4-b24675398aaa/scratchpad/r6`: `sc/tien_kiem.py` (khối `tien-kiem` r6, trùng từng byte với khối của đặc tả r6, sha256 `51b23a72ece9ea4d1dca40345da4abc638112e16c18cd6f690592c004e97e94b`), `sc/fx_tien_kiem.py` (`deabba7e6e06043e69e8e6c864af88ac3a9d0bf1ad81becd85a7efa6dc5e438d`), `sc/dot_bien.py` (`80e8ca998fa6fd0c65a0ad6cb4321cb0dff45c8afbca06952c1ffb9e53262c43`), `sc/tien_kiem_r5.py` (khối r5, để đối chứng), `rv/preflight_extra.py` (bản chép nguyên văn phản chứng của review lượt 5), và các log `do/fx_r6.log` (`9acd2c1cab1e6264668cd9987f95c57098028e84c7ed7ed3bfe6bcec0530f27f`), `do/dot_bien_r6.log` (`5307b6394edfbb76dd95dd64328a4a8445e29c82fd379fb357018d20c5935726`), `do/preflight_extra_r6.log` (`c5d91b0f5eea491cad165285671ba8234e5d48320a7dbdd108b871f97c69007c`), `do/do_that.log` (`4e033cd32b25a0f061d5aa8180ccc28a0f7df4f3b3a437f80fc4b07480e025e2`), `do/tien_kiem_that.log` (`234e9c8b75898c9e8a0a8592d82671d000222340b7337133872ceff4f4e284d9`). Clone đo thật là `kho/`. Nguyên mẫu mã không đổi ở r6: vẫn là cây r5 ở trên, nhánh `proto`, `c35ee0399f529d1f45c7fdc3eedbec2872e9843a`; `git diff --numstat 48d372e c35ee03` (04:10Z) vẫn ra 4 tệp, +434 −4, dưới trần 450. Các hiện vật r6 cũng nằm ngoài kho.
- Hiện vật của r7 nằm ở `/tmp/claude-0/-home-user-tra-luat/1428173d-f5d8-5c81-a6c4-b24675398aaa/scratchpad/r7`, ngoài kho: `sc/tien_kiem.py` (khối `tien-kiem` r7, trùng từng byte với khối của đặc tả r7 `3c89d87`), `sc/fx_tien_kiem.py` (bộ dựng r6, không sửa, trùng byte với bản ở `r6/sc/`), `sc/fx_r7.py`, `sc/dot_bien_r7.py`, `sc/do_that_r7.sh`, `sc/tien_kiem_r6.py` và `sc/tien_kiem_r5.py` (để đối chứng); log ở `do/` (`fx33_r7.log`, `fx_r7.log`, `dot_bien_r7.log`, `do_that_r7.log`); bản chép nguyên văn hai phản chứng của review lượt 6 ở `rv/` (`followup.py`, `hunt.py`, cùng sha256 với `evidence-followup.py`, `evidence-hunt.py`) và log của chúng (`rv/followup.log`, `rv/hunt.log`, `rv/hunt-results.json`). Tệp `SHA256SUMS` ở thư mục ấy ghi băm của từng tệp. Clone đo thật là `kho/`. `do/dot_bien_r7_luot_huy.log` là một lượt đột biến bị huỷ giữa chừng, chạy trên bản khối còn cờ `--full-history`; nó không dùng cho kết luận nào. Nguyên mẫu mã không đổi ở r7: nhánh `proto` vẫn ở `c35ee0399f529d1f45c7fdc3eedbec2872e9843a`, và `git diff --numstat 48d372e c35ee03` (04:53:02Z) vẫn ra 4 tệp, +434 −4, dưới trần 450.
- `packet_loop_test` chạy trọn: không chạy. Đã chạy 190 ca (S10), hai lượt vòng đột biến thật (S10, S11) và 40 ca `adr_song_*`.
- N8 trên nguyên mẫu r5 (03:03:21Z–03:12:06Z, tệp `.py` của `ea5baaa`, trùng `c35ee03`), cả hai chế độ in `ĐẠT` trên cây sạch; 65 biến thể, 65 đúng kỳ vọng.
  - Chế độ `ma`, 13 biến thể của r4 (12 đỏ, 1 đạt; như r4 đã liệt kê). 6 biến thể độc lập của review lượt 4, chép nguyên văn phần chèn từ `evidence-n8_run.py`, cả 6 đỏ: hàm mới có mặc định gán lại `RC_ADR`; chú thích kiểu có biểu thức gán (H không biên dịch được); decorator gán lại `RC_ADR`; lớp mới có `global` trong thân; `except … as RC_ADR`; decorator thêm vào hàm cũ. 23 đường vào do người soạn r5 tự liệt kê, 20 đỏ: lambda có mặc định là biểu thức gán; lambda có mặc định là tên cũ; gán giá trị là lời gọi `setattr`; gán giá trị là comprehension có biểu thức gán; gán có chú thích kiểu; gán tăng tên cũ; hàm mới có `global` trong thân; hàm mới có `global` trong hàm lồng; hàm mới có mặc định là tên cũ; `async def` mới; lớp mới không `global`; `def` tên cũ bọc trong `if`; `for` đích tên cũ; `with … as` tên cũ; `match` bắt tên cũ; `del` tên cũ; `type` alias; khối chèn có thêm `global _die`; khối chèn gán lại biến cũ `muc_tieu`; khối chèn đổi tên biến chạy; và 3 đạt: khối chèn chỉ đổi lời nhắn; hằng mới đúng họ; hàm mới có mặc định là hằng.
  - Chế độ `test`, 7 biến thể của r4 (6 đỏ, 1 đạt); 2 của review lượt 4 (mặc định và decorator gán lại `ROOT`, cả 2 đỏ); 14 của r5, 11 đỏ: biểu thức gán trong comprehension của `CASES +=`; biểu thức gán trong mặc định của lambda trong `CASES +=`; `MUTANTS[...] = …`; `CASES[0] = …`; `CASES.insert`; `CASES = CASES + []`; hàm mới có `global`; hàm mới tên `len` (tên dựng sẵn mà mã nền gọi); `print = print`; lớp mới; gán giá trị là lời gọi `setattr`; và 3 đạt: hàm mới tên lạ; `MUTANTS.update` với khoá mới; `MUTANTS_NHAM_TEST |= …`.
  - Chế độ `test` chạy khoảng 40 giây một lượt, vì so dòng của một tệp gần hai vạn dòng.
- Răng của khối `so-dang-ky` (03:15:30Z–03:16:21Z, chạy lại 03:26:24Z–03:26:37Z cùng kết quả): cây sạch ĐẠT rc 0; cây có thêm `MUTANTS.update({"r1187_drop_doc_guard": ("a", "b", [])})` KHÔNG ĐẠT rc 1 với đúng khoá ấy, trong khi N8 chế độ `test` trên cùng tệp in ĐẠT.
- Khối `tien-kiem` của r5 đến r7 và mọi số đo răng của nó (r5: 19 kịch bản; r6: 33 kịch bản, 3 đột biến; r7: 54 kịch bản, 14 đột biến; các phản chứng của review lượt 5 và 6 chạy lại) đã rút ở r8. Hồ sơ nằm ở các thư mục hiện vật nêu trên và ở đặc tả r7 (`3c89d87`). Chúng là dữ liệu đầu vào cho Issue #1484, không phải bằng chứng hay lời khai của wp1466.
- Hiện vật của r8 nằm ở `/tmp/claude-0/-home-user-tra-luat/1428173d-f5d8-5c81-a6c4-b24675398aaa/scratchpad/r8`, ngoài kho: `sc/muc1_buoc3.md` (bước 3 và bảng G1 đến G10 của mục 1), `sc/sua_r8.py` (bộ dựng r8 từ r7, mỗi phép thay đòi đúng một lần xuất hiện; sau nó có ba lượt sửa chữ nhỏ, nên diff đầy đủ r7→r8 là `do/r7-r8.diff`), `sc/do_that_r8.sh` và log `do/do_that_r8.log` (S18), `do/issue_*.json` (REST GET ba Issue), `do/grep_r8.log` (phép rà lời hứa, mục 19). Clone đo thật là `kho/`. Nguyên mẫu mã không đổi ở r8: nhánh `proto` của cây r5 vẫn ở `c35ee0399f529d1f45c7fdc3eedbec2872e9843a`.
- Điều kiện bắt đầu 3a đến 3e chưa chạy tới kết quả cho phép cấp lease trên kho thật: 3c ra người giữ B4 (S18). Kết quả ấy chỉ có được lúc cấp lease, sau khi B4 land và lease của nó được thu hồi. Giới hạn G1 đến G10 của mục 1: wp1466 không đo, vì chúng là nợ của Issue #1484.
- Chốt ID không bắt chữ cùng hình thuộc hệ chữ khác (mục 8.3); không đo thêm.
- Hành vi trên Windows của mã mới, nhất là G1 và việc đọc byte: không đo. `.gitattributes` của kho đặt `* text=auto eol=lf`, và `git check-attr` cho `docs/PROTOCOL_DA_PHIEN.md` ra `eol: lf`, nên checkout sạch trên mọi nền là LF. Một cây làm việc mà trình soạn thảo đã ghi CR LF vào protocol thì `doctrine-scan` đỏ ở máy ấy, dù blob sẽ được chuẩn hoá về LF lúc commit: đó là hệ quả chủ ý của băm trên byte thô, không phải lỗi.
- Diff cuối của packet B4: chưa tồn tại. Vị trí chèn và các dòng mốc phải đo lại trên base thật (điều kiện bắt đầu 4).
- 15 dòng khớp `label|assignee|board` ở ba tệp cổng sau: chưa đọc từng dòng.
- `bypass_actors` của ruleset và branch protection kiểu cũ của `master`: không đo.
- Trần lời gọi Codex cho review ĐẶC TẢ: không ADR nào nói `ADR-0055` có áp cho lượt review không gắn PR hay không.
- Model và effort thực phục vụ của reviewer: chỉ đo được ở từng lượt chạy.
- Tiêu chí N16: chỉ đo được sau land.

## 19. Lịch sử lớp finding của đặc tả này

Nguồn: review Codex lượt 1 trên r1 (`925f851`), lượt 2 trên r2 (`69bf087`), lượt 3 trên r3 (`b007995`, verdict `ops/specs/wp1466/review/r3-l3/VERDICT.md`), lượt 4 trên r4 (`937d135`, verdict `ops/specs/wp1466/review/r4-l4/VERDICT.md`, sha256 `400234b2…`), lượt 5 trên r5 (`05d12f1`, verdict `ops/specs/wp1466/review/r5-l5/VERDICT.md`, sha256 `9ce3dce3…`), lượt 6 trên r6 (`6c4ffe9`, verdict `ops/specs/wp1466/review/r6-l6/VERDICT.md`, sha256 `2a059046…`), lượt 7 trên r7 (`3c89d87`, verdict `ops/specs/wp1466/review/r7-l7/VERDICT.md`, sha256 `082db6d7…`). Slug giữ nguyên, không gộp, không tách. Từ lượt 4, verdict tách bảng (i), lớp mở của wp1466, khỏi bảng (ii), nợ kế nhiệm có authority; reviewer lượt 4 đồng ý cách đọc §8.3 ấy. Cột "trong wp1466" chỉ ghi thứ có phép đo trong phạm vi packet này. Cột "nợ kế nhiệm" ghi phần đã rời phạm vi: nó KHÔNG được gọi là vá và không được tính là vá (protocol §8.3); thẩm quyền của nó là quyết định E2 ở mục 0.

| slug · hạng | lượt 1 → 2 → 3 → 4 | trong wp1466 ở r5 | nợ kế nhiệm (Issue · tên nợ) | chưa đo |
|---|---|---|---|---|
| `neo-sai-don-vi-khop` · P1 | mới → ĐÃ VÁ THẬT → giữ → giữ | giữ: đơn vị vẫn được so TRỌN; r5 so trên byte thô, bảng `khoa` không đổi | — | mã của executor |
| `neo-thieu-nghia-vu` · P1 | mới → VÁ HỜ → ĐÃ VÁ THẬT → giữ | giữ: khoá trọn bảy đơn vị; ba ca xoá câu còn nguyên | — | luật ngoài bảy đơn vị không bị khoá |
| `cong-khong-do-bat-bien` · P1 | mới → VÁ HỜ → ĐÃ VÁ THẬT → giữ | giữ: 15 trên 15 ô cổng mang `còn nợ` | — | — |
| `thieu-truy-vet-yeu-cau` · P1 | mới → VÁ HỜ → ĐÃ VÁ THẬT → giữ | giữ: mười dòng của §1 chép nguyên văn | — | nguồn ngoài §1 chưa đối chiếu từng vế |
| `kiem-chuoi-khong-doc-cau-truc` · P2 | mới → VÁ SINH LỖI MỚI → còn mở → VÁ SINH LỖI MỚI (F05.d, F05.e ĐÃ VÁ THẬT; F05.f/g mới, bảng (i); F05.b/c bảng (ii)) | r5, F05.f/g: đọc `read_bytes` một lần, băm trên byte thô, biên chỉ là dòng rỗng 0 byte; không còn `read_text`, `splitlines`, `strip`, `rstrip` nào trên đường từ tệp tới băm. Các đường vào cùng cơ chế mà người soạn tự liệt kê rồi đóng cả loạt: lớp văn bản gộp CR LF, `rstrip` cuối mục, dòng chỉ khoảng trắng hay CR làm biên, `splitlines` tách ở U+2028; hai đường mà chính việc đổi sang byte thô mở ra (che đơn vị tại chỗ; đếm bản sao bị che); và ID ẩn ở G8 (U+200B, gạch mềm, chữ số toàn khoảng). Ca mới: 7 `crlf_*`, 7 `cach_cuoi_*`, `u2028_thay_xuong_dong`, `ff_giua_khoi`, `tab_cuoi_muc`, `nbsp_cuoi_muc`, `cr_cuoi_muc`, `dong_khoang_trang_sau_khoi`, `dong_cr_giua_hai_khoi`, `che_K04_ban_hien_noi_khac`, ba `dong_inv_ngoai_*` ẩn, ca xanh `them_dong_rong_giua_khoi_van_xanh`. Tám đột biến mới, mỗi đột biến một đường: `inv_doc_qua_text`, `inv_cat_cuoi_muc`, `inv_dong_trang_la_khoang_trang`, `inv_tach_dong_splitlines`, `inv_bo_hien_o_dia_chi`, `inv_dem_ban_ca_vung_che`, `inv_id_khong_chuan_hoa`, `inv_khoi_rong_tinh_la_khoi` (S10). 48 phép của review lượt 4: 48 đúng (S15). Dạng tương đương còn lại được KHAI: số dòng rỗng | F05.b/c: #1469 · `INV-BANG-DOI-CHIEU-NGU-NGHIA` | chữ cùng hình khác hệ chữ ở G8 |
| `duong-dan-chua-khep-trong-goc` · P2 | mới → VÁ HỜ → còn mở → CHƯA VÁ (bảng ii) | chỉ G1, cho tệp DUY NHẤT wp1466 đọc; r5 không đổi gì; wp1466 không hứa gì thêm về lớp này | đích đọc của tệp cổng, tệp ca, tệp ADR: #1469 · `INV-BANG-DOI-CHIEU-NGU-NGHIA` | Windows |
| `moc-chuyen-tiep-mau-thuan` · P2 | mới → VÁ HỜ → còn mở → CHƯA VÁ (bảng ii) | không có gì: wp1466 không nêu vị từ chuyển tiếp nào | toàn bộ lớp: #1470 · `INV-12-CONG-VERDICT-THEO-LOP` | — |
| `tieu-chi-dong-xoa-khong-do-hanh-vi` · P2 | mới → VÁ HỜ → còn mở → VÁ SINH LỖI MỚI (F08.b ĐÃ VÁ THẬT; F08.c mới, bảng (i)) | r5, F08.c: bỏ hàm `gan`; nút mới phải thuộc một NGỮ PHÁP ĐÓNG (F, A, R) cùng một luật cho hai chế độ; tên mới không trùng định danh nào của cây nền; khối chèn so với mẫu `CHEN`; H phải biên dịch được. Các đường vào mà người soạn tự liệt kê rồi đóng: giá trị mặc định, decorator, chú thích kiểu, thân lớp, `global` trong thân hàm và trong hàm lồng, lambda có mặc định, comprehension có `:=`, `except`, `for`, `with`, `match`, `import`, `del`, `type`, định nghĩa bọc trong `if`, gán có chú thích hay gán tăng, `global` hay gán lại biến cũ trong khối chèn, tên dựng sẵn mà mã nền gọi, gán giá trị là lời gọi, ghi đè bản ghi sổ (khối `so-dang-ky`). 65 biến thể đúng kỳ vọng, gồm đủ 8 biến thể độc lập của review lượt 4 (mục 18) | — | tác dụng phụ lúc chạy qua lời gọi: khai ở giới hạn của N8; đo hành vi bằng N6 (e), N9 và `so-dang-ky` |
| `dem-khong-khai-tap-ca` · P3 | mới → ĐÃ VÁ THẬT → giữ → giữ | giữ hai đơn vị ở S7 và N6 | — | — |
| `schema-bo-sot-provider-hop-le` · P2 | mới → VÁ HỜ → còn mở → CHƯA VÁ (bảng ii) | không có gì: wp1466 không nêu gì về lược đồ v2 | toàn bộ lớp: #1470 · `INV-12-CONG-VERDICT-THEO-LOP` | — |
| `tien-kiem-lease-chua-du` · P2 | mới → VÁ HỜ → còn mở → VÁ HỜ; lượt 5, 6, 7 đều VÁ HỜ (mục 0) | r8: không còn gì. wp1466 không hứa tiền kiểm; điều kiện bắt đầu 3a đến 3e chỉ chạy công cụ sẵn có và khai giới hạn G1 đến G10 (mục 1). r5 đến r7 từng đo lớp này bằng một khối tiền kiểm, đã rút ở r8 | toàn bộ lớp, gồm F11.b đến F11.i và G1 đến G10: #1484 · `INV-02-TIEN-KIEM-CAP-LEASE-KHONG-CLOSURE`. Thẩm quyền: quyết định E2 tách khối (mục 0). Theo §8.3, việc chuyển này KHÔNG được tính là vá | ĐẠT trên kho thật của 3a đến 3e: chỉ đo được lúc cấp lease |
| `doi-diem-goi-cong-chua-du-yeu-cau` · P2 | mới → ĐÃ VÁ THẬT → giữ → giữ | giữ: cổng nằm trong `doctrine-scan` | — | — |
| `doi-chung-khac-ho-chon-nham-doctrine` · P1 | — → mới → ĐÃ VÁ THẬT → giữ | giữ: tiền tố `doctrine_inv_`; 26 trên 26 dòng `ok` | — | — |
| `ma-tran-dem-doi-loi-thay-doi-mau` · P2 | — → mới → ĐÃ VÁ THẬT → giữ | giữ: đo bằng vòng đột biến thật | — | — |
| `tach-packet-bo-dieu-kien-integration` · P2 | — → mới → còn mở → ĐÃ VÁ THẬT | giữ: quyết định E5 chép ở mục 0 | — | — |
| `nghiem-thu-khoa-so-ca-trai-quyen-them` · P2 | — → mới → ĐÃ VÁ THẬT → giữ | giữ: N6, N7 theo tập bắt buộc cộng tập thêm thực | — | — |
| `khoa-khong-neo-vi-tri-va-duy-nhat` · P1 | — → — → mới → ĐÃ VÁ THẬT | giữ: địa chỉ, đúng một mục, đúng một bản. Byte thô làm phép che không còn tự lệch băm, nên r5 thêm vế hiển thị vào phép (2) và (3) để giữ đúng hành vi r4 với đơn vị bị che (D14); bốn ca dời và nhân đôi vẫn rc 9 | — | mã của executor |
| `moc-dot-bien-tu-khop-trong-khai-bao` · P2 | — → — → mới → ĐÃ VÁ THẬT | giữ: mốc dựng bằng phép nối; ca kiểm mốc nằm trong lượt nền và đạt (S10) | — | — |

**Lượt 5 (r5 `05d12f1`) và r6.** Nhãn của lượt 5: phần wp1466 của `kiem-chuoi-khong-doc-cau-truc` (F05.f/g) ĐÃ VÁ THẬT; `tieu-chi-dong-xoa-khong-do-hanh-vi` (F08.c) ĐÃ VÁ THẬT; `tien-kiem-lease-chua-du` VÁ HỜ (F11.b ĐÃ VÁ THẬT; F11.c VÁ HỜ; F11.d mới trong cùng nhóm, hai đường vào: nhánh cục bộ và remote phụ); bốn nhóm bảng (ii) CHƯA VÁ, đúng như đã chuyển sang #1469 và #1470. Các lớp đã đóng trước r5 được reviewer soi lại và giữ. Hội tụ r4→r5 là 2/3 (66,67%): reviewer áp U = ba lớp bảng (i) cuối lượt 4 theo chỉ thị của lượt ấy, không dùng U = 6 như đoạn cuối mục này ở r5. Không lớp mới, không lớp tái mở. `tien-kiem-lease-chua-du` có mặt ở cả năm lượt; lượt 5 là lần thứ năm. Lịch sử của nó: mới → VÁ HỜ → còn mở → VÁ HỜ → VÁ HỜ. Ở r6 lớp ấy vẫn ở bảng (i), vì wp1466 khi đó còn hứa tiền kiểm ở mục 1. Cách chữa của r6, ghi ở mục 0 và mục 1 của đặc tả r6 (các bước 3c, 3d, 3e theo đánh số r6): bất biến `I-NGUON`, cùng một bất biến cho trước và sau đăng. Người soạn r6 tự liệt kê chín đường vào, cộng hai đường khai là chưa đóng: máy chủ đổi sau T1, và cấu hình hay môi trường của người chạy. Có 33 kịch bản kho giả và 3 đột biến. Toàn bộ phần ấy đã rút ở r8.

**Lượt 6 (r6 `6c4ffe9`) và r7.** Nhãn của lượt 6: `tien-kiem-lease-chua-du` VÁ HỜ (F11.d ĐÃ VÁ THẬT; F11.e và F11.f mới trong cùng nhóm); bốn nhóm bảng (ii) CHƯA VÁ, đúng như đã chuyển sang #1469 và #1470; các lớp đã đóng trước r6 được giữ. Hội tụ r5→r6 là 0/1: U là 1, F là 0, vì reviewer không tính việc đóng riêng F11.d thành F = 1. Không lớp mới, không lớp tái mở. Lớp ấy có mặt ở cả sáu lượt; lượt 6 là lần thứ sáu. Lịch sử của nó: mới → VÁ HỜ → còn mở → VÁ HỜ → VÁ HỜ → VÁ HỜ. Quyết định ở checkpoint là mục sổ `xet_lai_cach_lam` ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7057370281: thôi vá theo từng đường, thay bằng danh sách cho phép đóng của mọi đầu vào, và đầu vào ngoài danh sách là DỪNG. Mục sổ ấy không gắn mã E nào. r7 làm theo hướng ấy (mục 0 và mục 1 của đặc tả r7, bảng *Đầu vào của khối*): mười một dòng đầu vào có chốt, ca và đột biến riêng, cộng năm dòng tiền đề được khai. Có 54 kịch bản kho giả và 14 đột biến. Lượt 7 vẫn tìm ra ba đầu vào ngoài bảng ấy. Toàn bộ phần ấy đã rút ở r8.

**Lượt 7 (r7 `3c89d87`) và r8.** Nhãn của lượt 7: `tien-kiem-lease-chua-du` VÁ HỜ (F11.e ĐÃ VÁ THẬT; các đường PyYAML cụ thể của F11.f đã đóng nhưng F11.f vẫn VÁ HỜ; F11.g, F11.h, F11.i mới trong cùng lớp); bốn nhóm bảng (ii) CHƯA VÁ, đúng như đã chuyển sang #1469 và #1470; các lớp đã đóng trước r7 được giữ. Hội tụ r6→r7 là 0/1: U là 1, F là 0. Không lớp mới, không lớp tái mở. Lớp ấy có mặt ở cả bảy lượt; lượt 7 là lần thứ bảy. Lịch sử của nó: mới → VÁ HỜ → còn mở → VÁ HỜ → VÁ HỜ → VÁ HỜ → VÁ HỜ. Hai chuyển tiếp liên tiếp r5→r6 và r6→r7 đều 0/1, dưới 50%. Checkpoint trước r7 là mục sổ `xet_lai_cach_lam` ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7057370281; câu trả lời cho checkpoint sau lượt 7 là quyết định E2 của chủ kho ở https://github.com/ducthangho/tra-luat/issues/1466#issuecomment-7058057029: "Tách khối ra (Recommended)". r8 làm đúng quyết định ấy (mục 0): rút khối tiền kiểm, chỉ giữ công cụ sẵn có làm điều kiện cấp lease, khai giới hạn G1 đến G10, và chuyển lớp sang bảng (ii) với nợ `INV-02-TIEN-KIEM-CAP-LEASE-KHONG-CLOSURE` của Issue #1484. Theo protocol §8.3, chuyển biểu hiện ra ngoài phạm vi KHÔNG được tính là vá: r8 không xin xếp lớp này ĐÃ VÁ THẬT, và nếu lượt 8 tính hội tụ r7→r8 thì lớp ấy không vào F. Nhãn của lớp ở lượt 8 do reviewer đặt. Phép rà "không còn lời hứa" của r8 (lệnh và output ở `r8/do/grep_r8.log`, mục 18): mọi câu còn nhắc khối, `I-NGUON`, "fail-closed" hay "đóng" trong phạm vi tiền kiểm đều là lịch sử của r5 đến r7 hoặc là lời khai giới hạn.

Không finding nào của bảy lượt bị người soạn bác.

**Lượt 8 (r8 `e215940`) và r9.** Lượt 8 approve r8 (bảng (i) 0 lớp). r9 không phát sinh từ review đặc tả mà từ phép đo của executor (mục 0, đoạn *Revision 9*). Lớp mới, đặt tên ở r9: `con-tro-trong-backtick-bi-cong-khac-doc` — chữ trong backtick của protocol bị `doc-claims-check` đọc như lệnh (L8) hay con trỏ ca (L12). Tám lượt review đặc tả không đo cổng này trên nguyên mẫu, và S10 của r5 cũng không. Hai đường vào, cả hai đã gặp: L12 ở bảng r8, L8 ở bản nháp của câu thêm ở r9.

**Review mã exact-H lượt 1 (H `da4e876`) và r10.** Verdict `blocked`. `phep-dem-ban-sao-khong-phu-ca-tep` · P2 (slug executor đặt ở lượt 1; cùng họ `khoa-khong-neo-vi-tri-va-duy-nhat`): chuyển sang bảng (ii), Issue #1469, nợ `INV-KHOA-BAN-SAO-DINH-CHU`, thẩm quyền E3; KHÔNG ghi là đã vá. `ca-id-chi-do-mot-gia-tri` · P3 (mới): phải đóng trong wp1466 bằng ca và đột biến của dòng G8 (mục 8.3); không miễn. Theo §12 lớp đầu đã lặp trong họ của nó, nên cách làm đổi theo quyết định chủ kho thay vì vá tiếp.

**Dữ liệu cho E1, nói thẳng.** Ba lớp `duong-dan-chua-khep-trong-goc`, `moc-chuyen-tiep-mau-thuan`, `schema-bo-sot-provider-hop-le` và nhóm F05.b/c của `kiem-chuoi-khong-doc-cau-truc` KHÔNG THỂ được đóng bằng bất kỳ revision nào của đặc tả này: chúng chỉ đóng được khi #1469 và #1470 có mã và ca. Review lượt 4 đã xếp chúng vào bảng (ii) và không tính chúng vào điều kiện approve của wp1466. Vì U của mỗi chuyển tiếp vẫn chứa các lớp ấy, tỷ lệ |F|/|U| của wp1466 có trần dưới 100% dù bảng (i) về 0: U cuối lượt 4 có 6 lớp, ba trong số đó chỉ còn biểu hiện ở bảng (ii), nên tỷ lệ r4→r5 cao nhất là 3/6 nếu reviewer xếp phần bảng (i) của `kiem-chuoi-khong-doc-cau-truc` là đã đóng, và 2/6 nếu không. Thước tiến triển mà mục sổ checkpoint thứ hai đã chọn là số lớp mở ở bảng (i): 13 → 9 → 3 → 1 → 1 → 1. Ở r8 thước ấy có thể về 0, nhưng con số 0 ấy đến từ việc chuyển phạm vi theo E2, không đến từ vá; theo §8.3 nó không được đọc thành tiến triển của vá. Đó là giới hạn của hướng này, không phải việc còn dang dở.
