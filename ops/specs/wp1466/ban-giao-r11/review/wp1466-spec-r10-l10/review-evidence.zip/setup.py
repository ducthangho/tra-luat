from pathlib import Path
import subprocess, json, hashlib, os, datetime
R=Path.cwd(); O=R/'out'
def run(args,cwd=R):
 p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 return {'cmd':args,'rc':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}
def snapshot(root):
 d={}
 for p in root.rglob('*'):
  if p.is_symlink(): d[str(p.relative_to(root))]=['link',os.readlink(p)]
  elif p.is_file():
   s=p.stat(); d[str(p.relative_to(root))]=[s.st_size,s.st_mtime_ns,hashlib.sha256(p.read_bytes()).hexdigest()]
 return d
for n in ['cay-kho','kho.git']:
 d=snapshot(R/n); (O/(n+'-before.json')).write_text(json.dumps(d))
 print('SNAPSHOT',n,len(d),flush=True)
logs=[]
for n in ['h','candidate']:
 root=O/n
 for a in [['git','clone','--shared','--no-checkout',str(R/'kho.git'),str(root)],['git','-C',str(root),'config','core.abbrev','7'],['git','-C',str(root),'config','core.hooksPath','/dev/null'],['git','-C',str(root),'checkout','--detach','da4e876890a1ebe99bb87de9e9a3b4f63c9fd5dd']]:
  r=run(a); logs.append(r); assert r['rc']==0,r
 print('BUILD',n,run(['git','rev-parse','HEAD','HEAD^{tree}'],root)['stdout'],flush=True)
(O/'setup.json').write_text(json.dumps(logs,ensure_ascii=False,indent=2))
