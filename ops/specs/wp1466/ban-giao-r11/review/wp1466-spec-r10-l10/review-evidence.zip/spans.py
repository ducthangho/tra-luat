from pathlib import Path
import sys,re,json,collections
O=Path(__file__).resolve().parent;C=O/'candidate';sys.path.insert(0,str(C/'scripts'));import tl
from tl_core import workflow as wf
ctx=tl._doc_claims_context(C); records=[]
for block in ['adr']+[f'p{i}-moi' for i in range(1,7)]:
 rel='docs/adr/0068-bat-bien-protocol-va-review-theo-lop.md' if block=='adr' else 'docs/PROTOCOL_DA_PHIEN.md'
 raw=(C/rel).read_text() if block=='adr' else (O/(block+'.txt')).read_text()
 nf,ns=tl._doc_claims_mask(raw);spans=list(wf._DOC_CLAIMS_SPAN_RE.finditer(nf));found=tl._doc_claims_scan_one(C/rel,nf,ns,tl._doc_claims_linestarts(raw),root=C,ctx=ctx)
 print(block,'SPANS',len(spans),'FINDINGS',json.dumps(found,ensure_ascii=False))
 records.append(dict(block=block,spans=[dict(line=raw[:s.start()].count('\n')+1,text=s[1]) for s in spans],findings=found))
print('ACTIVE_LAYERS',wf._DOC_CLAIMS_LAYERS,'REJECTED',ctx['basis'].get('layers_bac'))
(O/'spans.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
