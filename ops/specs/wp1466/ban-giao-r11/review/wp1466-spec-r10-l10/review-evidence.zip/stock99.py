from pathlib import Path
import os,sys,json
O=Path(__file__).resolve().parent; C=O/'candidate';sys.path.insert(0,str(C/'.claude/dev'));os.chdir(C);os.environ['TMPDIR']=str(O/'tmp')
import packet_loop_test as T
names={n for n,_ in T.CASES if n.startswith('doctrine_inv_dong_inv_ngoai')}
res=T.chay_suite(O/'id99/packet_loop.py',O/'stock99-fixed',names)
print('STOCK_ONLY99',sum(v is None for v in res.values()),'/',len(res),'ERRORS',{k:str(v) for k,v in res.items() if v is not None})
assert len(res)==6 and all(v is None for v in res.values())
